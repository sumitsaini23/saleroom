import { Grid, Card, CardContent, CardHeader, Button } from "@mui/material";
import React from "react";
import EmailIcon from "@mui/icons-material/Email";
import PeopleAltIcon from "@mui/icons-material/PeopleAlt";
import { Typography } from "antd";
import HistoryIcon from "@mui/icons-material/History";
import { useNavigate } from "react-router-dom";

const EmailHome = () => {
  let navigate = useNavigate();
  return (
    <>
      <Grid
        container
        alignItems={"center"}
        justifyContent={"center"}
        height={"85vh"}
        direction={"row"}
      >
        <Grid item>
          {EmailCard({
            heading: "Send Email",
            description: "Choose from pre-designed templates for any product",
            btnText: "Start Sending",
            btn: (
              <Button
                onClick={(e) => {
                  e.stopPropagation();
                  navigate("/emailLeads");
                }}
                variant="contained"
                sx={{
                  alignSelf: "bottom",
                  backgroundColor: "#174fba",
                  width: 150,
                }}
              >
                Start Sending
              </Button>
            ),
            icon: (
              <EmailIcon style={{ color: "#fff", height: "auto", width: 40 }} />
            ),
          })}
        </Grid>
        <Grid item>
          {EmailCard({
            heading: "Marketing Campaign",
            description: "Create curated campaigns from the contacts added",
            btnText: "Create",
            btn: (
              <Button
                disabled
                variant="contained"
                sx={{
                  alignSelf: "bottom",
                  backgroundColor: "#174fba",
                  width: 150,
                }}
              >
                Create
              </Button>
            ),
            icon: (
              <PeopleAltIcon
                style={{ color: "#fff", height: "auto", width: 40 }}
              />
            ),
          })}
        </Grid>
        <Grid item>
          {EmailCard({
            heading: "Analytics",
            description: "Check your marketing history & analytics data",
            btnText: "View",
            btn: (
              <Button
                variant="contained"
                disabled
                sx={{
                  alignSelf: "bottom",
                  backgroundColor: "#174fba",
                  width: 150,
                }}
              >
                View
              </Button>
            ),
            icon: (
              <HistoryIcon
                style={{ color: "#fff", height: "auto", width: 40 }}
              />
            ),
          })}
        </Grid>
      </Grid>
    </>
  );
};

export default EmailHome;

const EmailCard = (props) => {
  return (
    <>
      <Grid
        container
        alignItems={"center"}
        justifyContent={"center"}
        direction={"column"}
        sx={{ padding: 0, margin: 0 }}
        height={"100%"}
      >
        <Card
          sx={{
            padding: 0,
            margin: 0,
            minWidth: 275,
            minHeight: 275,
            margin: 5,
            borderRadius: 6,
            boxShadow: 10,
          }}
        >
          <CardContent sx={{ padding: 0, margin: 0, height: 250 }}>
            <Grid
              container
              alignItems={"center"}
              justifyContent={"center"}
              direction={"column"}
              // height={"100%"}
            >
              <Grid
                container
                width={"100%"}
                height={100}
                alignItems={"center"}
                justifyContent={"center"}
                sx={{ backgroundColor: "#174fba", padding: 0, margin: 0 }}
              >
                {props.icon}
              </Grid>
              <Grid
                container
                width={"100%"}
                height={110}
                alignItems={"center"}
                justifyContent={"center"}
                direction={"column"}
                maxWidth={200}
                sx={{ padding: 0, margin: 0, textAlign: "center" }}
              >
                <Grid item>
                  <Typography style={{ fontWeight: "bold", fontSize: 18 }}>
                    {props.heading}
                  </Typography>
                </Grid>
                <Grid item>
                  <Typography style={{ fontSize: 15 }}>
                    {props.description}
                  </Typography>
                </Grid>
              </Grid>
              {props.btn}
            </Grid>
          </CardContent>
        </Card>
      </Grid>
    </>
  );
};
