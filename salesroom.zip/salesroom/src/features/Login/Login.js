import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import { Button, TextField } from "@mui/material";

import "./Login.module.scss";
import ModalWrapper from "../../components/UI/ModalWrapper";
import {
  nextStep,
  userRegister,
  changeStatus,
  login,
  resetSignUp,
} from "../../reducers/authSlice";
import { Status, emailPattern } from "../../common/utility";

import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import IconButton from "@mui/material/IconButton";

//----request api--------------

const loginvalidateschema = Yup.object({
  username: Yup.string()
    .required("Required")
    .matches(emailPattern, "Invalid email ID"),
  password: Yup.string().required("Required"),
}).required();

const Login = ({ setloginWith, setProvideEmail }) => {
  const [showModal, setShowmodal] = useState(false);
  const status = useSelector((state) => state.auth.status);
  const regEmail = useSelector((state) => state.auth.signUp.email);
  const isLoggedIn = useSelector((state) => state.auth.isLoggedIn);
  const dispatch = useDispatch();
  //const errors = useSelector(selectErrors);
  //const inProgress = useSelector(selectIsLoading);
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm();

  const {
    control,
    handleSubmit: handleLoginSubmit,
    reset: resetLogin,
    formState: { errors: loginFormErrors },
  } = useForm({
    resolver: yupResolver(loginvalidateschema),
    mode: "onTouched",
  });

  useEffect(() => {
    if (status === Status.SUCCESS && regEmail !== "") {
      dispatch(changeStatus());
      navigate("/signup");
      //setloginWith(true);
    } else if (status === Status.SUCCESS && isLoggedIn === true) {
      dispatch(changeStatus());
      navigate("/dashboard");
    } else if (isLoggedIn === true) {
      navigate("/dashboard");
    } else {
      dispatch(resetSignUp());
      navigate("/");
    }
  }, [dispatch, isLoggedIn, status, regEmail, setloginWith, navigate]);

  const onSubmit = (data) => {
    if (!data) {
      alert("all field is empty");
      return;
    }
    let email = data.email;
    dispatch(nextStep(2));
    dispatch(userRegister({ email }));
    reset();
  };

  const onSubmitGetstarted = () => {
    // if (!data) {
    //   alert("all field is empty");
    // }
    navigate("/GetStarted/Signup");
    setProvideEmail(true);
  };

  const handleLoginModal = () => {
    setShowmodal(!showModal);
  };
  const handleClickShowConfPassword = () => {
    setShowPassword(!showPassword);
  };

  const handleMouseDownConfPassword = (event) => {
    event.preventDefault();
  };

  const authenticateUser = (data) => {
    let email = data.username;
    let password = data.password;
    dispatch(login({ email, password }));
    //resetLogin();
  };

  return (
    <>
      <div className=" h-screen">
        {/* a */}
        <div className="flex items-center px-8 py-3 h-fit">
          <div>
            {/* <img
                            alt="logo"
                            src={require("../../assets/images/icon/AplosLogo.png")}
                            className="h-20 "
                        /> */}
          </div>
          <div className="flex gap-8 ml-auto">
            {/* <Link
                            to="/"
                            className="text-[20px] font-semibold cursor-pointer"
                        >
                            Login
                        </Link> */}
            <Button
              className="text-[20px] font-semibold cursor-pointer"
              onClick={handleLoginModal}
            >
              Login
            </Button>
            <Button
              onClick={onSubmitGetstarted}
              className="btn-blue"
              // onClick={() => setProvideEmail(true)}
            >
              Get Started
            </Button>
          </div>
        </div>

        {/* b */}
        <div className="grid grid-cols-3 h-[86vh]">
          <div className="left pl-16 flex flex-col justify-around">
            <div className="w-56">
              <h1 className="text-5xl font-semibold mb-14 leading-snug">
                Managing Industrial Content
              </h1>
              <p className="leading-6 font-normal">
                Salesroom helps you create, organise and share your manuals and
                catalogues in seconds
              </p>
            </div>
          </div>
          <div className="right col-span-2 pr-16 ml-auto pt-20 flex flex-col justify-around">
            <div>
              <div className="flex gap-28 items-center mb-20">
                {/* <h1 className="text-8xl font-bold mb-10 text-[#174fba]">
                                    Salesroom
                                </h1> */}
                <img
                  alt="plan"
                  src={require("../../assets/images/icon/new logo.png")}
                  className="h-18"
                />
              </div>
              <form
                className="flex items-center w-fit ml-auto"
                onSubmit={handleSubmit(onSubmit)}
              >
                <div className="col-span-1  ">
                  <TextField
                    className="w-96"
                    autoComplete="off"
                    label="Enter Email "
                    name={"pasteurl"}
                    variant="outlined"
                    {...register("email", {
                      required: "This field is required",
                      pattern: {
                        value: emailPattern,
                        message: "Enter a valid email address",
                      },
                    })}
                  />
                </div>

                {/* <input
                                    type="text"
                                    
                                    placeholder="Enter Email"
                                    className="input-signup bg-[#ecedf0] pl-8 pr-12 py-4 rounded-full relative -right-10 w-96"
                                    style={{ marginBottom: 0 }}
                                    {...register("email", {
                                        required: "This field is required",
                                        pattern: {
                                            value: /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                                            message:
                                                "Enter a valid email address",
                                        },
                                    })}
                                /> */}
                <span className="errormsg loginError">
                  {errors?.email && errors.email.message}
                </span>
                <Button
                  variant="contained"
                  type="submit"
                  className="btn-black "
                  style={{
                    height: "58px",
                    marginLeft: "-10px",
                    padding: "0px 20px 0px 20px",
                    width: "150px",
                  }}
                >
                  Sign up
                </Button>
              </form>
              <ModalWrapper
                heading="Login"
                isPopUpShow={showModal}
                size="sm"
                toggleModel={handleLoginModal}
                saveBtnTitle="Done"
                onsubmit={handleLoginSubmit(authenticateUser)}
              >
                <div className="body">
                  <div className="grid grid-cols-6 gap-5 ">
                    {/* 1 */}
                    <div className="col-span-6">
                      <div className="col-span-6 mb-4">
                        <Controller
                          name="username"
                          control={control}
                          defaultValue=""
                          render={({ field, formState }) => (
                            <TextField
                              fullWidth
                              id="username"
                              label="Enter username *"
                              variant="standard"
                              {...field}
                              error={!!formState.errors?.username}
                            />
                          )}
                        />
                        {loginFormErrors.username &&
                          loginFormErrors.username.type === "required" && (
                            <span className={"error__feedback"}>
                              {loginFormErrors.username.message}
                            </span>
                          )}
                        {loginFormErrors.username &&
                          loginFormErrors.username.type === "matches" && (
                            <span className={"error__feedback"}>
                              {loginFormErrors.username.message}
                            </span>
                          )}
                      </div>
                      <div style={{ display: "flex" }}>
                        <Controller
                          name="password"
                          control={control}
                          defaultValue=""
                          render={({ field, formState }) => (
                            <TextField
                              fullWidth
                              type={showPassword ? "test" : "password"}
                              id="password"
                              label="Enter password *"
                              variant="standard"
                              {...field}
                              error={!!formState.errors?.password}
                            />
                          )}
                        />

                        <div className="pwdeyeicon">
                          <IconButton
                            position="end"
                            aria-label="toggle password visibility"
                            onClick={handleClickShowConfPassword}
                            onMouseDown={handleMouseDownConfPassword}
                          >
                            {showPassword ? <Visibility /> : <VisibilityOff />}
                          </IconButton>
                        </div>
                      </div>
                      {loginFormErrors.password &&
                        loginFormErrors.password.type === "required" && (
                          <span className={"error__feedback"}>
                            {loginFormErrors.password.message}
                          </span>
                        )}
                    </div>
                  </div>
                </div>
              </ModalWrapper>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Login;
