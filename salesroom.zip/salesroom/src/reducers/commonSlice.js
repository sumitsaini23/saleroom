import { createSlice } from "@reduxjs/toolkit";
import { getUser, login, logout } from "./authSlice";
/**
 * @type {AuthState}
 */
const initialState = {
  appName: "Salesroom",
  appLoaded: false,
  isAuthenticated: false,
  isLoading: false,
};

export const appLoad = (token, userId) => (dispatch) => {
  dispatch(commonSlice.actions.loadApp());
  if (token) {
    return dispatch(getUser({ userId }));
  }
};

const commonSlice = createSlice({
  name: "common",
  initialState,
  reducers: {
    loadApp(state) {
      state.appLoaded = true;
    },
    startLoader(state) {
      state.isLoading = true;
    },
    stopLoader(state) {
      state.isLoading = false;
    },
    clearRedirect(state) {
      delete state.redirectTo;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(login.fulfilled, (state, action) => {
      state.redirectTo = "/dashboard";
    });

    builder.addCase(logout, (state) => {
      state.redirectTo = "/";
    });
  },
});

export const { clearRedirect, startLoader, stopLoader } = commonSlice.actions;

export default commonSlice.reducer;
