import { Button, TextField } from "@mui/material";
import MenuItem from "@mui/material/MenuItem";
import React, { useState } from "react";
import Breadcrumb from "../../components/Breadcrumb/Breadcrumb";

function createData() {}

const EmailTemplates = () => {
  return (
    <>
      <Breadcrumb />
      <div className="p-6 grid grid-cols-1 md:grid-cols-4 lg:grid-cols-4 xl:grid-cols-4">
        <div className="mb-0 col-span-3">
          <h2 className="text-3xl font-bold mb-0">Email Templates</h2>
          {/* <h2 className="text-lg">2 members</h2> */}
        </div>
        <div className="col-span-3 mt-4">
          <div className={`form__item `}>
            <TextField
              fullWidth
              label="Subject Line"
              name={"email"}
              variant="outlined"
              helperText="Write a subject line that clearly describes your email content. It will be visible in your recipient’s inbox and is the first content they 
                                        will see. For example: ‘Private sale: 25% off our new collection"
            />
            <p className={"error__feedback mb-0"}>{/* {errors.Address1} */}</p>
          </div>
        </div>

        <div className="col-span-3 mt-4 ">
          <div className={`form__item `}>
            <TextField
              fullWidth
              label="Preview Text"
              variant="outlined"
              helperText="Write a short text (about 35 characters) that gives an overview of the content of your email. This will significantly increase your 
                                        opening rate. This feature is supported by most email clients, like Gmail and Yahoo. The text will be displayed in your recipient’s inbox, 
                                        just below the subject."
            />
            <p className={"error__feedback mb-0"}>{/* {errors.Address1} */}</p>
          </div>
        </div>
        <div className="col-span-3  mt-4">
          <div className={`form__item `}>
            <TextField
              fullWidth
              label="To Email"
              name={"email"}
              variant="outlined"
              helperText="Enter the address of the receiver"
            />
            <p className={"error__feedback mb-0"}>{/* {errors.Address1} */}</p>
          </div>
        </div>
        <div className="col-span-3 mt-4 ">
          <div className={`form__item `}>
            <TextField
              fullWidth
              variant="outlined"
              label="From Name"
              name={"email"}
              helperText="Enter a name (e.g. your company name) to help campaign recipients recognize you in their inbox."
            />
            <p className={"error__feedback mb-0"}>{/* {errors.Address1} */}</p>
          </div>
        </div>
        <div className="col-span-3 mt-5 ">
          <Button
            type="submit"
            disabled={false}
            variant="contained"
            className="btn-blue float-right"
          >
            Submit
          </Button>
        </div>
      </div>
    </>
  );
};

export default EmailTemplates;
