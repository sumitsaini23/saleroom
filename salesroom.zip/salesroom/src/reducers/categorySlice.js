import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import {
  Status,
  isApiError,
  //successReducer,
  failureReducer,
} from "../common/utility";
import requestsApi from "../app/requestsApi";
/**
 * @type {categoriesState}
 */
const initialState = {
  categories: [],
};
/**
 * Send a get current user request
 */
export const getAllCategories = createAsyncThunk(
  "categories/getAllCategories",
  async ({ businessId }, thunkApi) => {
    try {
      return await requestsApi.getRequest("/v1/dashboard/categories", {
        businessId: businessId,
      });
    } catch (error) {
      if (isApiError(error)) {
        // console.log("error", error);
        return thunkApi.rejectWithValue(error);
      }
      throw error;
    }
  }
);
/**
 * @param {import('@reduxjs/toolkit').Draft<AuthState>} state
 * @param {import('@reduxjs/toolkit').PayloadAction<{token: string, user: User}>} action
 */
function successGetAllCategoriesReducer(state, action) {
  state.status = Status.SUCCESS;
  state.categories = [...action.payload.categories];
}
/**
 * Reducers
 */
const categorySlice = createSlice({
  name: "categories",
  initialState,
  reducers: {
    saveCategories(state, action) {
      state.categories = action.payload;
    },
    deleteCategories(state, action) {
      state.categories = action.payload;
    },
  },
  extraReducers: (builder) => {
    /**
     * Pending Status
     */
    builder.addCase(getAllCategories.pending, (state) => {
      state.loading = Status.LOADING;
    });
    /**
     * fulfilled Status
     */
    builder.addCase(getAllCategories.fulfilled, successGetAllCategoriesReducer);
    /**
     * rejected Status
     */
    builder.addCase(getAllCategories.rejected, failureReducer);
  },
});

export const { saveCategories, deleteCategories } = categorySlice.actions;

export default categorySlice.reducer;
