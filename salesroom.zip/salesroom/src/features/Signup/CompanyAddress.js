import React, { useEffect, useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import { Button, TextField } from "@mui/material";
import Loader from "../../components/Loader";
import { Status } from "../../common/utility";
import {
    nextStep,
    previousStep,
    updateCompanyAddress,
    changeStatus,
} from "../../reducers/authSlice";

const companyFormSchema = Yup.object({
    address1: Yup.string().required("Required").min(2, "Too Short!"),
    address2: Yup.string().required("Required").min(2, "Too Short!"),
    landmark: Yup.string().required("Required").min(2, "Too Short!"),
    pincode: Yup.string()
        .required("Required")
        .matches(/^[0-9]+$/, "Must be only digits")
        .min(6, "Must be exactly 6 digits")
        .max(6, "Must be exactly 6 digits"),
    country: Yup.string().required("Required").min(2, "Too Short!"),
    district: Yup.string().required("Required").min(2, "Too Short!"),
    state: Yup.string().required("Required").min(2, "Too Short!"),
    city: Yup.string().required("Required").min(2, "Too Short!"),
}).required();

const CompanyAddress = () => {
    const dispatch = useDispatch();
    const [Isloading, setLoading] = React.useState(false);
    const status = useSelector((state) => state.auth.status);
    const businessId = useSelector((state) => state.auth.signUp.businessId);
    const companyAddress = useSelector(
        (state) => state.auth.signUp.companyAddress
    );

    const {
        control,
        handleSubmit,
        reset,
        formState: { errors },
    } = useForm({
        resolver: yupResolver(companyFormSchema),
    });

    useEffect(() => {
        if (status === Status.SUCCESS) {
            dispatch(changeStatus());
            setLoading(false);
            dispatch(
                nextStep(7) // update formStage
            );
        } else {
            setLoading(false);
            if (Object.keys(companyAddress).length !== 0) {
                reset({
                    address1: companyAddress.addressLine1,
                    address2: companyAddress.addressLine2,
                    city: companyAddress.city,
                    country: companyAddress.country,
                    district: companyAddress.district,
                    landmark: companyAddress.landmark,
                    pincode: companyAddress.pincode,
                    state: companyAddress.state,
                });
            }
        }
    }, [dispatch, reset, status, companyAddress]);

    const onSubmit = async (data) => {
        setLoading(true);
        let postData = {
            addressLine1: data.address1,
            addressLine2: data.address2,
            city: data.city,
            country: data.country,
            district: data.district,
            landmark: data.landmark,
            pincode: data.pincode,
            state: data.state,
        };
        await dispatch(updateCompanyAddress({ businessId, postData }));
        // reset();
    };

    return (
        <div>
            <div className="grid">
                <div className="header  mb-7">
                    <h2 className="text-[26px] font-medium">
                        Enter your company address
                    </h2>
                </div>
                <form>
                    <div className="body">
                        <div className="grid grid-cols-4 gap-1">
                            {/* 1 */}
                            <div className="col-span-4">
                                <div>
                                    <Controller
                                        control={control}
                                        name="address1"
                                        defaultValue=""
                                        render={({ field, formState }) => (
                                            <TextField
                                                fullWidth
                                                id="address1"
                                                label="Address 1 *"
                                                variant="standard"
                                                //autoComplete="off"
                                                {...field}
                                                error={
                                                    !!formState.errors.address1
                                                }
                                            />
                                        )}
                                    />

                                    {errors.address1 &&
                                        errors.address1.type === "required" && (
                                            <span className={"error__feedback"}>
                                                {errors.address1.message}
                                            </span>
                                        )}
                                    {errors.address1 &&
                                        errors.address1.type === "min" && (
                                            <span className={"error__feedback"}>
                                                {errors.address1.message}
                                            </span>
                                        )}
                                </div>
                            </div>
                            {/* 2 */}
                            <div className="col-span-4">
                                <div>
                                    <Controller
                                        name="address2"
                                        control={control}
                                        defaultValue=""
                                        render={({ field, formState }) => (
                                            <TextField
                                                fullWidth
                                                id="address2"
                                                label="Address 2 *"
                                                variant="standard"
                                                //autoComplete="off"
                                                {...field}
                                                error={
                                                    !!formState.errors?.address2
                                                }
                                            />
                                        )}
                                    />

                                    {errors.address2 &&
                                        errors.address2.type === "required" && (
                                            <span className={"error__feedback"}>
                                                Required
                                            </span>
                                        )}
                                    {errors.address2 &&
                                        errors.address2.type === "min" && (
                                            <span className={"error__feedback"}>
                                                {errors.address2.message}
                                            </span>
                                        )}
                                </div>
                            </div>
                            {/* 3 */}
                            <div className="col-span-3">
                                <div>
                                    <Controller
                                        name="landmark"
                                        control={control}
                                        defaultValue=""
                                        render={({ field, formState }) => (
                                            <TextField
                                                fullWidth
                                                id="landmark"
                                                label="Landmark *"
                                                variant="standard"
                                                autoComplete="off"
                                                {...field}
                                                error={
                                                    !!formState.errors?.landmark
                                                }
                                            />
                                        )}
                                    />

                                    {errors.landmark &&
                                        errors.landmark.type === "required" && (
                                            <span className={"error__feedback"}>
                                                Required
                                            </span>
                                        )}
                                    {errors.landmark &&
                                        errors.landmark.type === "min" && (
                                            <span className={"error__feedback"}>
                                                {errors.landmark.message}
                                            </span>
                                        )}
                                </div>
                            </div>
                            {/* 4 */}
                            <div className="col-span-1">
                                <div>
                                    <Controller
                                        name="pincode"
                                        control={control}
                                        defaultValue=""
                                        render={({ field, formState }) => (
                                            <TextField
                                                className="number-input"
                                                fullWidth
                                                type="text"
                                                id="pincode"
                                                label="Pincode *"
                                                variant="standard"
                                                autoComplete="off"
                                                {...field}
                                                inputProps={{ maxLength: 6 }}
                                                error={
                                                    !!formState.errors?.pincode
                                                }
                                            />
                                        )}
                                    />
                                    {errors.pincode &&
                                        errors.pincode.type === "required" && (
                                            <span className={"error__feedback"}>
                                                Required
                                            </span>
                                        )}
                                    {errors.pincode &&
                                        errors.pincode.type === "matches" && (
                                            <span className={"error__feedback"}>
                                                Pincode must be a number type
                                            </span>
                                        )}
                                    {errors.pincode &&
                                        errors.pincode.type === "min" && (
                                            <span className={"error__feedback"}>
                                                {errors.pincode.message}
                                            </span>
                                        )}
                                    {errors.pincode &&
                                        errors.pincode.type === "max" && (
                                            <span className={"error__feedback"}>
                                                {errors.pincode.message}
                                            </span>
                                        )}
                                </div>
                            </div>
                            {/* 5 */}
                            <div className="col-span-2">
                                <div>
                                    <Controller
                                        name="district"
                                        control={control}
                                        defaultValue=""
                                        render={({ field, formState }) => (
                                            <TextField
                                                fullWidth
                                                id="district"
                                                label="District *"
                                                variant="standard"
                                                autoComplete="off"
                                                {...field}
                                                error={
                                                    !!formState.errors?.district
                                                }
                                            />
                                        )}
                                    />

                                    {errors.district &&
                                        errors.district.type === "required" && (
                                            <span className={"error__feedback"}>
                                                Required
                                            </span>
                                        )}
                                    {errors.district &&
                                        errors.district.type === "min" && (
                                            <span className={"error__feedback"}>
                                                {errors.district.message}
                                            </span>
                                        )}
                                </div>
                            </div>
                            <div className="col-span-2">
                                <div>
                                    <Controller
                                        name="country"
                                        control={control}
                                        defaultValue=""
                                        render={({ field, formState }) => (
                                            <TextField
                                                fullWidth
                                                id="country"
                                                label="Country *"
                                                variant="standard"
                                                autoComplete="off"
                                                {...field}
                                                error={
                                                    !!formState.errors?.country
                                                }
                                            />
                                        )}
                                    />

                                    {errors.country &&
                                        errors.country.type === "required" && (
                                            <span className={"error__feedback"}>
                                                Required
                                            </span>
                                        )}
                                    {errors.country &&
                                        errors.country.type === "min" && (
                                            <span className={"error__feedback"}>
                                                {errors.country.message}
                                            </span>
                                        )}
                                </div>
                            </div>
                            {/* 6 */}
                            <div className="col-span-2">
                                <div>
                                    <Controller
                                        name="state"
                                        control={control}
                                        defaultValue=""
                                        render={({ field, formState }) => (
                                            <TextField
                                                fullWidth
                                                id="state"
                                                label="State *"
                                                variant="standard"
                                                autoComplete="off"
                                                {...field}
                                                error={
                                                    !!formState.errors?.state
                                                }
                                            />
                                        )}
                                    />

                                    {errors.state &&
                                        errors.state.type === "required" && (
                                            <span className={"error__feedback"}>
                                                Required
                                            </span>
                                        )}
                                    {errors.state &&
                                        errors.state.type === "min" && (
                                            <span className={"error__feedback"}>
                                                {errors.state.message}
                                            </span>
                                        )}
                                </div>
                            </div>
                            <div className="col-span-2">
                                <div>
                                    <Controller
                                        name="city"
                                        control={control}
                                        defaultValue=""
                                        render={({ field, formState }) => (
                                            <TextField
                                                fullWidth
                                                id="city"
                                                label="City *"
                                                variant="standard"
                                                autoComplete="off"
                                                {...field}
                                                error={!!formState.errors?.city}
                                            />
                                        )}
                                    />

                                    {errors.state &&
                                        errors.city.type === "required" && (
                                            <span className={"error__feedback"}>
                                                Required
                                            </span>
                                        )}
                                    {errors.state &&
                                        errors.state.type === "min" && (
                                            <span className={"error__feedback"}>
                                                {errors.state.message}
                                            </span>
                                        )}
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="footer col-span-4  flex justify-between my-5 ">
                        <Button
                            type="button"
                            style={{ marginRight: "1rem" }}
                            className="btnoutline  "
                            onClick={() =>
                                dispatch(
                                    previousStep() // update formStage
                                )
                            }
                        >
                            Back
                        </Button>
                        <div>
                            {/* <Button
                        type={"button"}
                        style={{ marginRight: "1rem" }}
                        onClick={next}
                    >
                        Skip
                    </Button> */}

                            <Button
                                type="submit"
                                className="btn-blue"
                                onClick={handleSubmit(onSubmit)}
                                //onClick={next}
                            >
                                {Isloading ? (
                                    <Loader isLoading={Isloading} />
                                ) : (
                                    "Next"
                                )}
                            </Button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default CompanyAddress;
