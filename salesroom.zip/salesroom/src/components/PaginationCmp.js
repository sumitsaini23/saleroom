import React from "react";
import PropTypes from "prop-types";
import Pagination from "@mui/material/Pagination";
import Stack from "@mui/material/Stack";

function PaginationCmp(props) {
  return (
    <Stack spacing={2}>
      <Pagination
        count={props.count}
        defaultPage={1}
        siblingCount={props.siblingCount}
        boundaryCount={props.boundaryCount}
        onChange={props.handlePageChange}
      />
    </Stack>
  );
}

PaginationCmp.propTypes = {};

export default PaginationCmp;
