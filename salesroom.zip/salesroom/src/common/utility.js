import moment from "moment";
import { toast } from "react-toastify";
import {
  ALERT_INFO,
  ALERT_WARNING,
  ALERT_ERROR,
  ALERT_SUCCESS,
  videoExtension,
  imageExtension,
  docExtension,
} from "./constants";
import requestsApi from "../app/requestsApi";
import axios from "axios";
/**
 * States of the slice
 * @readonly
 * @enum {string}
 */
export const Status = {
  /** The initial state */
  IDLE: "idle",
  /** The loading state */
  LOADING: "loading",
  /** The success state */
  SUCCESS: "success",
  /** The error state */
  FAILURE: "failure",
};

/**
 * Email regex
 */
export const emailPattern =
  /[A-Za-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[A-Za-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?\.)+[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?/;
/**
 * Check if error is an ApiError
 *
 * @param {object} error
 * @returns {boolean} error is ApiError
 */
export function isApiError(error) {
  switch (error.name) {
    case "AxiosError":
      return typeof error === "object" && error !== null;
    case "errors":
      return typeof error === "object" && error !== null && "errors" in error;
    default:
      break;
  }
}

/**
 * @param {import('@reduxjs/toolkit').Draft} state
 * @param {import('@reduxjs/toolkit').PayloadAction} action
 */
export function successReducer(state, _action) {
  state.status = Status.SUCCESS;
  //state.errors = action.payload.error;
}
export function failureReducer(state, _action) {
  state.status = Status.FAILURE;
  //state.errors = action.payload.error;
}

/**
 * Toast alert message
 */
export const ToastAlert = (obj) => {
  switch (obj.type) {
    case ALERT_INFO:
      return toast.info(obj.msg);
    case ALERT_WARNING:
      return toast.warning(obj.msg);
    case ALERT_ERROR:
      return toast.error(obj.msg);
    case ALERT_SUCCESS:
      return toast.success(obj.msg);
    default:
      break;
  }
};
/**
 * Error code & Error Message
 */
export const getErrorDetails = (error) => {
  let statusCode = "";
  let msg = "";
  statusCode = error.response.status ? error.response.status : error.code;
  msg = error.response.data ? error.response.data.errorMsg : error.message;
  return { statusCode, msg };
};
/**
 * check object
 */
export const dataIsArray = (data) => {
  //isArr = Object.prototype.toString.call(data) == '[object Array]'
  return Array.isArray(data);
};

/**
 * uploading the file we need the actual file data from  file URI
 */
// export const getBlob = async (fileUri) => {
//     const resp = await fetch(fileUri);
//     const imageBody = await resp.blob();
//     return imageBody;
// };
/**
 * check object empty or not
 */
export const checkObjectEmpty = (dataObject) => {
  if (Object.keys(dataObject).length === 0) {
    return null;
  } else {
    return dataObject;
  }
};
/**
 * clean object
 */
export const objDeepClone = (obj) => {
  return JSON.parse(JSON.stringify(obj));
};
/**
 * clean object
 */
export const firstLetterCapitalize = (str) => {
  return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
};

/**
 * Today Data time
 */
export const getTodayDateTime = () => {
  //2021-07-17T14:13
  return moment().format("YYYY-MM-DDTHH:mm");
};

/**
 * date custome format
 */

export const dateCustomFormat = (date, format, isCon = false) => {
  if (isCon === true) {
    return moment(date).utc().format(format); //convert with utc
  } else {
    return moment(date).format(format);
  }
};

export const getFileDetails = (fileData) => {
  const name = fileData.name;
  const lastDot = name.lastIndexOf(".");
  const fileName = name.substring(0, lastDot);
  const fileUrl = URL.createObjectURL(fileData);
  const ext = name.substring(lastDot + 1);
  return { fileName, fileUrl, ext };
};
/** get File Name
 * @param {*} fileData file array
 * @returns
 */
export const getFileName = (fileData) => {
  return dataIsArray(fileData) ? fileData[0].file.name : fileData.name;
};

/** get File extensions
 * @param {*} fileName file string
 * @returns
 */
export const getFileExtension = (fileName) => {
  return fileName.split(".").pop();
};
/** get File extensions by url
 * @param {*} url file string
 * @returns
 */
export const getFileExtensionByUrl = (fileUrl) => {
  return fileUrl.split(".").pop().split("?")[0];
};
/** get File name by url
 * @param {*} url file string
 * @returns
 */
export const getFileNameByUrl = (fileUrl, separator) => {
  let fileName = "";
  if (fileUrl) {
    let fnamestr = decodeURIComponent(fileUrl).split(separator)[1];
    if (fnamestr) {
      fileName = fnamestr.substring(0, fnamestr.indexOf("?"));
    }
  }
  return fileName;
};

export const getDecodecFileUrl = (fileUrl) => {
  let url = "";
  if (fileUrl) {
    let decodeurl = decodeURIComponent(fileUrl);
    if (decodeurl) {
      url = decodeurl
        .replace("https://aplos-onboard-dev.s3.ap-south-1.amazonaws.com/", "")
        .split("?");
      url = url[0];
    }
  }
  return url;
};

/** get sort filename
 * @param {*} fileName file string
 * @returns
 */
export const getSortName = (nameStr, num) => {
  let name = "";
  if (nameStr) {
    name =
      nameStr.length > num ? `${nameStr.substring(0, num - 3)}...` : nameStr;
  }
  return name;
};
/** get FileType for presigned URl
 * @param {*} fileName file string
 * @returns
 */
export const getPreSignUrlFileType = (fileName) => {
  let fileExtension = getFileExtension(fileName);
  if (videoExtension.includes(fileExtension)) {
    return "VIDEO";
  } else if (docExtension.includes(fileExtension)) {
    return docExtension === "PDF" || docExtension === "pdf" ? "PDF" : "DOC";
  } else {
    return "IMAGE";
  }
};

/**
 * get presignedURL
 */
export const getPreSignUrlLink = (
  businessId,
  fileName,
  uploadCategory,
  uploadFileType
) => {
  return requestsApi.postRequest("v2/documents/getPreSignUrl", {
    businessId: businessId,
    category: uploadCategory,
    filename: fileName,
    type: uploadFileType, //IMAGE
  });
};

/**
 * Upload file
 */

export const uploadFile = (preSignedUrl, fileData, onUploadProgress) => {
  //// console.log("fileData....", fileData);
  fileData = dataIsArray(fileData) ? fileData[0].file : fileData;
  let fileType = dataIsArray(fileData) ? fileData[0].file.type : fileData.type;
  const blob = new Blob([fileData], {
    type: fileType,
  });
  // formData.append(
  //     "file",
  //     dataIsArray(fileData) ? fileData[0].file : fileData
  // );

  let headers = {
    "Access-Control-Allow-Origin": "*",
    //"Content-Type": "multipart/form-data",
    "Content-Type": "binary/octate-stream",
  };

  return axios.put(preSignedUrl, blob, {
    headers: headers,
    onUploadProgress,
  });
  // .then(function (response) {
  //     // console.log("response_upload file", response);
  //     if (response.status === 200) {
  //         ToastAlert({
  //             type: ALERT_SUCCESS,
  //             msg: "File Uploaded",
  //         });
  //     }
  // })
  // .catch(function (error) {
  //     // console.log("response_upload file error", error);
  // });
};
