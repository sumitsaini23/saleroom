import React, { useContext } from "react";
import modalContext from "../ModalContext";
import { useNavigate } from "react-router-dom";
const VideosModalContent = () => {
  const { setShowModal, setUploadModal } = useContext(modalContext);
  const navigate = useNavigate();
  const handleDone = () => {
    navigate("/dashboard/videos");
    setUploadModal(true);
  };
  const handleCencle = () => {
    navigate("/dashboard");
    setShowModal(false);
  };
  return (
    <>
      {/*header*/}
      <div className="flex items-start justify-center p-5">
        <h3 className="text-3xl font-semibold text-center">Select Product</h3>
      </div>
      {/*body*/}
      <div className="relative p-6 flex-auto">
        <div>
          <select className="bg-gray-50 border border-black text-gray-900 text-sm focus:outline-none block w-[400px] p-2.5 mb-3">
            <option value="Auto CAPA">Auto CAPA</option>
            <option value="Manual CAPA">Manual CAPA</option>
            <option value="Bi-PAP v1.0 CP">Bi-PAP v1.0 CP</option>
          </select>
        </div>
      </div>
      {/*footer*/}
      <div className="flex items-center justify-end p-6 border-t border-solid border-slate-200 rounded-b">
        <button
          className="modal-cancle-btn"
          type="button"
          onClick={handleCencle}
        >
          Cancle
        </button>
        <button className="modal-done-btn" type="button" onClick={handleDone}>
          Done
        </button>
      </div>
    </>
  );
};

export default VideosModalContent;
