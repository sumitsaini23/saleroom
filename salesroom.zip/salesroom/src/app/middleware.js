//import agent from "../agent";
import { login, logout, userRegister } from "../reducers/authSlice";

const localStorageMiddleware = (store) => (next) => (action) => {
  switch (action.type) {
    case userRegister.fulfilled.type:
      break;
    case login.fulfilled.type:
      window.localStorage.setItem("token", action.payload?.logonSessionId);
      window.localStorage.setItem("userId", action.payload?.user.userId);
      break;
    case logout.type:
      window.localStorage.removeItem("token");
      window.localStorage.removeItem("userId");
      break;
    default:
      break;
  }

  return next(action);
};

export { localStorageMiddleware };
