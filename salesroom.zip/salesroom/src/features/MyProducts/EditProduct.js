import React, { useState, useEffect, useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { resetCreateProductObj } from "../../reducers/productSlice";
import Breadcrumb from "../../components/Breadcrumb/Breadcrumb";
import TabContentDetails from "../Categories/TabContentDetails";
import TabContentUploads from "../Categories/TabContentUploads";
import TabContentSpecification from "../Categories/TabContentSpecification";
import requestsApi from "../../app/requestsApi";

const EditProduct = (props) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const [openTab, setOpenTab] = useState("Details");
  const [productDetials, setProductDetials] = useState({});
  let productId = location.state?.productId;
  let categoryName = location.state?.categoryName;
  //// console.log("location", location);
  /**
   * Component mount
   */
  // useEffect(() => {
  //     // console.log("Calling");
  // });
  useEffect(() => {
    getProductById();
  }, []);
  /**
   * Clear state when component unmount
   */
  useEffect(() => {
    return () => {
      // console.log("cleaned up");
      dispatch(resetCreateProductObj());
      //navigate(location.state, {});;
    };
  }, []);

  const changeTab = (tabVal) => {
    setOpenTab(tabVal);
  };

  const getProductById = async () => {
    await requestsApi
      .getRequest(`/v1/products/${productId}`)
      .then(function (response) {
        setProductDetials(response);
      })
      .catch(function (error) {
        // console.log("error", error);
      })
      .then(function () {
        // always executed
        //dispatch(stopLoader());
        //// console.log("always executed");
      });
  };
  //// console.log("edit pro", productDetials);
  return (
    <>
      <Breadcrumb />
      <div className="flex flex-col w-full px-6 pt-7">
        <h3 className="font-bold">{categoryName}</h3>
      </div>

      <div className="flex  ">
        <div className="w-full">
          <ul
            className="tabs-btn flex mb-0 list-none flex-wrap pt-3 pb-4 flex-row px-6 border-b-2"
            role="tablist"
          >
            {/* Details tab */}
            <li className="-mb-px mr-2 last:mr-0 text-center">
              <a
                className={
                  "text-xs font-bold px-5 py-3 shadow-lg rounded block leading-normal" +
                  (openTab === "Details" ? " active" : " ")
                }
                onClick={(e) => {
                  e.preventDefault();
                  //setOpenTab("Details");
                }}
                data-toggle="tab"
                href="#link1"
                role="tablist"
                style={{ cursor: "default" }}
              >
                Details
              </a>
            </li>
            {/* Uploads tab */}
            <li className="-mb-px mr-2 last:mr-0 text-center">
              <a
                className={
                  "text-xs font-bold px-5 py-3 shadow-lg rounded block leading-normal" +
                  (openTab === "Uploads" ? " active" : " ")
                }
                onClick={(e) => {
                  e.preventDefault();
                  //setOpenTab("Uploads");
                }}
                data-toggle="tab"
                href="#link2"
                role="tablist"
                style={{ cursor: "default" }}
              >
                Uploads
              </a>
            </li>
            {/* Specifications tab */}
            <li className="-mb-px mr-2 last:mr-0 text-center">
              <a
                className={
                  "text-xs font-bold px-5 py-3 shadow-lg rounded block leading-normal" +
                  (openTab === "Specifications" ? " active" : " ")
                }
                onClick={(e) => {
                  e.preventDefault();
                  //setOpenTab("Specifications");
                }}
                data-toggle="tab"
                href="#link2"
                role="tablist"
                style={{ cursor: "default" }}
              >
                Specifications
              </a>
            </li>
          </ul>
          <div className="body px-6">
            {/* Details tab Content */}
            <div
              className={
                openTab === "Details" ? "grid grid-cols-1 gap-6 mt-6" : "hidden"
              }
              id="tablink1"
            >
              <TabContentDetails
                key="productDetails"
                changeTab={changeTab}
                prodata={productDetials}
                action="Edit"
              />
            </div>
            {/* Uploads tab content */}
            <div
              className={openTab === "Uploads" ? "block mt-6" : "hidden"}
              id="tablink2"
            >
              <TabContentUploads
                changeTab={changeTab}
                key="productUploadDetails"
                prodata={productDetials}
                action="Edit"
              />
            </div>
            {/* Specifications  tab content */}
            <div
              className={
                openTab === "Specifications"
                  ? "grid grid-cols-1 md:grid-cols-1 lg:grid-cols-1 gap-6 mt-6"
                  : "hidden"
              }
              id="tablink3"
            >
              <TabContentSpecification
                changeTab={changeTab}
                key="productSpecifications"
                prodata={productDetials}
                action="Edit"
              />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default EditProduct;
