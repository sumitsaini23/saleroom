import React, { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import PropTypes from "prop-types";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import { MdAdd } from "react-icons/md";

import { showCategoryModal, showProductModal } from "../reducers/modalSlice";
import CategoryModal from "./Modals/CategoryModal/CategoryModal";
import ProductModal from "./Modals/ProductModal/ProductModal";

function AddCardIconCmp(props) {
  const [modalName, setModalName] = useState("");
  const showModal = useSelector((state) => state.modalView.showModal);
  const dispatch = useDispatch();

  /**
   *
   * Methods
   */
  const handleModal = (item) => {
    setModalName(item);
    switch (item) {
      case "Product":
        return dispatch(
          showProductModal({
            action: "Add",
            selectedMenu: item,
            categoryId: props.categoryId,
            productName: "",
            productId: "",
          })
        );
      case "Category":
        return dispatch(
          showCategoryModal({ action: "Add", selectedMenu: item })
        );
      default:
        break;
    }
  };

  const getModal = () => {
    switch (modalName) {
      case "Product":
        return <ProductModal />;
      case "Category":
        return <CategoryModal />;
      default:
        break;
    }
  };

  return (
    <>
      <Box
        sx={{
          border: "2px dashed #174fba",
          height: "100%",
          borderRadius: "10px",
          background: "#F4F7FE",
        }}
      >
        <Card
          sx={{
            height: "100%",
            borderRadius: "12px",
            background: "#F4F7FE",
            boxShadow: 10,
          }}
          onClick={() => handleModal(props.title)}
        >
          <CardContent>
            <h2
              className="fontheadclr"
              style={{ paddingTop: "25px" }}
            >{`Add ${props.title}`}</h2>

            <MdAdd className="iconadd" />
          </CardContent>
        </Card>
      </Box>
      {showModal && getModal()}
    </>
  );
}

AddCardIconCmp.propTypes = {};

export default AddCardIconCmp;
