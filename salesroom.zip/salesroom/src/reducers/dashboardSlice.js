import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import {
  Status,
  isApiError,
  successReducer,
  failureReducer,
} from "../common/utility";
import requestsApi from "../app/requestsApi";

/**
 * @type {AuthState}
 */
const initialState = {
  status: Status.IDLE,
};

/**
 * Send request upload image
 */
export const updateBusinessLogo = createAsyncThunk(
  "auth/updateBusinessLogo",
  async ({ url, file }, thunkApi) => {
    // console.log("url", url);
    try {
      return await requestsApi.putRequest(url, {
        file: file,
      });
    } catch (error) {
      // console.log("res....", error);
      if (isApiError(error)) {
        return thunkApi.rejectWithValue(error);
      }
      throw error;
    }
  }
);
/**
 * Send request update company address
 */
export const updateCompanyAddress = createAsyncThunk(
  "auth/updateCompanyAddress",
  async ({ businessId, postData }, thunkApi) => {
    try {
      return await requestsApi.putRequest("v1/business", {
        businessId: businessId,
        address: postData,
      });
    } catch (error) {
      // console.log("res....", error);
      if (isApiError(error)) {
        return thunkApi.rejectWithValue(error);
      }
      throw error;
    }
  }
);
/**
 * Send request update BusinessAdditionalInfo
 */
export const updateBusinessAdditionalInfo = createAsyncThunk(
  "auth/updateBusinessAdditionalInfo",
  async ({ businessId, postData }, thunkApi) => {
    try {
      return await requestsApi.putRequest("v1/business", {
        businessId: businessId,
        additionalInfo: postData,
      });
    } catch (error) {
      if (isApiError(error)) {
        return thunkApi.rejectWithValue(error);
      }
      throw error;
    }
  }
);

/**
 * Send request update BusinessAdditionalInfo
 */
export const updateBusinessSocialMediaInfo = createAsyncThunk(
  "auth/updateBusinessSocialMediaInfo",
  async ({ businessId, postData }, thunkApi) => {
    try {
      return await requestsApi.putRequest("v1/business", {
        businessId: businessId,
        socialMediaInfo: postData,
      });
    } catch (error) {
      if (isApiError(error)) {
        return thunkApi.rejectWithValue(error);
      }
      throw error;
    }
  }
);
/**
 * @param {import('@reduxjs/toolkit').Draft<AuthState>} state
 * @param {import('@reduxjs/toolkit').PayloadAction<{token: string, user: User}>} action
 */
function successLoginReducer(state, action) {
  state.status = Status.SUCCESS;
  state.isLoggedIn = true;
  state.token = action.payload.logonSessionId;
  state.user = action.payload.user;
}

function successGetUsesrReducer(state, action) {
  const token = window.localStorage.getItem("token");
  state.status = Status.SUCCESS;
  state.isLoggedIn = true;
  state.token = token;
  state.user = {
    businessId: action.payload.businessId,
    email: action.payload.email,
    fullName: action.payload.fullName,
    role: action.payload.role,
    userId: action.payload.userId,
  };
}

function successSignUpReducer(state, action) {
  state.signUp.email = action.payload.identifier;
  state.signUp.otpReferenceId = action.payload.otpReferenceId;
  state.status = Status.SUCCESS;
}

function successSignUpBusinessReducer(state, action) {
  state.signUp.businessId = action.payload.businessId;
  state.status = Status.SUCCESS;
}

function successSignUpUserReducer(state, action) {
  state.signUp.userId = action.payload.userId;
  state.status = Status.SUCCESS;
}

function successSignUpPresignedUrlReducer(state, action) {
  state.signUp.presignedUrl = action.payload.preSignedUrl;
  state.signUp.path = action.payload.path;
  state.status = Status.SUCCESS;
}
function successSocialMediaInfoReducer(state) {
  state.signUp = initialState.signUp;
  state.status = Status.SUCCESS;
}

/**
 * Reducers
 */

export const dashboardSlice = createSlice({
  name: "dashboard",
  initialState,
  reducers: {
    /**
     * Log out the user
     */
    logout: () => initialState,
    /**
     * SignUp
     */
    signUpPassword: (state, action) => {
      state.signUp.password = action.payload;
    },
    changeStatus: (state) => {
      state.status = initialState.status;
    },

    // /**
    //  * Update token
    //  *
    //  * @param {import('@reduxjs/toolkit').Draft<AuthState>} state
    //  * @param {import('@reduxjs/toolkit').PayloadAction<string>} action
    //  */
    // setToken(state, action) {
    //   state.token = action.payload;
    // },
  },
  extraReducers(builder) {
    /**
     * Pending Status
     */
    // builder.addCase(login.pending, (state) => {
    //     state.loading = Status.LOADING;
    // });
    /**
     * fulfilled Status
     */
    //builder.addCase(login.fulfilled, successLoginReducer);
    /**
     * rejected Status
     */
    //builder.addCase(login.rejected, failureReducer);
    //     builder.addMatcher(
    //       (action) => /auth\/.*\/pending/.test(action.type),
    //       loadingReducer
    //     );
  },
});

/**
 * Action creators are generated for each case reducer function
 */

export const { logout, signUpPassword, changeStatus } = dashboardSlice.actions;

export default dashboardSlice.reducer;
