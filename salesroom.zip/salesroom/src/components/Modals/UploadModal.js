import React, { useContext, useState } from "react";
import modalContext from "./ModalContext";
import { useNavigate } from "react-router-dom";
const UploadModal = () => {
  const { showModal, setShowModal, setUploadModal, dropdownItem } =
    useContext(modalContext);
  const [loadImage, setLoadImage] = useState("");
  const navigate = useNavigate();
  const handleUpload = (e) => {
    const reader = new FileReader();
    reader.onload = () => {
      setLoadImage(reader.result);
    };
    reader.readAsDataURL(e.target.files[0]);
  };
  const handleDone = () => {
    if (dropdownItem === "Manual") {
      navigate("/dashboard/manuals");
    }
    if (dropdownItem === "Catalogue") {
      navigate("/dashboard/catalogues");
    }
    if (dropdownItem === "CAD drawings") {
      navigate("/dashboard/cadFiles");
    }
    if (dropdownItem === "Videos") {
      navigate("/dashboard/videos");
    }
    setUploadModal(false);
    setShowModal(false);
  };
  const handleCencle = () => {
    setShowModal(false);
    setUploadModal(false);
  };
  return (
    <>
      {showModal && (
        <div className="w-[70vw] bg-white border-2 border-gray-400">
          {/*header*/}
          <div className="flex items-start justify-center p-5">
            <h3 className="text-2xl text-center">Choose file to upload</h3>
          </div>

          {/* body */}
          <div className="relative p-6 flex-auto h-[50vh]">
            {loadImage ? (
              <img src={loadImage} className="w-full h-full" alt="" />
            ) : null}
          </div>

          {/*footer*/}
          <div className="flex items-center justify-end p-6 border-t border-solid border-slate-200 rounded-b">
            <button
              className="modal-cancle-btn"
              type="button"
              onClick={handleCencle}
            >
              Cancle
            </button>
            {loadImage ? (
              <button className="modal-done-btn" onClick={handleDone}>
                Done
              </button>
            ) : (
              <label for="imageUpload" role="button" className="modal-done-btn">
                Upload
              </label>
            )}
            <input
              type="file"
              id="imageUpload"
              accept="image/*"
              onChange={handleUpload}
              hidden
            ></input>
          </div>
        </div>
      )}
    </>
  );
};

export default UploadModal;
