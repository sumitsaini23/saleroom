import React from "react";
import { Navigate, Route } from "react-router-dom";

const AuthRoute = (props) => {
  const token = window.localStorage.getItem("token");
  const { type, children } = props;
  if (type === "guest" && token) return <Navigate to="/dashboard" />;
  else if (type === "private" && !token) return <Navigate to="/" />;
  else if (type === "private" && token) return children;
  else return children;
  // if (type === "guest" && token) return <Navigate to="/dashboard" />;
  // else if (type === "private" && !token) return <Navigate to="/" />;
  // else if (type === "private" && token) return children;
  //return <Navigate to="/login" />;

  // else if (type === "private" && !token) return <Navigate to="/" />;
  // return <Route {...props} />;
};

export default AuthRoute;
