import React, { useState } from "react";
import IconButton from "@mui/material/IconButton";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
//import { styled, alpha } from "@mui/material/styles";
import DownloadIcon from "@mui/icons-material/Download";

export default function FileMenu(props) {
  const [anchorEl_file, setAnchorEl_file] = useState(null);
  const openFileMenu = Boolean(anchorEl_file);

  const handleMenuClick = (event) => {
    setAnchorEl_file(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl_file(null);
  };

  return (
    <>
      <IconButton
        aria-label="more"
        id="long-button"
        aria-controls={openFileMenu ? "long-menu" : undefined}
        aria-expanded={openFileMenu ? "true" : undefined}
        aria-haspopup="true"
        onClick={handleMenuClick}
      >
        <MoreVertIcon />
      </IconButton>
      <Menu
        id="basic-menu"
        anchorEl={anchorEl_file}
        open={openFileMenu}
        onClose={handleMenuClose}
        MenuListProps={{
          "aria-labelledby": "basic-button",
        }}
      >
        <MenuItem>
          <a href={props.url} download>
            <DownloadIcon /> Download
          </a>
        </MenuItem>
      </Menu>
    </>
  );
}
