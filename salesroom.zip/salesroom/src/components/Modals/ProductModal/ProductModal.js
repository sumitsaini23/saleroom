import React, { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useForm, Controller } from "react-hook-form";
import { useNavigate, useLocation } from "react-router-dom";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import Swal from "sweetalert2";
import MenuItem from "@mui/material/MenuItem";
import TextField from "@mui/material/TextField";

import ModalWrapper from "../../UI/ModalWrapper";
import ReactHookFormSelect from "../../UI/ReactHookFormSelect";
import { hideModal } from "../../../reducers/modalSlice";
import { startLoader, stopLoader } from "../../../reducers/commonSlice";
import {
  getProductByCategoryId,
  getAllProducts,
} from "../../../reducers/productSlice";
import requestsApi from "../../../app/requestsApi";
import doneicn from "../../../assets/images/icon/doneicn.gif";

const schema = Yup.object({
  categoryId: Yup.string().required("Required"),
  productName: Yup.string().required("Required"),
}).required();

export default function ProductModal() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const cId = useSelector((state) => state.modalView.product.categoryId);
  const cName = location.state?.categoryName
    ? location.state?.categoryName
    : "";
  const [categoryId, setcategoryId] = useState(cId);
  const [categoryName, setcategoryName] = useState(cName);
  const showModal = useSelector((state) => state.modalView.showModal);
  const heading = useSelector((state) => state.modalView.heading);
  let productName = useSelector((state) => state.modalView.product.productName);
  const businessId = useSelector((state) => state.auth?.user?.businessId);
  const productId = useSelector((state) => state.modalView.product.productId);
  const categories = useSelector((state) => state.categories.categories);

  /**
   * Form
   */
  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
  });

  const onSaveProduct = (data) => {
    productName = data.productName;
    dispatch(startLoader());
    reset();
    dispatch(hideModal());

    if (heading !== "Edit") {
      dispatch(stopLoader());
      navigate("/addProduct", {
        state: {
          categoryId: categoryId,
          categoryName: categoryName,
          productName: productName,
        },
      });
      // setTimeout(() => {
      //     dispatch(stopLoader());
      //     navigate("/addProduct", {
      //         state: {
      //             categoryId: categoryId,
      //             //categoryName: categoryName,
      //             productName: productName,
      //         },
      //     });
      // }, 1000);
    } else {
      updateProductName();
    }
  };
  /**
   * Update product name
   */
  const updateProductName = async () => {
    await requestsApi
      .putRequest("/v1/products", {
        categoryId: categoryId,
        productId: productId,
        productName: productName,
      })
      .then(function (_response) {
        reset();
        dispatch(hideModal());
        Swal.fire({
          title: "Product successfully renamed",
          imageUrl: doneicn,
          imageWidth:"100",
          showConfirmButton: false,
          timer: 2000,
        });
        if (location.pathname === "/dashboard") {
          dispatch(getAllProducts({ businessId, offset: 0 }));
        } else {
          dispatch(getProductByCategoryId({ categoryId }));
        }
      })
      .catch(function (error) {
        // console.log("error", error);
      })
      .then(function () {
        // always executed
        dispatch(stopLoader());
        //// console.log("always executed");
      });
  };

  const getSeletedItem = (categoryItem) => {
    setcategoryId(categoryItem.categoryId);
    setcategoryName(categoryItem.categoryName);
  };

  return (
    <ModalWrapper
      heading={`${heading} Product`}
      isPopUpShow={showModal}
      size="sm"
      toggleModel={() => dispatch(hideModal())}
      saveBtnTitle="Done"
      onsubmit={handleSubmit(onSaveProduct)}
    >
      <>
        <div className="relative p-6 flex-auto">
          <ReactHookFormSelect
            id="category-select"
            name="categoryId"
            label="Select Category *"
            control={control}
            defaultValue={categoryId}
            fullWidth
            variant="standard"
            disabled={cId ? true : false}
          >
            <MenuItem value="">
              <em>None</em>
            </MenuItem>
            {categories.map((category) => (
              <MenuItem
                key={category.categoryId}
                value={category.categoryId}
                onClick={() => getSeletedItem(category)}
              >
                {category.categoryName}
              </MenuItem>
            ))}
          </ReactHookFormSelect>
          {errors.categoryId && errors.categoryId.type === "required" && (
            <span className={"error__feedback"}>
              {errors.categoryId.message}
            </span>
          )}
        </div>
        <div className="relative p-6 flex-auto">
          <Controller
            name="productName"
            control={control}
            defaultValue={productName}
            render={({ field, formState }) => (
              <TextField
                fullWidth
                id="productName"
                label="Enter Product Name *"
                variant="standard"
                {...field}
                error={!!formState.errors?.productName}
              />
            )}
          />
          {errors.productName && errors.productName.type === "required" && (
            <span className={"error__feedback"}>
              {errors.productName.message}
            </span>
          )}
        </div>
      </>
    </ModalWrapper>
  );
}
