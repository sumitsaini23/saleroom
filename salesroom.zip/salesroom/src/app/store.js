import { configureStore } from "@reduxjs/toolkit";
import { combineReducers } from "redux";
// import { connectRouter, routerMiddleware } from 'connected-react-router';

//import authReducer from '../features/auth/authSlice';
import commanReducer from "../reducers/commonSlice";
import productsReducer from "../reducers/productSlice";
import categoryReducer from "../reducers/categorySlice";
import authReducer from "../reducers/authSlice";
import modalReducer from "../reducers/modalSlice";
import { localStorageMiddleware } from "./middleware";

const rootReducer = combineReducers({
  products: productsReducer,
  categories: categoryReducer,
  common: commanReducer,
  modalView: modalReducer,
  auth: authReducer,
  //articleList: articlesReducer,
  // router: connectRouter(history),
});

function configureAppStore(preloadedState) {
  return configureStore({
    reducer: rootReducer,
    devTools: true,
    preloadedState,
    middleware: (getDefaultMiddleware) => [
      ...getDefaultMiddleware(),
      //routerMiddleware(history),
      localStorageMiddleware,
    ],
  });
  // if (process.env.NODE_ENV !== "production" && module.hot) {
  //     module.hot.accept(rootReducer, () => store.replaceReducer(rootReducer));
  // }
}

const store = configureAppStore();
export default store;
