import React, { useContext } from "react";
import modalContext from "../ModalContext";
const ProductModalContent = () => {
  const { setShowModal, setModalContent, setCreateNewCategory } =
    useContext(modalContext);
  const handleCreateCategory = () => {
    setCreateNewCategory(true);
  };

  const handleDone = () => {
    setModalContent(false);
  };
  const handleCencle = () => {
    setShowModal(false);
  };
  return (
    <>
      {/*header*/}
      <div className="flex items-start justify-center p-5">
        <h3 className="text-3xl font-semibold text-center">Select Category</h3>
      </div>
      {/*body*/}
      <div className="relative p-6 flex-auto">
        <div>
          <select className="bg-gray-50 border border-black text-gray-900 text-sm focus:outline-none block w-[400px] p-2.5 mb-3">
            <option value="CAPA">CAPA</option>
            <option value="CUPA">CUPA</option>
            <option value="BI-PAP">BI-PAP</option>
          </select>
          <span
            className="text-primary font-semibold cursor-pointer"
            onClick={handleCreateCategory}
          >
            Create new category
          </span>
        </div>
      </div>
      {/*footer*/}
      <div className="flex items-center justify-end p-6 border-t border-solid border-slate-200 rounded-b">
        <button
          className="modal-cancle-btn"
          type="button"
          onClick={handleCencle}
        >
          Cancle
        </button>
        <button className="modal-done-btn" type="button" onClick={handleDone}>
          Done
        </button>
      </div>
    </>
  );
};

export default ProductModalContent;
