import React, { useEffect } from "react";
import { useForm, Controller } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import { Button, TextField } from "@mui/material";
import Loader from "../../components/Loader";

import { Status } from "../../common/utility";

import {
  nextStep,
  previousStep,
  createBusiness,
  createUser,
  changeStatus,
} from "../../reducers/authSlice";
const NameYourRoom = () => {
  const status = useSelector((state) => state.auth.status);
  const email = useSelector((state) => state.auth.signUp.email);
  const userId = useSelector((state) => state.auth.signUp.userId);
  const businessId = useSelector((state) => state.auth.signUp.businessId);
  const businessName = useSelector((state) => state.auth.signUp.businessName);
  const password = useSelector((state) => state.auth.signUp.password);
  const [Isloading, setLoading] = React.useState(false);
  const dispatch = useDispatch();

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm();

  useEffect(() => {
    if (status === Status.SUCCESS && businessId !== "" && userId === "") {
      dispatch(changeStatus);
      let reqObj = {
        businessId: businessId,
        email: email,
        fullName: "",
        password: password,
        role: "SUPER_ADMIN",
      };
      //// console.log("reqobj", reqObj);
      dispatch(createUser({ reqObj }));
    }
    if (status === Status.SUCCESS && userId !== "") {
      dispatch(changeStatus);
      setLoading(false);
      dispatch(
        nextStep(5) // update formStage
      );
      // setTimeout(() => {
      //     dispatch(
      //         nextStep(5) // update formStage
      //     );
      // }, 1000);
    } else {
      setLoading(false);
    }
    if (businessName !== "") {
      reset({
        roomName: businessName,
      });
    }
  }, [
    dispatch,
    reset,
    businessId,
    userId,
    email,
    password,
    status,
    businessName,
  ]);

  const onSubmit = async (data) => {
    setLoading(true);
    let bizName = data.roomName;
    await dispatch(createBusiness({ email, bizName }));
    // reset();
  };

  return (
    <form>
      <div className="header mb-0">
        <h2 className="text-[26px] font-medium mb-0">Name your room</h2>
        <p className="text-gray-500 text-lg  font-medium">
          Store, create and share - all in one room
        </p>
      </div>
      <div className="grid grid-cols-4 gap-3">
        <div className="body col-span-4 pt-5">
          <h5>Room name</h5>
          <div>
            <Controller
              name="roomName"
              control={control}
              defaultValue=""
              rules={{ required: true }}
              render={({ field, formState }) => (
                <TextField
                  fullWidth
                  id="roomName"
                  label="Enter your company name *"
                  variant="standard"
                  {...field}
                  error={!!formState.errors?.roomName}
                  inputProps={{
                    maxLength: 50,
                  }}
                />
              )}
            />
            {errors.roomName && errors.roomName.type === "required" && (
              <span className={"error__feedback"}>Required*</span>
            )}
          </div>
          <div
            className={"form__item button__items d-flex justify-content-end"}
          ></div>
        </div>
        <div className="footer col-span-4 flex justify-between mb-5">
          {/* <div></div> */}
          <Button
            style={{ marginRight: "1rem" }}
            type="button"
            className="btnoutline"
            onClick={() =>
              dispatch(
                previousStep() // update formStage
              )
            }
          >
            Back
          </Button>
          <Button
            type="submit"
            className="btn-blue"
            onClick={handleSubmit(onSubmit)}
            // onClick={() => next()}
          >
            {Isloading ? <Loader isLoading={Isloading} /> : "Next"}
          </Button>
        </div>
      </div>
    </form>
  );
};

export default NameYourRoom;
