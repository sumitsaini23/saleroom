import React, { useState, useEffect, useRef } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import axios from "axios";
import Swal from "sweetalert2";
import DeleteIcon from "@mui/icons-material/Delete";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableRow from "@mui/material/TableRow";
import Checkbox from "@mui/material/Checkbox";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import FilterAltIcon from "@mui/icons-material/FilterAlt";

import { contactTypesData } from "../../common/constants";
import { emailPattern, firstLetterCapitalize } from "../../common/utility";
import Breadcrumb from "../../components/Breadcrumb/Breadcrumb";
import ModalWrapper from "../../components/UI/ModalWrapper";
import PaginationCmp from "../../components/PaginationCmp";
import EnhancedTableHead from "./EnhancedTableHead";

import { startLoader, stopLoader } from "../../reducers/commonSlice";
import requestsApi from "../../app/requestsApi";
import {
    Button,
    FormControl,
    FormControlLabel,
    FormLabel,
    Radio,
    RadioGroup,
    TextField,
} from "@mui/material";
import doneicn from "../../assets/images/icon/doneicn.gif";

const validateDealerSchema = {
    companyName: Yup.string().required("Required"),
    fullName: Yup.string().required("Required"),
    primaryPhone: Yup.number().required("Required"),
    primaryEmail: Yup.string()
        .required("Required")
        .matches(emailPattern, "Invalid emailId"),
    state: Yup.string().required("Required"),
    city: Yup.string().required("Required"),
    pincode: Yup.string()
        .required("Required")
        .matches(/^[0-9]+$/, "Must be only digits")
        .min(6, "Must be exactly 6 digits")
        .max(6, "Must be exactly 6 digits"),
    address: Yup.string().required("Required"),
};

const Contact = () => {
    const dispatch = useDispatch();
    const ref = useRef();
    const [anchorEl, setAnchorEl] = React.useState(null);
    const openFilterToggle = Boolean(anchorEl);
    const [selectedFilter, setSelectedFilter] = React.useState(
        contactTypesData.CUSTOMER
    );
    const [showModal, setShowModal] = useState(false);
    const [contactsList, setContactsList] = useState([]);
    const [contactsIdArray, setContactsIdArray] = useState([]);
    const [contactType, setContactType] = useState(contactTypesData.CUSTOMER);
    const [page, setPage] = useState(1);
    const businessId = useSelector((state) => state.auth?.user?.businessId);
    const userRole = useSelector((state) => state.auth?.user?.role);

    const {
        control,
        handleSubmit,
        reset,
        formState: { errors },
    } = useForm({
        resolver: yupResolver(
            contactType === contactTypesData.DISTRIBUTOR
                ? Yup.object(validateDealerSchema).required()
                : Yup.object({
                      ...validateDealerSchema,
                      contactPerson: Yup.string().required("Required"),
                      designation: Yup.string().required("Required"),
                  }).required()
        ),
    });

    /**
     * Component will mount
     */
    useEffect(() => {
        getAllContactByBusinessId(contactTypesData.CUSTOMER, 0);
    }, [businessId]);
    /**
     * component will unmount
     */

    useEffect(() => {
        return () => {
            setContactsList([]);
        };
    }, []);

    /**
     * get all contact
     */

    const getAllContactByBusinessId = async (customerType, offset) => {
        /**
         * Contact Api
         * http://api-qa.salesroom.in/v1/dashboard/contacts
         *   ?businessId=1880ee89-4804-4cad-92c0-6f9675a212ab&direction=DESC&offset=0&size=12&sortBy=createdOn&type=CUSTOMER
         */
        if (businessId) {
            await requestsApi
                .getRequest(`/v1/dashboard/contacts/`, {
                    businessId: businessId,
                    direction: "DESC",
                    offset: offset,
                    size: "12",
                    sortBy: "createdOn",
                    type: customerType,
                })
                .then(function (response) {
                    //// console.log("response.content", response.content);
                    setContactsList(response);
                })
                .catch(function (error) {
                    // console.log("error", error);
                });
        }
    };
    /**
     * Save Contact
     */
    const onSaveContact = async (data) => {
        dispatch(startLoader());
        let postData = {
            address: {
                addressLine1: data.address,
                addressLine2: "",
                city: data.city,
                country: data.country,
                district: "",
                landmark: "",
                pincode: data.pincode,
                state: data.state,
            },
            businessId: businessId,
            companyName: data.companyName,
            designation: data.designation,
            email: data.primaryEmail,
            fullName: data.fullName,
            primaryPhone: data.primaryPhone,
            secondaryPhone: data.secondaryPhone,
            type: contactType,
        };

        //// console.log("postData", postData);
        await requestsApi
            .postRequest("/v1/dashboard/contacts", postData)
            .then(function (response) {
                reset();
                handleModal();
                getAllContactByBusinessId(selectedFilter);
                Swal.fire({
                    title: "Contact added successfully",
                    imageUrl: doneicn,
                    imageWidth:"100",
                    showConfirmButton: false,
                    timer: 2000,
                });
            })
            .catch(function (error) {
                // console.log("error", error);
            })
            .then(function () {
                // always executed
                dispatch(stopLoader());
                //// console.log("always executed");
            });
    };

    const handleModal = () => {
        setShowModal(!showModal);
    };

    const handleFilterToggleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };
    const handleFilterToggleClose = () => {
        setAnchorEl(null);
    };

    const handleMenuItemClick = (event, val) => {
        setSelectedFilter(val);
        setAnchorEl(null);
        getAllContactByBusinessId(val);
    };

    const handleImportModal = () => {
        ref.current.click();
    };

    // Dropzone
    // const getUploadParams = ({ meta }) => {
    //     return { url: "https://httpbin.org/post" };
    // };

    const columns = [
        {
            id: "companyName",
            label: "Company Name",
            numeric: false,
            disablePadding: true,
        },
        {
            id: "fullName",
            label: "Name",
            numeric: false,
            disablePadding: true,
        },
        {
            id: "email",
            label: "Email",
            numeric: false,
            disablePadding: true,
        },
        {
            id: "designation",
            label: "Designation",
            width: 230,
            numeric: false,
            disablePadding: true,
        },
        {
            id: "primaryPhone",
            label: "Phone",
            width: 200,
            numeric: false,
            disablePadding: true,
        },
        {
            id: "city",
            label: "City",
            width: 180,
            numeric: false,
            disablePadding: true,
        },
    ];

    const CustomerForm = () => {
        return (
            <>
                <div className="col-span-4">
                    <Controller
                        name="companyName"
                        control={control}
                        defaultValue=""
                        render={({ field, formState }) => (
                            <TextField
                                fullWidth
                                id="companyName"
                                label="Company Name *"
                                variant="standard"
                                {...field}
                                error={!!formState.errors?.companyName}
                            />
                        )}
                    />
                    {errors.companyName &&
                        errors.companyName.type === "required" && (
                            <span className={"error__feedback"}>
                                {errors.companyName.message}
                            </span>
                        )}
                </div>
                {/* 2 */}
                <div className="col-span-4">
                    <Controller
                        name="contactPerson"
                        control={control}
                        defaultValue=""
                        render={({ field, formState }) => (
                            <TextField
                                fullWidth
                                id="contactPerson"
                                label="Contact Person *"
                                variant="standard"
                                {...field}
                                error={!!formState.errors?.contactPerson}
                            />
                        )}
                    />
                    {errors.contactPerson &&
                        errors.contactPerson.type === "required" && (
                            <span className={"error__feedback"}>
                                {errors.contactPerson.message}
                            </span>
                        )}
                </div>
                {/* 3 */}
                <div className="col-span-4">
                    <Controller
                        name="designation"
                        control={control}
                        defaultValue=""
                        render={({ field, formState }) => (
                            <TextField
                                fullWidth
                                id="designation"
                                label="Designation *"
                                variant="standard"
                                {...field}
                                error={!!formState.errors?.designation}
                            />
                        )}
                    />
                    {errors.designation &&
                        errors.designation.type === "required" && (
                            <span className={"error__feedback"}>
                                {errors.designation.message}
                            </span>
                        )}
                </div>
            </>
        );
    };

    const DealerForm = () => {
        return (
            <div className="col-span-4">
                <Controller
                    name="companyName"
                    control={control}
                    defaultValue=""
                    render={({ field, formState }) => (
                        <TextField
                            fullWidth
                            id="companyName"
                            label="Dealer Name *"
                            variant="standard"
                            {...field}
                            error={!!formState.errors?.companyName}
                        />
                    )}
                />
                {errors.companyName &&
                    errors.companyName.type === "required" && (
                        <span className={"error__feedback"}>
                            {errors.companyName.message}
                        </span>
                    )}
            </div>
        );
    };

    const onFileChange = async (event) => {
        let file = event.target.files[0];
        let allowedExtensions = /(\.XLS|\.XLSX|\.xls|\.xlsx|\.CSV|\.csv)$/i;
        if (file && allowedExtensions.exec(file.name)) {
            let formData = new FormData();
            formData.append("businessId", businessId);
            formData.append("file", file);
            formData.append("fileName", file.name);
            const token = localStorage.getItem("token");
            const config = {
                headers: {
                    "Access-Control-Allow-Origin": "*",
                    "content-type": "multipart/form-data",
                    Authorization: `Bearer ${token}`,
                },
            };
            let postData = formData;
            let requrl = `${process.env.REACT_APP_API_BASE_URL}/v1/dashboard/contacts/import`;
            await axios
                .post(requrl, postData, config)
                .then(function (response) {
                    Swal.fire({
                        title: " Contacts imported from file",
                        imageUrl: doneicn,
                        imageWidth:"100",
                        showConfirmButton: false,
                        timer: 2000,
                    });
                    //// console.log("response", response);
                })
                .catch(function (error) {
                    // console.log("error_upload", error);
                });
        } else {
            Swal.fire({
                title: "File format not allowed",
                icon: "error",
                showConfirmButton: false,
                timer: 2000,
            });
        }
    };

    const confirmDeleteContacts = () => {
        if (contactsIdArray && contactsIdArray.length > 0) {
            Swal.fire({
                title: "Are you sure?",
                text: "Want to change access level",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#174FBA",
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes, do it!",
            }).then((result) => {
                if (result.isConfirmed) {
                    deleteContacts();
                }
            });
        } else {
            Swal.fire({
                title: "Please select contact",
                icon: "error",
                showConfirmButton: false,
                timer: 2000,
            });
        }
    };

    const deleteContacts = async () => {
        await requestsApi
            .mutipleDeleteRequest(`/v1/dashboard/contacts/`, {
                contactIds: contactsIdArray,
            })
            .then(function (response) {
                let msg = contactsIdArray.length > 1 ? "Contacts" : "Contact";
                setContactsIdArray([]);
                getAllContactByBusinessId(contactType,  0);
                Swal.fire({
                    title: `${msg} deleted from the list`,
                    imageUrl: doneicn,
                    imageWidth:"100",
                    showConfirmButton: false,
                    timer: 2000,
                });
            })
            .catch(function (error) {
                // console.log("error", error);
            });
    };

    const handleSelectAllClick = (event) => {
        if (event.target.checked) {
            const newSelecteds = contactsList.content.map((c) => c.id);
            setContactsIdArray(newSelecteds);
            return;
        }
        setContactsIdArray([]);
    };

    const handleClick = (event, id) => {
        const selectedIndex = contactsIdArray.indexOf(id);
        let newSelected = [];

        if (selectedIndex === -1) {
            newSelected = newSelected.concat(contactsIdArray, id);
        } else if (selectedIndex === 0) {
            newSelected = newSelected.concat(contactsIdArray.slice(1));
        } else if (selectedIndex === contactsIdArray.length - 1) {
            newSelected = newSelected.concat(contactsIdArray.slice(0, -1));
        } else if (selectedIndex > 0) {
            newSelected = newSelected.concat(
                contactsIdArray.slice(0, selectedIndex),
                contactsIdArray.slice(selectedIndex + 1)
            );
        }
        setContactsIdArray(newSelected);
    };

    const handleChangePage = (event, newPage) => {
        setPage(newPage - 1);
        getAllContactByBusinessId(contactType, newPage - 1);
    };

    const isSelected = (id) => contactsIdArray.indexOf(id) !== -1;

    return (
        <>
            <Breadcrumb />
            <div className="pt-6 mb-0">
                <div className="mb-0">
                    <h2 className="text-3xl font-bold mb-1">
                        Contacts{" "}
                        {contactsList
                            ? `(${contactsList?.content?.length})`
                            : null}
                    </h2>
                    {/* <h2 className="text-lg">2 contact</h2> */}
                </div>
            </div>

            <div className="btnclr">
                <Button
                    id="basic-button"
                    aria-controls={openFilterToggle ? "basic-menu" : undefined}
                    aria-haspopup="true"
                    aria-expanded={openFilterToggle ? "true" : undefined}
                    className="btnoutline"
                    // variant="contained"
                    onClick={handleFilterToggleClick}
                >
                    <span>{firstLetterCapitalize(selectedFilter)}</span>
                    <FilterAltIcon />
                </Button>
                <Menu
                    id="basic-menu"
                    anchorEl={anchorEl}
                    open={openFilterToggle}
                    onClose={handleFilterToggleClose}
                    MenuListProps={{
                        "aria-labelledby": "basic-button",
                    }}
                >
                    <MenuItem
                        selected={contactTypesData.CUSTOMER === selectedFilter}
                        onClick={(event) =>
                            handleMenuItemClick(
                                event,
                                contactTypesData.CUSTOMER
                            )
                        }
                    >
                        Customer
                    </MenuItem>
                    <MenuItem
                        selected={contactTypesData.LEAD === selectedFilter}
                        onClick={(event) =>
                            handleMenuItemClick(event, contactTypesData.LEAD)
                        }
                    >
                        Lead
                    </MenuItem>
                    <MenuItem
                        selected={
                            contactTypesData.DISTRIBUTOR === selectedFilter
                        }
                        onClick={(event) =>
                            handleMenuItemClick(
                                event,
                                contactTypesData.DISTRIBUTOR
                            )
                        }
                    >
                        Distributor
                    </MenuItem>
                </Menu>
                <Button
                    className="btn-black"
                    variant="contained"
                    onClick={handleImportModal}
                >
                    <input
                        ref={ref}
                        type="file"
                        id="imageUpload"
                        accept="XLS/*,XLSX/*,xls/*,xlsx/*,CSV/*,csv/*"
                        onChange={onFileChange}
                        style={{ display: "none" }}
                    ></input>
                    Import Contact
                </Button>
                <Button
                    className="btn-blue"
                    variant="contained"
                    onClick={handleModal}
                >
                    Add Contact
                </Button>
                {userRole === "SUPER_ADMIN" || userRole === "ADMIN" ? (
                    <div className="dlticn">
                        <Button onClick={confirmDeleteContacts}>
                            <DeleteIcon />
                        </Button>
                    </div>
                ) : null}
            </div>

            <div style={{ height: 400, width: "100%", background: "#fff" }}>
                <TableContainer>
                    <Table
                        sx={{ minWidth: 750 }}
                        aria-labelledby="tableTitle"
                        size={"medium"}
                    >
                        <EnhancedTableHead
                            headCells={columns}
                            numSelected={contactsIdArray.length}
                            onSelectAllClick={handleSelectAllClick}
                            rowCount={
                                contactsList &&
                                contactsList.hasOwnProperty("content")
                                    ? contactsList.content.length
                                    : 0
                            }
                        />
                        <TableBody>
                            {(contactsList.content || []).map((row, index) => {
                                const isItemSelected = isSelected(row.id);
                                const labelId = `enhanced-table-checkbox-${index}`;
                                return (
                                    <TableRow
                                        hover
                                        onClick={(event) =>
                                            handleClick(event, row.id)
                                        }
                                        role="checkbox"
                                        aria-checked={isItemSelected}
                                        tabIndex={-1}
                                        key={row.id}
                                        selected={isItemSelected}
                                    >
                                        <TableCell padding="checkbox">
                                            <Checkbox
                                                sx={{
                                                    color: "#174fba",
                                                    "&.Mui-checked": {
                                                        color: "#174fba",
                                                    },
                                                }}
                                                checked={isItemSelected}
                                                inputProps={{
                                                    "aria-labelledby": labelId,
                                                }}
                                            />
                                        </TableCell>
                                        <TableCell align="center">
                                            {row.companyName}
                                        </TableCell>
                                        <TableCell align="center">
                                            {row.fullName}
                                        </TableCell>
                                        <TableCell align="center">
                                            {row.email}
                                        </TableCell>
                                        <TableCell align="center">
                                            {row.designation}
                                        </TableCell>
                                        <TableCell align="center">
                                            {row.primaryPhone}
                                        </TableCell>
                                        <TableCell align="center">
                                            {row.address.city}
                                        </TableCell>
                                    </TableRow>
                                );
                            })}
                            {contactsList?.content?.length === 0 && (
                                <TableRow key={"emptyrow"}>
                                    <TableCell colSpan={7} align="center">
                                        No contacts avaialble
                                    </TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                    {contactsList?.content?.length > 0 && (
                        <div style={{ float: "right", marginTop: "20px" }}>
                            <PaginationCmp
                                count={
                                    contactsList &&
                                    contactsList.hasOwnProperty("totalPages")
                                        ? contactsList.totalPages
                                        : 1
                                }
                                defaultPage={1}
                                siblingCount={0}
                                handlePageChange={handleChangePage}
                                style={{ align: "right" }}
                            />
                        </div>
                    )}
                </TableContainer>
            </div>

            <div style={{ width: "800px" }}>
                <ModalWrapper
                    heading="New Contact"
                    isPopUpShow={showModal}
                    size="md"
                    // width="800px"
                    toggleModel={handleModal}
                    saveBtnTitle="Done"
                    onsubmit={handleSubmit(onSaveContact)}
                >
                    <>
                        <div>
                            {" "}
                            <FormControl>
                                <FormLabel id="demo-row-radio-buttons-group-label">
                                    This contact is a/from …
                                </FormLabel>
                                <RadioGroup
                                    row
                                    aria-labelledby="demo-row-radio-buttons-group-label"
                                    name="row-radio-buttons-group"
                                    defaultValue={contactType}
                                >
                                    <FormControlLabel
                                        value={contactTypesData.CUSTOMER}
                                        onClick={() =>
                                            setContactType(
                                                contactTypesData.CUSTOMER
                                            )
                                        }
                                        control={<Radio />}
                                        label="Customer"
                                    />
                                    <FormControlLabel
                                        value={contactTypesData.LEAD}
                                        onClick={() =>
                                            setContactType(
                                                contactTypesData.LEAD
                                            )
                                        }
                                        control={<Radio />}
                                        label="Lead"
                                    />
                                    <FormControlLabel
                                        value={contactTypesData.DISTRIBUTOR}
                                        onClick={() =>
                                            setContactType(
                                                contactTypesData.DISTRIBUTOR
                                            )
                                        }
                                        control={<Radio />}
                                        label="Dealer"
                                    />
                                </RadioGroup>
                            </FormControl>
                        </div>
                        {/**
                         * Form
                         */}
                        <div className="body">
                            <div className="grid grid-cols-6 gap-5">
                                {contactType === contactTypesData.CUSTOMER ||
                                contactType === contactTypesData.LEAD ? (
                                    <CustomerForm />
                                ) : (
                                    <DealerForm />
                                )}
                                <div className="col-span-4">
                                    <Controller
                                        name="fullName"
                                        control={control}
                                        defaultValue=""
                                        render={({ field, formState }) => (
                                            <TextField
                                                fullWidth
                                                id="fullName"
                                                label="Name *"
                                                variant="standard"
                                                {...field}
                                                error={
                                                    !!formState.errors?.fullName
                                                }
                                            />
                                        )}
                                    />
                                    {errors.fullName &&
                                        errors.fullName.type === "required" && (
                                            <span className={"error__feedback"}>
                                                {errors.fullName.message}
                                            </span>
                                        )}
                                </div>
                                <div className="col-span-4">
                                    <Controller
                                        name="primaryPhone"
                                        control={control}
                                        defaultValue=""
                                        render={({ field, formState }) => (
                                            <TextField
                                                fullWidth
                                                id="primaryPhone"
                                                label="Primary Phone Number *"
                                                variant="standard"
                                                {...field}
                                                inputProps={{ maxLength: 15 }}
                                                error={
                                                    !!formState.errors
                                                        ?.primaryPhone
                                                }
                                            />
                                        )}
                                    />
                                    {errors.primaryPhone &&
                                        errors.primaryPhone.type ===
                                            "required" && (
                                            <span className={"error__feedback"}>
                                                {errors.primaryPhone.message}
                                            </span>
                                        )}
                                    {errors.primaryPhone &&
                                        errors.primaryPhone.type ===
                                            "typeError" && (
                                            <span className={"error__feedback"}>
                                                Phone must be a number type
                                            </span>
                                        )}
                                </div>
                                <div className="col-span-4">
                                    <Controller
                                        name="secondaryPhone"
                                        control={control}
                                        defaultValue=""
                                        render={({ field, formState }) => (
                                            <TextField
                                                fullWidth
                                                id="secondaryPhone"
                                                label="Secondary Phone Number"
                                                variant="standard"
                                                {...field}
                                                error={
                                                    !!formState.errors
                                                        ?.secondaryPhone
                                                }
                                            />
                                        )}
                                    />
                                    {errors.secondaryPhone &&
                                        errors.secondaryPhone.type ===
                                            "required" && (
                                            <span className={"error__feedback"}>
                                                {errors.secondaryPhone.message}
                                            </span>
                                        )}
                                </div>

                                {/* 5 */}
                                <div className="col-span-4">
                                    <Controller
                                        name="primaryEmail"
                                        control={control}
                                        defaultValue=""
                                        render={({ field, formState }) => (
                                            <TextField
                                                fullWidth
                                                id="primaryEmail"
                                                label="Primary Email *"
                                                variant="standard"
                                                {...field}
                                                error={
                                                    !!formState.errors
                                                        ?.primaryEmail
                                                }
                                            />
                                        )}
                                    />
                                    {errors.primaryEmail &&
                                        errors.primaryEmail.type ===
                                            "required" && (
                                            <span className={"error__feedback"}>
                                                {errors.primaryEmail.message}
                                            </span>
                                        )}
                                </div>
                                <div className="col-span-4">
                                    <Controller
                                        name="country"
                                        control={control}
                                        defaultValue="India"
                                        render={({ field, formState }) => (
                                            <TextField
                                                fullWidth
                                                id="country"
                                                label="country *"
                                                variant="standard"
                                                //value="India"
                                                {...field}
                                                error={
                                                    !!formState.errors?.country
                                                }
                                                inputProps={{
                                                    readOnly: true,
                                                }}
                                            />
                                        )}
                                    />
                                    {errors.country &&
                                        errors.country.type === "required" && (
                                            <span className={"error__feedback"}>
                                                {errors.country.message}
                                            </span>
                                        )}
                                </div>
                                <div className="col-span-4">
                                    <Controller
                                        name="state"
                                        control={control}
                                        defaultValue=""
                                        render={({ field, formState }) => (
                                            <TextField
                                                fullWidth
                                                id="state"
                                                label="State *"
                                                variant="standard"
                                                {...field}
                                                error={
                                                    !!formState.errors?.state
                                                }
                                            />
                                        )}
                                    />
                                    {errors.state &&
                                        errors.state.type === "required" && (
                                            <span className={"error__feedback"}>
                                                {errors.state.message}
                                            </span>
                                        )}
                                </div>
                                {/* 3 */}
                                <div className="col-span-4">
                                    <Controller
                                        name="city"
                                        control={control}
                                        defaultValue=""
                                        render={({ field, formState }) => (
                                            <TextField
                                                fullWidth
                                                id="city"
                                                label="City *"
                                                variant="standard"
                                                {...field}
                                                error={!!formState.errors?.city}
                                            />
                                        )}
                                    />
                                    {errors.city &&
                                        errors.city.type === "required" && (
                                            <span className={"error__feedback"}>
                                                {errors.city.message}
                                            </span>
                                        )}
                                </div>
                                <div className="col-span-4">
                                    <Controller
                                        name="pincode"
                                        control={control}
                                        defaultValue=""
                                        render={({ field, formState }) => (
                                            <TextField
                                                fullWidth
                                                id="pincode"
                                                label="pincode *"
                                                variant="standard"
                                                {...field}
                                                inputProps={{ maxLength: 6 }}
                                                error={
                                                    !!formState.errors?.pincode
                                                }
                                            />
                                        )}
                                    />
                                    {errors.pincode &&
                                        errors.pincode.type === "required" && (
                                            <span className={"error__feedback"}>
                                                {errors.pincode.message}
                                            </span>
                                        )}
                                    {errors.pincode &&
                                        errors.pincode.type === "matches" && (
                                            <span className={"error__feedback"}>
                                                {errors.pincode.message}
                                            </span>
                                        )}
                                    {errors.pincode &&
                                        errors.pincode.type === "min" && (
                                            <span className={"error__feedback"}>
                                                {errors.pincode.message}
                                            </span>
                                        )}
                                    {errors.pincode &&
                                        errors.pincode.type === "max" && (
                                            <span className={"error__feedback"}>
                                                {errors.pincode.message}
                                            </span>
                                        )}
                                </div>
                                <div className="col-span-12">
                                    <Controller
                                        name="address"
                                        control={control}
                                        defaultValue=""
                                        render={({ field, formState }) => (
                                            <TextField
                                                fullWidth
                                                multiline
                                                maxRows={4}
                                                id="address"
                                                label="Address *"
                                                variant="standard"
                                                {...field}
                                                error={
                                                    !!formState.errors?.address
                                                }
                                            />
                                        )}
                                    />
                                    {errors.address &&
                                        errors.address.type === "required" && (
                                            <span className={"error__feedback"}>
                                                {errors.address.message}
                                            </span>
                                        )}
                                </div>
                            </div>
                        </div>
                    </>
                </ModalWrapper>
            </div>
        </>
    );
};

export default Contact;
