import React, { useEffect, useState, useRef } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useForm, Controller } from "react-hook-form";
import { Button, TextField, Alert, Stack } from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import Swal from "sweetalert2";
import { getUser, logout } from "../../reducers/authSlice";
import { startLoader, stopLoader } from "../../reducers/commonSlice";
import { getAllCategories } from "../../reducers/categorySlice";
import { getAllProducts } from "../../reducers/productSlice";
import {
    getPreSignUrlLink,
    getFileName,
    getPreSignUrlFileType,
    uploadFile,
    ToastAlert,
    getFileDetails,
} from "../../common/utility";
import {
    ALERT_INFO,
    ALERT_SUCCESS,
    imageExtension,
} from "../../common/constants";
import Breadcrumb from "../../components/Breadcrumb/Breadcrumb";
import ModalWrapper from "../../components/UI/ModalWrapper";
import Loader from "../../components/Loader";
import requestsApi from "../../app/requestsApi";
import doneicn from "../../assets/images/icon/doneicn.gif";
/**
 * Change Name from
 */
const ValidateNameSchema = Yup.object({
    fullName: Yup.string().required("Required"),
}).required();

/**
 * Password Change validation
 */
const ValidateChangePasswordSchema = Yup.object({
    oldPassword: Yup.string().required("Required"),
    newPassword: Yup.string()
        .required("Required")
        .matches(/[a-zA-Z]/, "Password can only contain Latin letters.")
        .min(8, "Min 8 charactor require")
        .max(16, "Too Long!"),
    confirmPassword: Yup.string()
        .required("Required")
        .oneOf([Yup.ref("newPassword"), null], "New Passwords must match"),
}).required();

/**
 * social Media validation
 */
const urlPattern =
    /https?:\/\/w{0,3}\w*?\.(\w*?\.)?\w{2,3}\S*|www\.(\w*?\.)?\w*?\.\w{2,3}\S*|(\w*?\.)?\w*?\.\w{2,3}[\/\?]\S*/;

const socialMediaValidateSchema = Yup.object({
    companyName: Yup.string().required("Required"),
    linkedin: Yup.string()
        .required("Required")
        .matches(urlPattern, "Invalid URL"),
    instagram: Yup.string()
        .required("Required")
        .matches(urlPattern, "Invalid URL"),
    facebook: Yup.string()
        .required("Required")
        .matches(urlPattern, "Invalid URL"),
    twitter: Yup.string()
        .required("Required")
        .matches(urlPattern, "Invalid URL"),
}).required();

const Setting = () => {
    const dispatch = useDispatch();
    const logoref = useRef();
    const userId = useSelector((state) => state.auth?.user?.userId);
    const userRole = useSelector((state) => state.auth?.user?.role);
    const businessId = useSelector((state) => state.auth?.user?.businessId);
    const fullName = useSelector((state) => state.auth?.user?.fullName);
    const email = useSelector((state) => state.auth?.user?.email);
    //const [logoImage, setLogoImage] = useState([]);
    const [showLoader, setShowLoader] = React.useState(false);
    const [showChangeNameModal, setShowChangeNamemodal] = useState(false);
    const [showResetPasswordModal, setShowResetPasswordModal] = useState(false);
    const [businessLogoUrl, setBusinessLogoUrl] = useState("");
    const [responseError, setResponseError] = useState("");
    const [openTab, setOpenTab] = React.useState("Profile");

    /**
     *  Change name from control
     */
    const {
        control: nameFormControl,
        handleSubmit: changeNameSubmit,
        reset: nameFormReset,
        formState: { errors: nameFormErrors },
    } = useForm({
        resolver: yupResolver(ValidateNameSchema),
        mode: "onTouched",
    });
    /**
     * Change Password from control
     */
    const {
        control: passwordFormControl,
        handleSubmit: handleSavePassword,
        reset: passwordFormReset,
        formState: { errors: passwordFormErrors },
    } = useForm({
        resolver: yupResolver(ValidateChangePasswordSchema),
        mode: "onTouched",
    });
    /**
     * Social media from control
     */
    const {
        control: socialFormControl,
        handleSubmit: handleSocialMedia,
        reset: resetSocialMediaForm,
        formState: { errors: socialMediaFormErrors },
    } = useForm({
        resolver: yupResolver(socialMediaValidateSchema),
        mode: "onTouched",
    });

    useEffect(() => {
        if (businessId) {
            getBusinessDetails();
            dispatch(getAllCategories({ businessId }));
            dispatch(getAllProducts({ businessId, offset: 0 }));
        }
    }, [businessId, dispatch]);

    const getBusinessDetails = () => {
        requestsApi
            .getRequest(`/v1/business/${businessId}`)
            .then(function (response) {
                setBusinessLogoUrl(response.businessLogoUrl);
                resetSocialMediaForm({
                    companyName: response.businessName,
                    linkedin: response.socialMediaInfo.linkedInUrl,
                    instagram: response.socialMediaInfo.instagramUrl,
                    facebook: response.socialMediaInfo.facebookUrl,
                    twitter: response.socialMediaInfo.twitterUrl,
                });
            })
            .catch(function (error) {
                // console.log("get business details error", error);
            });
    };

    const onFileChange = (e) => {
        if (!e || !e.target || !e.target.files || e.target.files.length === 0) {
            return;
        }
        let allowedExtensions = imageExtension;
        const fileData = e.target.files[0];
        let { ext } = getFileDetails(fileData);

        if (!allowedExtensions.includes(ext)) {
            ToastAlert({
                type: ALERT_INFO,
                msg: "Invalid file format",
            });
            return;
        }
        getPreSignUrl(fileData, "IMAGES");
    };

    const handleChangeNameModal = () => {
        nameFormReset();
        setShowChangeNamemodal(!showChangeNameModal);
    };

    const handleResetPasswordModal = () => {
        passwordFormReset();
        setShowResetPasswordModal(!showResetPasswordModal);
    };

    const handleChangeNameSubmit = (data) => {
        dispatch(startLoader());
        let postData = {
            fullName: data.fullName,
            userId: userId,
        };
        requestsApi
            .putRequest("/v1/users", postData)
            .then(function (response) {
                dispatch(getUser({ userId }));
                nameFormReset();
                handleChangeNameModal();
                Swal.fire({
                    title: "Name changed successfully",
                    imageUrl: doneicn,
		            imageWidth:"100",
                    showConfirmButton: false,
                    timer: 2000,
                });
            })
            .catch(function (error) {
                // console.log("error", error);
            })
            .then(function () {
                // always executed
                dispatch(stopLoader());
            });
    };

    const removeLogo = () => {
        Swal.fire({
            title: "Are you sure?",
            text: "Want to delete logo",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, delete it!",
        }).then((result) => {
            if (result.isConfirmed) {
                updateLogo(null);
                // setBusinessLogoUrl("");
                Swal.fire("Logo deleted successfully");
            }
        });
    };

    const savePassword = (data) => {
        dispatch(startLoader());
        let postData = {
            newPassword: data.newPassword,
            oldPassword: data.oldPassword,
            userId: userId,
        };
        requestsApi
            .postRequest("/v1/users/resetPassword", postData)
            .then(function (response) {
                handleResetPasswordModal();
                Swal.fire({
                    title: "Password changed successfully",
                    imageUrl: doneicn,
		            imageWidth:"100",
                    showConfirmButton: false,
                    timer: 2000,
                }).then((_result) => {
                    dispatch(getUser({ userId }));
                });
            })
            .catch(function (error) {
                setResponseError(error.response.data.errorMsg);
                setTimeout(() => setResponseError(""), 3000);
            })
            .then(function () {
                // always executed
                dispatch(stopLoader());
            });
    };

    const saveSocialMedia = (data) => {
        setShowLoader(true);
        let postData = {
            businessId: businessId,
            businessName: data.companyName,
            socialMediaInfo: {
                facebookUrl: data.facebook,
                instagramUrl: data.instagram,
                linkedInUrl: data.linkedin,
                twitterUrl: data.twitter,
            },
        };

        requestsApi
            .putRequest("/v1/business", postData)
            .then(function (response) {
                setShowLoader(false);
                getBusinessDetails();
                Swal.fire({
                    title: "Details Updated Successfully",
                    imageUrl: doneicn,
		            imageWidth:"100",
                    showConfirmButton: false,
                    timer: 2000,
                });
            })
            .catch(function (error) {
                setShowLoader(false);
                Swal.fire({
                    title: `${error.response.data.errorMsg}`,
                    icon: "error",
                    showConfirmButton: false,
                    timer: 3000,
                });
                // setResponseError(error.response.data.errorMsg);
                // setTimeout(() => setResponseError(""), 3000);
            });
    };

    const updateLogo = (path) => {
        let postData = {
            businessId: businessId,
            businessLogoS3Url: path,
        };
        requestsApi
            .putRequest("/v1/business", postData)
            .then(function (response) {
                getBusinessDetails();
                Swal.fire({
                    title: "Logo Updated Successfully",
                    imageUrl: doneicn,
		            imageWidth:"100",
                    showConfirmButton: false,
                    timer: 2000,
                });
            })
            .catch(function (error) {
                // console.log("Update logo", error);
            });
    };

    const confirmUploadFile = async (preSignedUrl, path, fileData) => {
        await uploadFile(preSignedUrl, fileData)
            .then(function (response) {
                if (response.status === 200) {
                    ToastAlert({
                        type: ALERT_SUCCESS,
                        msg: "File Uploaded",
                    });
                    /**
                     * Update logo on backend
                     */
                    updateLogo(path);
                }
            })
            .catch(function (error) {
                // console.log("response_upload file error", error);
            });
    };

    const getPreSignUrl = async (fileData, uploadCategory) => {
        let fileName = getFileName(fileData);
        let uploadFileType = getPreSignUrlFileType(fileName);

        await getPreSignUrlLink(
            businessId,
            fileName,
            uploadCategory,
            uploadFileType
        )
            .then(function (response) {
                let preSignedUrl = response.preSignedUrl;
                let path = response.path;
                //// console.log("path", path);
                //setBusinessLogoUrl(path);
                /**
                 * Upload file
                 */
                confirmUploadFile(preSignedUrl, path, fileData);
            })
            .catch(function (error) {
                // console.log("getPreSignUrl_error", error);
            });
    };

    return (
        <>
            <Breadcrumb />
            <div className="p-6 pb-0">
                <div className="mb-6">
                    <h2 className="text-3xl font-bold mb-1">Settings </h2>
                </div>
            </div>

            <div className="flex m-5 mt-0">
                <div className="w-full">
                    <ul
                        className="tabs-btn flex mb-0 list-none flex-wrap pt-3 pb-4 flex-row"
                        role="tablist"
                    >
                        {/* Profile tab */}
                        <li className="-mb-px mr-2 last:mr-0 text-center">
                            <a
                                className={
                                    "text-xs font-bold  px-5 py-3 shadow-lg rounded block leading-normal" +
                                    (openTab === "Profile" ? " active" : "")
                                }
                                onClick={(e) => {
                                    e.preventDefault();
                                    setOpenTab("Profile");
                                }}
                                data-toggle="tab"
                                href="#link1"
                                role="tablist"
                            >
                                Profile
                            </a>
                        </li>
                        {/* all Brandings tab */}
                        {userRole === "SUPER_ADMIN" || userRole === "ADMIN" ? (
                            <li className="-mb-px mr-2 last:mr-0 text-center">
                                <a
                                    className={
                                        "text-xs font-bold  px-5 py-3 shadow-lg rounded block leading-normal" +
                                        (openTab === "Brandings"
                                            ? " active"
                                            : "")
                                    }
                                    onClick={(e) => {
                                        e.preventDefault();
                                        setOpenTab("Brandings");
                                    }}
                                    data-toggle="tab"
                                    href="#link2"
                                    role="tablist"
                                >
                                    Branding
                                </a>
                            </li>
                        ) : null}

                        <li className="-mb-px mr-2 last:mr-0 text-center">
                            <a
                                className={
                                    "text-xs font-bold  px-5 py-3 shadow-lg rounded block leading-normal" +
                                    (openTab === "Language" ? " active" : "")
                                }
                                onClick={(e) => {
                                    e.preventDefault();
                                    setOpenTab("Language");
                                }}
                                data-toggle="tab"
                                href="#link2"
                                role="tablist"
                            >
                                Language
                            </a>
                        </li>
                        {userRole === "SUPER_ADMIN" ? (
                            <li className="-mb-px mr-2 last:mr-0 text-center">
                                <a
                                    className={
                                        "text-xs font-bold  px-5 py-3 shadow-lg rounded block leading-normal" +
                                        (openTab === "Billing" ? " active" : "")
                                    }
                                    onClick={(e) => {
                                        e.preventDefault();
                                        setOpenTab("Billing");
                                    }}
                                    data-toggle="tab"
                                    href="#link2"
                                    role="tablist"
                                >
                                    Billing
                                </a>
                            </li>
                        ) : null}
                    </ul>
                    {/* Profile tab content */}
                    <div
                        className={
                            openTab === "Profile"
                                ? "grid grid-cols-1 md:grid-cols-1 lg:grid-cols-1 xl:grid-cols-1 gap-6 mt-6"
                                : "hidden"
                        }
                        id="link1"
                    >
                        <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2 gap-5">
                            {/* 1 */}
                            <div className="col-span-1 ">
                                <div className={`form__item `}>
                                    <TextField
                                        fullWidth
                                        label="Name"
                                        name={"name"}
                                        variant="standard"
                                        value={fullName}
                                        disabled={true}
                                        inputProps={{ readOnly: true }}
                                        InputLabelProps={{ shrink: true }}
                                    />
                                    <p className={"error__feedback mb-0"}>
                                        {/* {errors.Address1} */}
                                    </p>
                                </div>
                            </div>
                            <div className="col-span-1  VerticalAlignCenter">
                                <Button onClick={handleChangeNameModal}>
                                    Change Name
                                </Button>
                            </div>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2 gap-5">
                            <div className="col-span-1  ">
                                <div className={`form__item `}>
                                    <TextField
                                        fullWidth
                                        label="Email"
                                        name={"email"}
                                        variant="standard"
                                        defaultValue={email}
                                        disabled={true}
                                        inputProps={{ readOnly: true }}
                                    />
                                    <p className={"error__feedback mb-0"}>
                                        {/* {errors.Address1} */}
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div className="grid grid-cols-4 gap-5">
                            <div className="col-span-1  ">
                                <div className={`form__item `}>
                                    {/* <p>Password</p> */}
                                </div>
                                <Button
                                    onClick={handleResetPasswordModal}
                                    variant="contained"
                                    className="md:grid-cols-2 btnbg w-52 ml-5 btn-black"
                                >
                                    Change Password
                                </Button>
                            </div>
                        </div>

                        <div className="grid grid-cols-8 gap-5">
                            <div className="col-span-4  ">
                                <div className={`clrgray form__item `}>
                                    <p>Log out of all devices</p>
                                    <p>
                                        You will be logged out of all other
                                        active sessions besides this one and
                                        will have to log back in.
                                    </p>
                                </div>
                                <Button
                                    variant="contained"
                                    className="md:grid-cols-2 w-52 ml-5 btn-gray"
                                    onClick={() => dispatch(logout())}
                                >
                                    Log Out
                                </Button>
                            </div>
                        </div>
                    </div>

                    {/* all Brandings tab content */}
                    <div
                        className={
                            openTab === "Brandings"
                                ? "grid grid-cols-1 md:grid-cols2 lg:grid-cols-2 xl:grid-cols-2 gap-2 mt-6"
                                : "hidden"
                        }
                        id="link1"
                    >
                        <div className="col-span-4">
                            <p>{/* <b>Logo</b> */}</p>
                        </div>
                        <div className="memlogo">
                            {businessLogoUrl && businessLogoUrl !== "" ? (
                                <img src={businessLogoUrl} alt="logo" />
                            ) : null}
                        </div>

                        <div className="col-span-4 editdlt">
                            <div>
                                <Button
                                    className=" edt btn-black"
                                    onClick={() => logoref.current.click()}
                                >
                                    <input
                                        ref={logoref}
                                        type="file"
                                        id="imageUpload"
                                        accept=".jpg,.jpeg,.JPG,.JPEG,.PNG,.png | image/*"
                                        onChange={onFileChange}
                                        style={{ display: "none" }}
                                    ></input>
                                    <EditIcon /> Edit
                                </Button>
                            </div>
                            <div>
                                <Button
                                    className="dlt btn-black"
                                    onClick={removeLogo}
                                >
                                    <DeleteIcon /> Delete
                                </Button>
                            </div>
                        </div>
                        <form onSubmit={handleSocialMedia(saveSocialMedia)}>
                            <p className="col-span-4 mt-5">
                                <b>Company Website</b>
                            </p>
                            <div className="col-span-2">
                                <div className={`form__item `}>
                                    <Controller
                                        name="companyName"
                                        control={socialFormControl}
                                        defaultValue=""
                                        render={({ field, formState }) => (
                                            <TextField
                                                fullWidth
                                                id="companyName"
                                                label="Company Name *"
                                                variant="standard"
                                                {...field}
                                                error={
                                                    !!formState
                                                        .socialMediaFormErrors
                                                        ?.companyName
                                                }
                                            />
                                        )}
                                    />
                                    {socialMediaFormErrors.companyName &&
                                        socialMediaFormErrors.companyName
                                            .type === "required" && (
                                            <span className={"error__feedback"}>
                                                {
                                                    socialMediaFormErrors
                                                        .companyName.message
                                                }
                                            </span>
                                        )}
                                </div>

                                <p className="mt-8">
                                    <b>Social Media</b>
                                </p>
                                <div className="col-span-1">
                                    <div className="mt-5">
                                        <Controller
                                            name="linkedin"
                                            control={socialFormControl}
                                            defaultValue=""
                                            render={({ field, formState }) => (
                                                <TextField
                                                    fullWidth
                                                    id="Linkedin"
                                                    label="Linkedin *"
                                                    variant="standard"
                                                    {...field}
                                                    error={
                                                        !!formState
                                                            .socialMediaFormErrors
                                                            ?.linkedin
                                                    }
                                                />
                                            )}
                                        />
                                        {socialMediaFormErrors.linkedin &&
                                            socialMediaFormErrors.linkedin
                                                .type === "required" && (
                                                <span
                                                    className={
                                                        "error__feedback"
                                                    }
                                                >
                                                    {
                                                        socialMediaFormErrors
                                                            .linkedin.message
                                                    }
                                                </span>
                                            )}
                                        {socialMediaFormErrors.linkedin &&
                                            socialMediaFormErrors.linkedin
                                                .type === "matches" && (
                                                <span
                                                    className={
                                                        "error__feedback"
                                                    }
                                                    style={{
                                                        paddingLeft: "13%",
                                                    }}
                                                >
                                                    {
                                                        socialMediaFormErrors
                                                            .linkedin.message
                                                    }{" "}
                                                </span>
                                            )}
                                    </div>
                                    <div className="mt-5">
                                        <Controller
                                            name="facebook"
                                            control={socialFormControl}
                                            defaultValue=""
                                            render={({ field, formState }) => (
                                                <TextField
                                                    fullWidth
                                                    id="facebook"
                                                    label="Facebook *"
                                                    variant="standard"
                                                    {...field}
                                                    error={
                                                        !!formState
                                                            .socialMediaFormErrors
                                                            ?.facebook
                                                    }
                                                />
                                            )}
                                        />
                                        {socialMediaFormErrors.facebook &&
                                            socialMediaFormErrors.facebook
                                                .type === "required" && (
                                                <span
                                                    className={
                                                        "error__feedback"
                                                    }
                                                >
                                                    {
                                                        socialMediaFormErrors
                                                            .facebook.message
                                                    }
                                                </span>
                                            )}
                                        {socialMediaFormErrors.facebook &&
                                            socialMediaFormErrors.facebook
                                                .type === "matches" && (
                                                <span
                                                    className={
                                                        "error__feedback"
                                                    }
                                                    style={{
                                                        paddingLeft: "13%",
                                                    }}
                                                >
                                                    {
                                                        socialMediaFormErrors
                                                            .facebook.message
                                                    }{" "}
                                                </span>
                                            )}
                                    </div>
                                    <div className="mt-5">
                                        <Controller
                                            name="instagram"
                                            control={socialFormControl}
                                            defaultValue=""
                                            render={({ field, formState }) => (
                                                <TextField
                                                    fullWidth
                                                    id="instagram"
                                                    label="Instagram *"
                                                    variant="standard"
                                                    {...field}
                                                    error={
                                                        !!formState
                                                            .socialMediaFormErrors
                                                            ?.instagram
                                                    }
                                                />
                                            )}
                                        />
                                        {socialMediaFormErrors.instagram &&
                                            socialMediaFormErrors.instagram
                                                .type === "required" && (
                                                <span
                                                    className={
                                                        "error__feedback"
                                                    }
                                                >
                                                    {
                                                        socialMediaFormErrors
                                                            .instagram.message
                                                    }
                                                </span>
                                            )}
                                        {socialMediaFormErrors.instagram &&
                                            socialMediaFormErrors.instagram
                                                .type === "matches" && (
                                                <span
                                                    className={
                                                        "error__feedback"
                                                    }
                                                    style={{
                                                        paddingLeft: "13%",
                                                    }}
                                                >
                                                    {
                                                        socialMediaFormErrors
                                                            .instagram.message
                                                    }{" "}
                                                </span>
                                            )}
                                    </div>
                                    <div className="mt-5">
                                        <Controller
                                            name="twitter"
                                            control={socialFormControl}
                                            defaultValue=""
                                            render={({ field, formState }) => (
                                                <TextField
                                                    fullWidth
                                                    id="twitter"
                                                    label="Twitter *"
                                                    variant="standard"
                                                    {...field}
                                                    error={
                                                        !!formState
                                                            .socialMediaFormErrors
                                                            ?.twitter
                                                    }
                                                />
                                            )}
                                        />
                                        {socialMediaFormErrors.twitter &&
                                            socialMediaFormErrors.twitter
                                                .type === "required" && (
                                                <span
                                                    className={
                                                        "error__feedback"
                                                    }
                                                >
                                                    {
                                                        socialMediaFormErrors
                                                            .twitter.message
                                                    }
                                                </span>
                                            )}
                                        {socialMediaFormErrors.twitter &&
                                            socialMediaFormErrors.twitter
                                                .type === "matches" && (
                                                <span
                                                    className={
                                                        "error__feedback"
                                                    }
                                                    style={{
                                                        paddingLeft: "13%",
                                                    }}
                                                >
                                                    {
                                                        socialMediaFormErrors
                                                            .twitter.message
                                                    }
                                                </span>
                                            )}
                                    </div>
                                    <div className="col-span-5 mt-5 float-right">
                                        <Button
                                            type="submit"
                                            variant="contained"
                                            className="btn-black "
                                            onClick={handleSocialMedia(
                                                saveSocialMedia
                                            )}
                                        >
                                            {showLoader ? (
                                                <Loader
                                                    isLoading={showLoader}
                                                />
                                            ) : (
                                                "Submit"
                                            )}
                                        </Button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>

                    {/* all Brandings tab content */}
                    <div
                        className={
                            openTab === "Language"
                                ? "grid grid-cols-1 md:grid-cols-1 lg:grid-cols-1 xl:grid-cols-1 gap-6 mt-6"
                                : "hidden"
                        }
                        id="link1"
                    >
                        <p>
                            Hey there ! Our engineers are working tirelessly to
                            bring in multiple languages. We will be back with a
                            bang.
                        </p>
                        <p>
                            Be the first one to know ! Hit the notify button.{" "}
                        </p>
                        <div className="">
                            <Button variant="contained" className="btn-blue ">
                                Notify Me
                            </Button>
                        </div>
                    </div>

                    {/* all Billing tab content */}
                    <div
                        className={
                            openTab === "Billing"
                                ? "grid grid-cols-1 md:grid-cols-1 lg:grid-cols-1 xl:grid-cols-1 gap-6 mt-6"
                                : "hidden"
                        }
                        id="link1"
                    >
                        <p>Add your fadsfs that are present across the world</p>
                        <div className="">
                            <Button variant="contained" className="btn-black ">
                                Add Distributor
                            </Button>
                        </div>
                    </div>
                </div>
            </div>

            <ModalWrapper
                heading="Reset Password"
                isPopUpShow={showResetPasswordModal}
                size="sm"
                toggleModel={handleResetPasswordModal}
                saveBtnTitle="Change Password"
                onsubmit={handleSavePassword(savePassword)}
            >
                {" "}
                <div className="grid grid-cols-4 md:grid-cols-2 lg:grid-cols-3 gap-1 mt-3 ">
                    {responseError && (
                        <div className="col-span-3  ">
                            <Stack sx={{ width: "100%" }}>
                                <Alert severity="error">{responseError}</Alert>
                            </Stack>
                        </div>
                    )}
                    <div className="col-span-3  ">
                        <Controller
                            name="oldPassword"
                            control={passwordFormControl}
                            defaultValue=""
                            render={({ field, formState }) => (
                                <TextField
                                    fullWidth
                                    id="oldPassword"
                                    label="Enter Old Password *"
                                    variant="standard"
                                    {...field}
                                    error={
                                        !!formState.passwordFormErrors
                                            ?.oldPassword
                                    }
                                />
                            )}
                        />
                        {passwordFormErrors.oldPassword &&
                            passwordFormErrors.oldPassword.type ===
                                "required" && (
                                <span className={"error__feedback"}>
                                    {passwordFormErrors.oldPassword.message}
                                </span>
                            )}
                    </div>

                    <div className="col-span-3 mt-5">
                        <Controller
                            name="newPassword"
                            control={passwordFormControl}
                            defaultValue=""
                            render={({ field, formState }) => (
                                <TextField
                                    fullWidth
                                    id="newPassword"
                                    label="Enter New Password *"
                                    variant="standard"
                                    {...field}
                                    error={
                                        !!formState.passwordFormErrors
                                            ?.newPassword
                                    }
                                />
                            )}
                        />
                        {passwordFormErrors.newPassword &&
                            passwordFormErrors.newPassword.type ===
                                "required" && (
                                <span className={"error__feedback"}>
                                    {passwordFormErrors.newPassword.message}
                                </span>
                            )}
                        {passwordFormErrors.newPassword &&
                            passwordFormErrors.newPassword.type ===
                                "matches" && (
                                <span className={"error__feedback"}>
                                    {passwordFormErrors.newPassword.message}
                                </span>
                            )}
                        {passwordFormErrors.newPassword &&
                            passwordFormErrors.newPassword.type === "min" && (
                                <span className={"error__feedback"}>
                                    {passwordFormErrors.newPassword.message}
                                </span>
                            )}
                        {passwordFormErrors.newPassword &&
                            passwordFormErrors.newPassword.type === "max" && (
                                <span className={"error__feedback"}>
                                    {passwordFormErrors.newPassword.message}
                                </span>
                            )}
                    </div>
                    <div className="col-span-3  mt-5">
                        <Controller
                            name="confirmPassword"
                            control={passwordFormControl}
                            defaultValue=""
                            render={({ field, formState }) => (
                                <TextField
                                    fullWidth
                                    id="confirmPassword"
                                    label="Enter Confirm Password *"
                                    variant="standard"
                                    {...field}
                                    error={
                                        !!formState.passwordFormErrors
                                            ?.confirmPassword
                                    }
                                />
                            )}
                        />
                        {passwordFormErrors.confirmPassword &&
                            passwordFormErrors.confirmPassword.type ===
                                "required" && (
                                <span className={"error__feedback"}>
                                    {passwordFormErrors.confirmPassword.message}
                                </span>
                            )}
                        {passwordFormErrors.confirmPassword &&
                            passwordFormErrors.confirmPassword.type ===
                                "oneOf" && (
                                <span className={"error__feedback"}>
                                    {passwordFormErrors.confirmPassword.message}
                                </span>
                            )}
                    </div>

                    <div className="col-span-3 mt-5  ">
                        <p>
                            Use a password at least 15 letters long, or at least
                            8 Characters long with both letters and numbers.
                        </p>
                    </div>
                </div>
            </ModalWrapper>

            <ModalWrapper
                heading="Change Name"
                isPopUpShow={showChangeNameModal}
                size="xs"
                toggleModel={handleChangeNameModal}
                saveBtnTitle="Continue"
                onsubmit={changeNameSubmit(handleChangeNameSubmit)}
            >
                <div className="grid grid-cols-4 md:grid-cols-2 lg:grid-cols-3 gap-1 mt-3 ">
                    <div className="col-span-3  ">
                        <Controller
                            name="fullName"
                            control={nameFormControl}
                            defaultValue=""
                            render={({ field, formState }) => (
                                <TextField
                                    fullWidth
                                    id="fullname"
                                    label="Enter Name *"
                                    variant="standard"
                                    {...field}
                                    error={!!formState.nameFormErrors?.fullName}
                                />
                            )}
                        />
                        {nameFormErrors.fullName &&
                            nameFormErrors.fullName.type === "required" && (
                                <span className={"error__feedback"}>
                                    {nameFormErrors.fullName.message}
                                </span>
                            )}
                    </div>
                </div>
            </ModalWrapper>
        </>
    );
};

export default Setting;
