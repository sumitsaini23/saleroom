module.exports = {
    content: ["./src/**/*.{js,jsx,ts,tsx}"],
    theme: {
        extend: {
            colors: {
                primary: "#174fba!important",
                fontColor: "#fff",
                titleColor: "#000000",
                white: "#ffffff",
            },
            fontFamily: {
                poppins: " 'Poppins', sans-serif",
            },
        },
    },
    plugins: [],
};
