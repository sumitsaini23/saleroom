import React from "react";

export default function LogoIcon(props) {
  let logoIconPath = require("../../assets/images/icon/sortlogo.png");
  if (props.logoSize) {
    logoIconPath = require("../../assets/images/icon/logonew.png");
  }
  return (
    <img className={props?.cn} src={logoIconPath} alt="logo" width={"38"} />
  );
}
