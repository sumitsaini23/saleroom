import React, { useEffect, useContext } from "react";
import { useForm, Controller } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import { Button } from "@mui/material";
import TextField from "@mui/material/TextField";

import linkedin from "../../assets/images/image/linkedin.jpeg";
import Instagram from "../../assets/images/image/Instagram.jpeg";
import twitter from "../../assets/images/image/twitter.jpeg";
import Loader from "../../components/Loader";
import { Status } from "../../common/utility";
import {
  nextStep,
  previousStep,
  updateBusinessSocialMediaInfo,
  changeStatus,
  login,
} from "../../reducers/authSlice";

const urlPattern =
  /https?:\/\/w{0,3}\w*?\.(\w*?\.)?\w{2,3}\S*|www\.(\w*?\.)?\w*?\.\w{2,3}\S*|(\w*?\.)?\w*?\.\w{2,3}[\/\?]\S*/;

const socialMediaValidateSchema = Yup.object({
  linkedin: Yup.string()
    .required("Required")
    .matches(urlPattern, "Invalid URL"),
  instagram: Yup.string()
    .required("Required")
    .matches(urlPattern, "Invalid URL"),
  twitter: Yup.string().required("Required").matches(urlPattern, "Invalid URL"),
}).required();

const SocialMediaLinks = () => {
  const [Isloading, setLoading] = React.useState(false);
  const businessId = useSelector((state) => state.auth.signUp.businessId);
  const status = useSelector((state) => state.auth.status);
  const email = useSelector((state) => state.auth.signUp.email);
  const password = useSelector((state) => state.auth.signUp.password);
  const isLoggedIn = useSelector((state) => state.auth.isLoggedIn);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(socialMediaValidateSchema),
  });

  useEffect(() => {
    // if (status === Status.SUCCESS) {
    //     dispatch(changeStatus());
    //     setLoading(false);
    //     setTimeout(() => {
    //         navigate("/");
    //     }, 1000);
    // }
    if (status === Status.SUCCESS && isLoggedIn === true) {
      dispatch(changeStatus());
      navigate("/dashboard");
    } else {
      setLoading(false);
    }
  }, [dispatch, navigate, status, isLoggedIn]);

  const onSubmit = (data) => {
    setLoading(true);
    let postData = {
      facebookUrl: "",
      instagramUrl: data.linkedin,
      linkedInUrl: data.instagram,
      twitterUrl: data.twitter,
    };
    dispatch(updateBusinessSocialMediaInfo({ businessId, postData }));
    dispatch(login({ email, password }));
    // reset();
  };

  // const goToLogin = () => {
  //     dispatch(login({ email, password }));
  // };

  return (
    <form>
      <div className="header ">
        <h2 className="text-[26px] font-medium mb-0">
          Enter social media links
        </h2>
        <p className="text-gray-500 text-lg  font-medium">
          This will help us customise salesroom for you
        </p>
      </div>

      <div className="grid grid-cols-4 gap-3 ">
        <div className="body col-span-4 pt-1">
          <div className="grid grid-cols-4 gap-3">
            <div className="col-span-4">
              <div className="flex justify-center mb-4">
                <div className="flex items-center mr-3">
                  <img className="w-10/12" src={linkedin} alt="linkedin" />
                </div>
                <Controller
                  name="linkedin"
                  control={control}
                  defaultValue=""
                  render={({ field, formState }) => (
                    <TextField
                      fullWidth
                      id="linkedin"
                      label="Enter LinkedIn profile link *"
                      variant="standard"
                      {...field}
                      error={!!formState.errors?.linkedin}
                    />
                  )}
                />
                {/* <input
                                    className="!mb-0"
                                    name="linkedin"
                                    placeholder="Enter LinkedIn profile link"
                                    autoComplete="off"
                                /> */}
              </div>
              {errors.linkedin && errors.linkedin.type === "required" && (
                <span
                  className={"error__feedback"}
                  style={{ paddingLeft: "13%" }}
                >
                  {errors.linkedin.message}
                </span>
              )}
              {errors.linkedin && errors.linkedin.type === "matches" && (
                <span
                  className={"error__feedback"}
                  style={{ paddingLeft: "13%" }}
                >
                  {errors.linkedin.message}
                </span>
              )}
            </div>
            <div className="col-span-4">
              <div className="flex justify-center mb-4">
                <div className="flex items-center mr-3">
                  <img className="w-10/12" src={Instagram} alt="Instagram" />
                </div>
                <Controller
                  name="instagram"
                  control={control}
                  defaultValue=""
                  render={({ field, formState }) => (
                    <TextField
                      fullWidth
                      id="instagram"
                      label="Enter Instagram profile link *"
                      variant="standard"
                      {...field}
                      error={!!formState.errors?.instagram}
                    />
                  )}
                />
                {/* <input
                                    className="!mb-0"
                                    name="Instagram"
                                    placeholder="Enter Instagram profile link"
                                    autoComplete="off"
                                /> */}
              </div>
              {errors.instagram && errors.instagram.type === "required" && (
                <span
                  className={"error__feedback"}
                  style={{ paddingLeft: "13%" }}
                >
                  {errors.instagram.message}
                </span>
              )}
              {errors.instagram && errors.instagram.type === "matches" && (
                <span
                  className={"error__feedback"}
                  style={{ paddingLeft: "13%" }}
                >
                  {errors.instagram.message}
                </span>
              )}
            </div>
            <div className="col-span-4">
              <div className="flex justify-center mb-4">
                <div className="flex items-center mr-3">
                  <img className="w-10/12" src={twitter} alt="twitter" />
                </div>
                <Controller
                  name="twitter"
                  control={control}
                  defaultValue=""
                  render={({ field, formState }) => (
                    <TextField
                      fullWidth
                      id="twitter"
                      label="Enter twitter profile link *"
                      variant="standard"
                      {...field}
                      autoComplete="off"
                      error={!!formState.errors?.twitter}
                    />
                  )}
                />
                {/* <input
                                    className="!mb-0"
                                    name="twitter"
                                    placeholder="Enter twitter profile link"
                                    autoComplete="off"
                                /> */}
              </div>
              {errors.twitter && errors.twitter.type === "required" && (
                <span
                  className={"error__feedback"}
                  style={{ paddingLeft: "13%" }}
                >
                  {errors.twitter.message}
                </span>
              )}
              {errors.twitter && errors.twitter.type === "matches" && (
                <span
                  className={"error__feedback"}
                  style={{ paddingLeft: "13%" }}
                >
                  {errors.twitter.message}
                </span>
              )}
            </div>
          </div>
        </div>
        <div className="footer col-span-4 flex justify-between gap-3 mb-5">
          <Button
            type="button"
            className="btnoutline"
            style={{ marginRight: "1rem" }}
            onClick={() =>
              dispatch(
                previousStep() // update formStage
              )
            }
            //onClick={() => next()}
          >
            Back
          </Button>

          <div>
            {/* <Button
                        type={"button"}
                        style={{ marginRight: "1rem" }}
                        onClick={goToLogin}
                    >
                        Skip
                    </Button> */}
            <Button
              type="submit"
              className="btn-blue"
              onClick={handleSubmit(onSubmit)}
              //onClick={() => next()}
            >
              {Isloading ? <Loader isLoading={Isloading} /> : "Done"}
            </Button>
            <div></div>
          </div>
        </div>
      </div>
    </form>
  );
};

export default SocialMediaLinks;
