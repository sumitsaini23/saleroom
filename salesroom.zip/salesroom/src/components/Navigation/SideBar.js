import React from "react";
import { NavLink } from "react-router-dom";
import { styled, useTheme } from "@mui/material/styles";
import MuiDrawer from "@mui/material/Drawer";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import Divider from "@mui/material/Divider";
import IconButton from "@mui/material/IconButton";
import LogoIcon from "../Logo/LogoIcon";

const drawerWidth = 240;

const openedMixin = (theme) => ({
  width: drawerWidth,
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.enteringScreen,
  }),
  overflowX: "hidden",
});

const closedMixin = (theme) => ({
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  overflowX: "hidden",
  width: `calc(${theme.spacing(7)} + 1px)`,
  [theme.breakpoints.up("sm")]: {
    width: `calc(${theme.spacing(8)} + 1px)`,
  },
});

const DrawerHeader = styled("div")(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  justifyContent: "flex-end",
  padding: theme.spacing(0, 1),
  // necessary for content to be below app bar
  ...theme.mixins.toolbar,
}));

const Drawer = styled(MuiDrawer, {
  shouldForwardProp: (prop) => prop !== "open",
})(({ theme, open }) => ({
  width: drawerWidth,
  flexShrink: 0,
  whiteSpace: "nowrap",
  boxSizing: "border-box",
  ...(open && {
    ...openedMixin(theme),
    "& .MuiDrawer-paper": openedMixin(theme),
  }),
  ...(!open && {
    ...closedMixin(theme),
    "& .MuiDrawer-paper": closedMixin(theme),
  }),
}));

const SideBar = (props) => {
  const theme = useTheme();
  // const [open, setOpen] = useState(true);
  const menus = [
    {
      // icon: "./assets/images/icon/home.png",
      icon: "home.png",
      title: "Home",
      path: "/dashboard",
    },
    { icon: "image.png", title: "Images", path: "/images" },
    {
      icon: "manual.png",
      title: "Manuals",
      path: "/manuals",
    },
    {
      icon: "catalogues.png",
      title: "Catalogues",
      path: "/catalogues",
    },
    {
      icon: "videos.png",
      title: "Videos",
      path: "/videos",
    },
    { icon: "contacts.png", title: "Contacts", path: "/contact" },
    {
      icon: "cad.png",
      title: "CAD files",
      border: true,
      path: "/cadFiles",
    },

    {
      icon: "email.png",
      title: "Email Leads",

      path: "/emailHome",
    },
    {
      icon: "whatsapp.png",
      title: "Whatsapp Leads",
      border: true,
      path: "/whatsapp_leads",
    },
    { icon: "members.png", title: "Members", path: "/members" },
    { icon: "settings.png", title: "Settings", path: "/setting" },
    // // { icon:  "image.png", title: "Setting", path: "/setting" },
  ];
  return (
    <>
      <Drawer
        variant="permanent"
        open={props.toggle}
        sx={{
          width: drawerWidth,
          "& .MuiDrawer-paper": {
            background: "#174fba",
            boxSizing: "border-box",
          },
        }}
      >
        <DrawerHeader>
          <IconButton onClick={props.drawerClose}>
            {theme.direction === "rtl" ? (
              <LogoIcon cn="mainlogo" />
            ) : (
              <LogoIcon logoSize="sort" cn="mainlogo1" />
            )}
          </IconButton>
        </DrawerHeader>
        <Divider />
        <List>
          {menus.map((menu, index) => (
            <ListItem
              key={`li-${index}`}
              disablePadding
              sx={{ display: "block" }}
            >
              <NavLink
                to={menu?.path}
                key={index}
                className={({ isActive }) =>
                  isActive
                    ? `sidebar-link text-primary menu-active ${
                        menu.border && "border-b-2 border-b-[#C7C7C7]"
                      }`
                    : `sidebar-link text-fontColor ${
                        menu.border && "border-b-2 border-[#C7C7C7]"
                      }`
                }
              >
                <ListItemButton
                  sx={{
                    minHeight: 48,
                    justifyContent: props.toggle ? "initial" : "center",
                    px: 2.5,
                  }}
                >
                  <ListItemIcon
                    sx={{
                      minWidth: 0,
                      mr: props.toggle ? 3 : "auto",
                      justifyContent: "center",
                    }}
                  >
                    <img
                      className="w-4"
                      src={require(`../../assets/images/icon/${menu.icon}`)}
                      alt="logo"
                    />
                  </ListItemIcon>
                  <ListItemText
                    primary={menu.title}
                    sx={{ opacity: props.toggle ? 1 : 0 }}
                  />
                </ListItemButton>
              </NavLink>
            </ListItem>
          ))}
        </List>
        {/* <Divider /> */}
      </Drawer>
    </>
  );
};

export default SideBar;
