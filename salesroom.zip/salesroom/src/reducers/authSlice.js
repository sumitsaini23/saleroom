import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import {
  Status,
  isApiError,
  successReducer,
  failureReducer,
  ToastAlert,
  getErrorDetails,
} from "../common/utility";
import { ALERT_ERROR } from "../common/constants";
import requestsApi from "../app/requestsApi";

/**
 * @type {AuthState}
 */
const initialState = {
  status: Status.IDLE,
  isLoggedIn: false,
  token: null,
  signUp: {
    currentStep: 1,
    email: "",
    otpReferenceId: "",
    otp: "",
    password: "",
    businessId: "",
    userId: "",
    businessName: "",
    companyAddress: {},
    businessAdditionalInfo: {},
    companyDetail: {},
  },
};

const errorDisplay = (error) => {
  const { statusCode, msg } = getErrorDetails(error);
  ToastAlert({
    type: ALERT_ERROR,
    msg: `${msg}`,
  });
};

/**
 * Send a login request
 */
export const login = createAsyncThunk(
  "auth/login",
  async ({ email, password }, thunkApi) => {
    try {
      return await requestsApi.postRequest("v1/login", {
        password: password,
        userName: email,
      });
    } catch (error) {
      if (isApiError(error)) {
        errorDisplay(error);
        return thunkApi.rejectWithValue(error);
      }
      throw error;
    }
  }
  // ,
  // {
  //   condition: (_, { getState }) => !selectIsLoading(getState()),
  // }
);
/**
 * Send a get current user request
 */
export const getUser = createAsyncThunk(
  "auth/getUser",
  async ({ userId }, thunkApi) => {
    let url = `/v1/users/${userId}`;
    try {
      return await requestsApi.getRequest(url);
    } catch (error) {
      if (isApiError(error)) {
        return thunkApi.rejectWithValue(error);
      }
      throw error;
    }
  }
);

/**
 * Send a register request
 */
export const userRegister = createAsyncThunk(
  "auth/signUp",
  async ({ email }, thunkApi) => {
    try {
      return await requestsApi.postRequest("v1/login/templates/send", {
        identifier: email,
        verificationType: "EMAIL",
      });
    } catch (error) {
      // console.log("res....", error);
      if (isApiError(error)) {
        return thunkApi.rejectWithValue(error);
      }
      throw error;
    }
  }
);

/**
 * Send a verify request
 */
export const verifyOtp = createAsyncThunk(
  "auth/verifyOtp",
  async ({ regEmail, otp, otpReferenceId }, thunkApi) => {
    try {
      return await requestsApi.postRequest("v1/login/templates/verify", {
        identifier: regEmail,
        otp: otp,
        otpReferenceId: otpReferenceId,
        verificationType: "EMAIL",
      });
    } catch (error) {
      errorDisplay(error);
      if (isApiError(error)) {
        return thunkApi.rejectWithValue(error);
      }
      throw error;
    }
  }
);

/**
 * Send a creare Business(room) request
 */
export const createBusiness = createAsyncThunk(
  "auth/createBusiness",
  async ({ email, bizName }, thunkApi) => {
    try {
      return await requestsApi.postRequest("v1/business", {
        businessName: bizName,
        primaryEmail: email,
        onboardPhase: "BUSINESS_NAME",
      });
    } catch (error) {
      // console.log("res....", error);
      if (isApiError(error)) {
        return thunkApi.rejectWithValue(error);
      }
      throw error;
    }
  }
);

/**
 * Send a creare User request
 */
export const createUser = createAsyncThunk(
  "auth/createUser",
  async ({ reqObj }, thunkApi) => {
    // console.log("reqObj", reqObj);
    try {
      return await requestsApi.postRequest("v1/users", {
        businessId: reqObj.businessId,
        email: reqObj.email,
        fullName: reqObj.fullName,
        password: reqObj.password,
        role: "SUPER_ADMIN",
      });
    } catch (error) {
      // console.log("res....", error);
      if (isApiError(error)) {
        return thunkApi.rejectWithValue(error);
      }
      throw error;
    }
  }
);

/**
 * Send request upload image
 */
export const updateBusinessLogo = createAsyncThunk(
  "auth/updateBusinessLogo",
  async ({ url, file }, thunkApi) => {
    // console.log("url", url);
    try {
      return await requestsApi.putRequest(url, {
        file: file,
      });
    } catch (error) {
      // console.log("res....", error);
      if (isApiError(error)) {
        return thunkApi.rejectWithValue(error);
      }
      throw error;
    }
  }
);
/**
 * Send request update company address
 */
export const updateCompanyAddress = createAsyncThunk(
  "auth/updateCompanyAddress",
  async ({ businessId, postData }, thunkApi) => {
    try {
      return await requestsApi.putRequest("v1/business", {
        businessId: businessId,
        address: postData,
        onboardPhase: "BUSINESS_ADDRESS",
      });
    } catch (error) {
      // console.log("res....", error);
      if (isApiError(error)) {
        return thunkApi.rejectWithValue(error);
      }
      throw error;
    }
  }
);
/**
 * Send request update BusinessAdditionalInfo
 */
export const updateBusinessAdditionalInfo = createAsyncThunk(
  "auth/updateBusinessAdditionalInfo",
  async ({ businessId, postData }, thunkApi) => {
    try {
      return await requestsApi.putRequest("v1/business", {
        businessId: businessId,
        additionalInfo: postData,
        onboardPhase: "BUSINESS_ADDITIONAL_INFO",
      });
    } catch (error) {
      if (isApiError(error)) {
        return thunkApi.rejectWithValue(error);
      }
      throw error;
    }
  }
);

/**
 * Send request update BusinessAdditionalInfo
 */
export const updateBusinessSocialMediaInfo = createAsyncThunk(
  "auth/updateBusinessSocialMediaInfo",
  async ({ businessId, postData }, thunkApi) => {
    try {
      return await requestsApi.putRequest("v1/business", {
        businessId: businessId,
        socialMediaInfo: postData,
      });
    } catch (error) {
      if (isApiError(error)) {
        return thunkApi.rejectWithValue(error);
      }
      throw error;
    }
  }
);
/**
 * @param {import('@reduxjs/toolkit').Draft<AuthState>} state
 * @param {import('@reduxjs/toolkit').PayloadAction<{token: string, user: User}>} action
 */
function successLoginReducer(state, action) {
  state.status = Status.SUCCESS;
  state.isLoggedIn = true;
  state.token = action.payload.logonSessionId;
  state.user = action.payload.user;
  state.signUp = initialState.signUp;
}

function successGetUsesrReducer(state, action) {
  const token = window.localStorage.getItem("token");
  state.status = Status.SUCCESS;
  state.isLoggedIn = true;
  state.token = token;
  state.user = {
    businessId: action.payload.businessId,
    email: action.payload.email,
    fullName: action.payload.fullName,
    role: action.payload.role,
    userId: action.payload.userId,
  };
}

function successSignUpReducer(state, action) {
  state.signUp.email = action.payload.identifier;
  state.signUp.otpReferenceId = action.payload.otpReferenceId;
  state.status = Status.SUCCESS;
}

function successOtpVerifyReducer(state, action) {
  state.signUp.otp = action.meta.arg.otp;
  state.status = Status.SUCCESS;
}

function successSignUpBusinessReducer(state, action) {
  state.signUp.businessId = action.payload.businessId;
  state.signUp.businessName = action.payload.businessName;
  state.status = Status.SUCCESS;
}

function successSignUpUserReducer(state, action) {
  state.signUp.userId = action.payload.userId;
  state.status = Status.SUCCESS;
}

function successSocialMediaInfoReducer(state) {
  let email = state.signUp.email;
  let password = state.signUp.password;
  login({ email, password });
  state.signUp = initialState.signUp;
  state.status = Status.SUCCESS;
}

function successUpdateCompanyAddressReducer(state, action) {
  state.signUp.companyAddress = action.payload.address;
  state.status = Status.SUCCESS;
}

function successUpdateBusinessAdditionalInfoReducer(state, action) {
  state.signUp.businessAdditionalInfo = action.payload.additionalInfo;
  state.status = Status.SUCCESS;
}

/**
 * Reducers
 */

export const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    /**
     * Log out the user
     */
    logout: () => initialState,
    /**
     * SignUp
     */
    nextStep: (state, action) => {
      state.signUp.currentStep = action.payload;
    },
    previousStep: (state) => {
      state.signUp.currentStep = state.signUp.currentStep - 1;
    },
    signUpPassword: (state, action) => {
      state.signUp.password = action.payload;
    },
    changeStatus: (state) => {
      state.status = initialState.status;
    },
    companyLogoWesite: (state, action) => {
      state.signUp.companyDetail = action.payload;
    },
    resetSignUp: (state) => {
      state.signUp = initialState.signUp;
    },
    // /**
    //  * Update token
    //  *
    //  * @param {import('@reduxjs/toolkit').Draft<AuthState>} state
    //  * @param {import('@reduxjs/toolkit').PayloadAction<string>} action
    //  */
    // setToken(state, action) {
    //   state.token = action.payload;
    // },
  },
  extraReducers(builder) {
    /**
     * Pending Status
     */
    builder.addCase(login.pending, (state) => {
      state.loading = Status.LOADING;
    });
    builder.addCase(getUser.pending, (state) => {
      state.loading = Status.LOADING;
    });
    builder.addCase(userRegister.pending, (state) => {
      state.loading = Status.LOADING;
    });
    builder.addCase(verifyOtp.pending, (state) => {
      state.loading = Status.LOADING;
    });
    builder.addCase(createBusiness.pending, (state) => {
      state.loading = Status.LOADING;
    });
    builder.addCase(createUser.pending, (state) => {
      state.loading = Status.LOADING;
    });
    builder.addCase(updateBusinessLogo.pending, (state) => {
      state.loading = Status.LOADING;
    });
    builder.addCase(updateCompanyAddress.pending, (state) => {
      state.loading = Status.LOADING;
    });
    builder.addCase(updateBusinessAdditionalInfo.pending, (state) => {
      state.loading = Status.LOADING;
    });
    builder.addCase(updateBusinessSocialMediaInfo.pending, (state) => {
      state.loading = Status.LOADING;
    });
    /**
     * fulfilled Status
     */
    builder.addCase(login.fulfilled, successLoginReducer);
    builder.addCase(getUser.fulfilled, successGetUsesrReducer);
    builder.addCase(userRegister.fulfilled, successSignUpReducer);
    // builder.addCase(verifyOtp.fulfilled, successReducer);
    builder.addCase(verifyOtp.fulfilled, successOtpVerifyReducer);
    builder.addCase(createBusiness.fulfilled, successSignUpBusinessReducer);
    builder.addCase(createUser.fulfilled, successSignUpUserReducer);
    builder.addCase(updateBusinessLogo.fulfilled, successReducer);
    // builder.addCase(updateCompanyAddress.fulfilled, successReducer);
    builder.addCase(
      updateCompanyAddress.fulfilled,
      successUpdateCompanyAddressReducer
    );
    // builder.addCase(updateBusinessAdditionalInfo.fulfilled, successReducer);
    builder.addCase(
      updateBusinessAdditionalInfo.fulfilled,
      successUpdateBusinessAdditionalInfoReducer
    );
    builder.addCase(
      updateBusinessSocialMediaInfo.fulfilled,
      successSocialMediaInfoReducer
    );
    /**
     * rejected Status
     */
    builder.addCase(login.rejected, failureReducer);
    builder.addCase(getUser.rejected, failureReducer);
    builder.addCase(userRegister.rejected, failureReducer);
    builder.addCase(verifyOtp.rejected, failureReducer);
    builder.addCase(createBusiness.rejected, failureReducer);
    builder.addCase(createUser.rejected, failureReducer);
    builder.addCase(updateBusinessLogo.rejected, failureReducer);
    builder.addCase(updateCompanyAddress.rejected, failureReducer);
    builder.addCase(updateBusinessAdditionalInfo.rejected, failureReducer);
    builder.addCase(updateBusinessSocialMediaInfo.rejected, failureReducer);
    //     builder.addMatcher(
    //       (action) => /auth\/.*\/pending/.test(action.type),
    //       loadingReducer
    //     );
  },
});

/**
 * Action creators are generated for each case reducer function
 */

export const {
  logout,
  nextStep,
  previousStep,
  signUpPassword,
  changeStatus,
  companyLogoWesite,
  resetSignUp,
} = authSlice.actions;

export default authSlice.reducer;
