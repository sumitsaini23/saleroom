import React from "react";

function WhatsAppLead() {
  return <div>WhatsAppLead</div>;
}

export default WhatsAppLead;
