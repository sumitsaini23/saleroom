import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import Loader from "../../components/Loader";
import { Button, TextField } from "@mui/material";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import IconButton from "@mui/material/IconButton";

import {
  nextStep,
  previousStep,
  signUpPassword,
  changeStatus,
} from "../../reducers/authSlice";

const schema = Yup.object({
  password: Yup.string()
    .required("Required")
    .matches(/[a-zA-Z0-9]/, "Password allowd only alphanumeric characters.")
    .min(8, "Min 8 charactor require")
    .max(16, "Too Long!"),
  confirmPassword: Yup.string()
    .required("Required")
    .oneOf([Yup.ref("password"), null], "Passwords must match"),
}).required();

const EnterPassword = () => {
  const [Isloading, setIsloading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfPassword, setShowConfPassword] = useState(false);
  const regPassword = useSelector((state) => state.auth.signUp.password);
  const dispatch = useDispatch();

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
  });

  useEffect(() => {
    dispatch(changeStatus());
    if (regPassword !== "") {
      reset({
        password: regPassword,
        confirmPassword: regPassword,
      });
    }
  }, [dispatch, regPassword, reset]);

  const onSubmit = (data) => {
    dispatch(signUpPassword(data.password));
    // reset();
    setIsloading(true);
    dispatch(
      nextStep(4) // update formStage
    );
    // setTimeout(() => {
    //     reset();
    //     setIsloading(true);
    //     dispatch(
    //         nextStep(4) // update formStage
    //     );
    // }, 1000);
  };

  const handleClickShowPassword = () => {
    setShowPassword(!showPassword);
  };

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };

  const handleClickShowConfPassword = () => {
    setShowConfPassword(!showConfPassword);
  };

  const handleMouseDownConfPassword = (event) => {
    event.preventDefault();
  };

  return (
    <form>
      <div className="header  mb-7">
        <h2 className="text-[26px] font-medium">Enter password</h2>
      </div>
      <div className="grid grid-cols-4 gap-3">
        <div className="body col-span-4 pt-12">
          <div className="mb-5" style={{ display: "flex" }}>
            <Controller
              name="password"
              control={control}
              defaultValue=""
              render={({ field, formState }) => (
                <TextField
                  type={showPassword ? "test" : "password"}
                  fullWidth
                  id="password"
                  label="Enter password *"
                  variant="standard"
                  {...field}
                  error={!!formState.errors?.password}
                />
              )}
            />
            <div className="pwdeyeicon">
              <IconButton
                position="end"
                aria-label="toggle password visibility"
                onClick={handleClickShowPassword}
                onMouseDown={handleMouseDownPassword}
              >
                {showPassword ? <Visibility /> : <VisibilityOff />}
              </IconButton>
            </div>
          </div>
          {errors.password && errors.password.type === "required" && (
            <span className={"error__feedback"}>{errors.password.message}</span>
          )}
          {errors.password && errors.password.type === "matches" && (
            <span className={"error__feedback"}>{errors.password.message}</span>
          )}
          {errors.password && errors.password.type === "min" && (
            <span className={"error__feedback"}>{errors.password.message}</span>
          )}
          {errors.password && errors.password.type === "max" && (
            <span className={"error__feedback"}>{errors.password.message}</span>
          )}

          <div style={{ display: "flex", marginTop: "40px" }}>
            <Controller
              name="confirmPassword"
              control={control}
              defaultValue=""
              render={({ field, formState }) => (
                <TextField
                  type={showConfPassword ? "test" : "password"}
                  fullWidth
                  id="confpassword"
                  label="Enter confirm password *"
                  variant="standard"
                  {...field}
                  error={!!formState.errors?.confirmPassword}
                />
              )}
            />

            <div className="pwdeyeicon">
              <IconButton
                position="end"
                aria-label="toggle password visibility"
                onClick={handleClickShowConfPassword}
                onMouseDown={handleMouseDownConfPassword}
              >
                {showConfPassword ? <Visibility /> : <VisibilityOff />}
              </IconButton>
            </div>
          </div>
          {errors.confirmPassword &&
            errors.confirmPassword.type === "required" && (
              <span className={"error__feedback"}>
                {errors.confirmPassword.message}
              </span>
            )}
          {errors.confirmPassword &&
            errors.confirmPassword.type === "oneOf" && (
              <span className={"error__feedback"}>
                {errors.confirmPassword.message}
              </span>
            )}
          <div
            className={"form__item button__items d-flex justify-content-end"}
          ></div>
        </div>
        <div className="footer col-span-4 flex justify-between mb-5">
          <Button
            type="button"
            style={{ marginRight: "1rem" }}
            className="btnoutline"
            onClick={() =>
              dispatch(
                previousStep() // update formStage
              )
            }
          >
            Back
          </Button>
          <Button
            type="submit"
            className="btn-blue"
            onClick={handleSubmit(onSubmit)}
            // onClick={() => next()}
          >
            {Isloading ? <Loader isLoading={Isloading} /> : "Next"}
          </Button>
        </div>
      </div>
    </form>
  );
};
export default EnterPassword;
