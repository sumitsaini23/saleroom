import React from "react";
import { useForm, Controller } from "react-hook-form";
import { useSelector, useDispatch } from "react-redux";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import Swal from "sweetalert2";
import TextField from "@mui/material/TextField";
import ModalWrapper from "../../UI/ModalWrapper";
import { hideModal } from "../../../reducers/modalSlice";
import { startLoader, stopLoader } from "../../../reducers/commonSlice";
import { getAllCategories } from "../../../reducers/categorySlice";
import doneicn from "../../../assets/images/icon/doneicn.gif";


import requestsApi from "../../../app/requestsApi";
// import { edit } from "git-cz";

const schema = Yup.object({
  categoryName: Yup.string().required("Required"),
}).required();

export default function CategoryModal(props) {
  const showModal = useSelector((state) => state.modalView.showModal);
  const heading = useSelector((state) => state.modalView.heading);
  const businessId = useSelector((state) => state.auth?.user?.businessId);
  const dispatch = useDispatch();

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
  });

  const onSaveCategory = async (data) => {
    dispatch(startLoader());
    await requestsApi
      .postRequest("/v1/category", {
        businessId: businessId,
        categoryName: data.categoryName,
      })
      .then(function (response) {
        reset();
        dispatch(getAllCategories({ businessId }));
        dispatch(hideModal());
        Swal.fire({
          title: "Category successfully created",
          // icon: "success",
          imageUrl: doneicn,
          imageWidth:"100",
          showConfirmButton: false,
          timer: 2000,
        });
      })
      .catch(function (error) {
        // console.log("error", error);
      })
      .then(function () {
        // always executed
        dispatch(stopLoader());
        //// console.log("always executed");
      });
  };

  return (
    <ModalWrapper
      heading={`${heading} Category`}
      isPopUpShow={showModal}
      size="xs"
      toggleModel={() => dispatch(hideModal())}
      onsubmit={handleSubmit(onSaveCategory)}
      saveBtnTitle="Done"
    >
      <div className="relative p-6 flex-auto">
        <Controller
          name="categoryName"
          control={control}
          defaultValue=""
          render={({ field, formState }) => (
            <TextField
              fullWidth
              id="categoryName"
              label="Enter Category Name *"
              variant="standard"
              {...field}
              error={!!formState.errors?.categoryName}
            />
          )}
        />
        {errors.categoryName && errors.categoryName.type === "required" && (
          <span className={"error__feedback"}>
            {errors.categoryName.message}
          </span>
        )}
      </div>
    </ModalWrapper>
  );
  // return (
  //   <>
  //     {showModal && (
  //       <>
  //         <div className="justify-center items-center flex overflow-x-hidden overflow-y-auto fixed inset-0 z-50 outline-none focus:outline-none">
  //           <div className="relative w-auto my-6 mx-auto max-w-xl">
  //             {/*content*/}
  //             <div className="border-0 rounded-lg shadow-lg relative flex flex-col w-full bg-white outline-none focus:outline-none">
  //               <CategoryModalContent />
  //             </div>
  //           </div>
  //         </div>
  //         <div
  //           className={`${
  //             createNewCategory
  //               ? "opacity-0 fixed inset-0 z-40 bg-black"
  //               : "opacity-25 fixed inset-0 z-40 bg-black"
  //           }`}
  //         ></div>
  //       </>
  //     )}
  //   </>
  // );
}
