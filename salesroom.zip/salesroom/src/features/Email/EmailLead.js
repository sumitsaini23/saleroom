import React, { useState, useEffect } from "react";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import Swal from "sweetalert2";
import DOMPurify from "dompurify";
import Grid from "@mui/material/Grid";
import { useSelector, useDispatch } from "react-redux";

import MenuItem from "@mui/material/MenuItem";

import Breadcrumb from "../../components/Breadcrumb/Breadcrumb";
import ModalWrapper from "../../components/UI/ModalWrapper";
import { emailPattern } from "../../common/utility";
import { startLoader, stopLoader } from "../../reducers/commonSlice";
import { getAllProducts } from "../../reducers/productSlice";
import { getAllCategories } from "../../reducers/categorySlice";
import requestsApi from "../../app/requestsApi";
import HistoryIcon from "@mui/icons-material/History";
import {
  Drawer,
  CircularProgress,
  Box,
  Button,
  Divider,
  TextField,
  Typography,
} from "@mui/material";
import * as _ from "lodash";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import List from "@mui/material/List";
import InboxIcon from "@mui/icons-material/MoveToInbox";
import MailIcon from "@mui/icons-material/Mail";
import doneicn from "../../assets/images/icon/doneicn.gif";

/**
 * send template validation
 */
const shareTemplateValidationSchema = Yup.object({
  subjectline: Yup.string().required("Required"),
  previewtext: Yup.string().required("Required"),
  emails: Yup.string().required("Required"),
  from: Yup.string().required("Required"),
}).required();

/**
 * Start Component
 */
const EmailLead = () => {
  const dispatch = useDispatch();
  const businessId = useSelector((state) => state.auth?.user?.businessId);
  const products = useSelector((state) => state.products.products?.content);
  const [historyModal, setHistoryModal] = useState(false);
  const [emailHistory, setEmailHistory] = useState([]);
  const [openTab, setOpenTab] = useState("Pre-sales");
  const [templateList, setTemplateList] = useState([]);
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  const [showShareTempModal, setShowShareTempModal] = useState(false);
  const [previewTemplate, setPreviewTemplate] = useState("");
  const [selectTemplateId, setSelectTemplateId] = useState("");
  const [selectedProductId, setSelectedProductId] = useState(
    products && products.length > 0 ? products?.[0]["id"] : ""
  );
  const [selectedTemplateType, setSelectedTemplateType] = useState("PRE_SALES");
  /**
   *  share template from control
   */
  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(shareTemplateValidationSchema),
    mode: "onTouched",
  });

  const getEmailHistory = () => {
    requestsApi
      .getRequest("https://jsonplaceholder.typicode.com/users")
      .then((res) => {
        setEmailHistory(res);
      })
      .catch((err) => {
        setEmailHistory([]);
      });
  };

  useEffect(() => {
    //// console.log("initialProductId", initialProductId);
    if (selectedProductId && selectedProductId !== "") {
      getTemplateByProductid(selectedProductId, selectedTemplateType);
    } else if (!products && businessId) {
      dispatch(getAllCategories({ businessId }));
      dispatch(getAllProducts({ businessId, offset: 0 }));
    } else if (products && selectedProductId === "") {
      let pId = products && products.length > 0 ? products?.[0]["id"] : "";
      setSelectedProductId(pId);
      getTemplateByProductid(pId, selectedTemplateType);
    }
  }, [products, businessId]);

  const fetchEmailHistory = () => {
    getEmailHistory();
    setHistoryModal(true);
  };

  const toggleDrawer = (open) => (event) => {
    if (event.type === "click") {
      getEmailHistory();
      setHistoryModal(open);
    }
  };

  const getTemplateByProductid = async (productId, templateType) => {
    /**
     * templateType:
     * PRE_SALES,POST_SALES,PRODUCT_TEMPLATE
     */
    const promises = [];
    await requestsApi
      .postRequest("/v1/templates/get/", {
        businessId: businessId,
        filterReqType: "TEMPLATE_CONFIG_TYPE",
        //referenceEntityId: productId,
        templateType: templateType,
      })
      .then(function (response) {
        //// console.log("response", response);
        if (
          Object.keys(response).length > 0 &&
          response.templateConfigs &&
          response.templateConfigs.length > 0 &&
          selectedProductId !== ""
        ) {
          for (const item of response.templateConfigs) {
            promises.push(
              //getTemplatePreviewById(productId, item.id)
              requestsApi.postRequest("/v1/templates/preview", {
                businessId: businessId,
                referenceEntity: "PRODUCT_ENTITY",
                referenceEntityId: productId,
                templateConfigId: item.id,
              })
            );
          }
          Promise.all(promises).then((results) =>
            //// console.log("promise all", results)
            setTemplateList(results)
          );
        } else {
          Swal.fire({
            title: "Template not available",
            icon: "info",
            showConfirmButton: false,
            timer: 2000,
          });
        }
        //setTemplateList(response.templateConfigs);
      })
      .catch(function (error) {
        // console.log("error", error);
      });
  };
  /**
   * @param {*} tempconfigId
   */

  const handlePreviewModal = () => {
    setShowPreviewModal(!showPreviewModal);
  };

  const showTemplatePreview = (info) => {
    setSelectTemplateId(info.templateConfigId);
    setPreviewTemplate(info.htmlString);
    handlePreviewModal();
  };

  const handleShareTempModal = () => {
    setShowShareTempModal(!showShareTempModal);
  };

  const handleNextAction = () => {
    handlePreviewModal();
    handleShareTempModal();
  };

  const sendTemplate = async (data) => {
    dispatch(startLoader());
    let emailIds = [];
    data.emails.split(",").forEach(function (email) {
      if (email && emailPattern.test(email)) emailIds.push(email.trim());
    });

    await requestsApi
      .postRequest("/v1/templates/saveAndShare", {
        createTemplateReq: {
          businessId: businessId,
          htmlString: previewTemplate,
          referenceEntityId: selectedProductId,
          referenceEntityType: "PRODUCT_ENTITY",
          templateConfigId: selectTemplateId,
          type: "PRODUCT_TEMPLATE",
        },
        notificationInfo: {
          identifiers: emailIds,
          notificationType: "EMAIL",
          subject: data.subjectline,
        },
      })
      .then(function (response) {
        reset();
        setSelectTemplateId("");
        setPreviewTemplate("");
        handleShareTempModal();
        Swal.fire({
          title: "Template sent successfully",
          // icon: "success",
          imageUrl: doneicn,
		  imageWidth:"100",
          showConfirmButton: false,
          timer: 2000,
        });
        //// console.log("Send", response);
      })
      .catch(function (error) {
        // console.log("error", error);
      })
      .then(function () {
        // always executed
        dispatch(stopLoader());
      });
  };

  const cleanHTML = (rawHtml) => {
    return DOMPurify.sanitize(rawHtml, {
      USE_PROFILES: { html: true },
    });
  };

  // console.log("template list", templateList);

  return (
    <>
      <Breadcrumb />
      <div className="p-6 grid grid-cols-1 md:grid-cols-4 lg:grid-cols-4 xl:grid-cols-4">
        <div className="mb-0 col-span-3">
          <h2 className="text-3xl font-bold mb-0">Email Templates</h2>
          {/* <h2 className="text-lg">2 members</h2> */}
        </div>
        <div className="grid md:grid-cols-6 gap-5">
          <div className="col-span-2">
            <TextField
              fullWidth
              variant="outlined"
              id="outlined-select-currency"
              select
              label="Select Product"
              value={selectedProductId}
              InputLabelProps={{
                shrink: true,
              }}
            >
              {(products || []).map((p, i) => (
                <MenuItem
                  key={p.id}
                  value={p.id}
                  selected={i === 0}
                  onClick={() => {
                    setTemplateList([]);
                    setSelectedProductId(p.id);
                    getTemplateByProductid(p.id, selectedTemplateType);
                  }}
                >
                  {p.productName}
                </MenuItem>
              ))}
            </TextField>{" "}
          </div>
          <div className="col-span-2">
            <TextField
              fullWidth
              id="outlined-select-currency"
              select
              label="Language"
              value={"English"}
              disabled={true}
              variant="outlined"
              // onChange={handleChange}
              // helperText="Please select your currencyasdfds"
            >
              <MenuItem key={"English"} value={"English"}>
                English
              </MenuItem>
            </TextField>{" "}
          </div>
          <div className="mb-0 col-span-2 align-middle">
            <HistoryIcon
              fontSize="large"
              onClick={() => {
                fetchEmailHistory();
              }}
            />
          </div>
        </div>
      </div>

      <div className="flex m-5 mt-0">
        <div className="w-fit">
          <ul
            className="tabs-btn flex mb-0 list-none flex-wrap pt-3 pb-4 flex-row"
            role="tablist"
          >
            {/* presales tab */}
            <li className="-mb-px mr-2 last:mr-0 text-center">
              <a
                className={
                  "text-xs font-bold  px-5 py-3 shadow-lg rounded block leading-normal" +
                  (openTab === "Pre-sales" ? " active" : "")
                }
                onClick={(e) => {
                  e.preventDefault();
                  setTemplateList([]);
                  setSelectedTemplateType("PRE_SALES");
                  getTemplateByProductid(selectedProductId, "PRE_SALES");
                  setOpenTab("Pre-sales");
                }}
                data-toggle="tab"
                href="#link1"
                role="tablist"
                style={
                  openTab === "Pre-sales" ? { pointerEvents: "none" } : null
                }
              >
                Pre-sales
              </a>
            </li>
            {/* Post-sales tab */}
            <li className="-mb-px mr-2 last:mr-0 text-center">
              <a
                className={
                  "text-xs font-bold  px-5 py-3 shadow-lg rounded block leading-normal" +
                  (openTab === "Post-sales" ? " active" : "")
                }
                onClick={(e) => {
                  e.preventDefault();
                  setTemplateList([]);
                  setSelectedTemplateType("POST_SALES");
                  getTemplateByProductid(selectedProductId, "POST_SALES");
                  setOpenTab("Post-sales");
                }}
                data-toggle="tab"
                href="#link2"
                role="tablist"
                style={
                  openTab === "Post-sales" ? { pointerEvents: "none" } : null
                }
              >
                Post-sales
              </a>
            </li>

            <li className="-mb-px mr-2 last:mr-0 text-center">
              <a
                className={
                  "text-xs font-bold  px-5 py-3 shadow-lg rounded block leading-normal" +
                  (openTab === "Follow-up" ? " active" : "")
                }
                onClick={(e) => {
                  e.preventDefault();
                  setTemplateList([]);
                  setSelectedTemplateType("FOLLOW_UP");
                  getTemplateByProductid(selectedProductId, "FOLLOW_UP");
                  setOpenTab("Follow-up");
                }}
                data-toggle="tab"
                href="#link2"
                role="tablist"
                style={
                  openTab === "Follow-up" ? { pointerEvents: "none" } : null
                }
              >
                Follow-up
              </a>
            </li>

            <li className="-mb-px mr-2 last:mr-0 text-center">
              <a
                className={
                  "text-xs font-bold  px-5 py-3 shadow-lg rounded block leading-normal" +
                  (openTab === "Thankyou" ? " active" : "")
                }
                onClick={(e) => {
                  e.preventDefault();
                  setTemplateList([]);
                  setSelectedTemplateType("THANK_YOU");
                  getTemplateByProductid(selectedProductId, "THANK_YOU");
                  setOpenTab("Thankyou");
                }}
                data-toggle="tab"
                href="#link2"
                role="tablist"
                style={
                  openTab === "Thankyou" ? { pointerEvents: "none" } : null
                }
              >
                Thank you
              </a>
            </li>

            <li className="-mb-px mr-2 last:mr-0 text-center">
              <a
                className={
                  "text-xs font-bold  px-5 py-3 shadow-lg rounded block leading-normal" +
                  (openTab === "wishes" ? " active" : "")
                }
                onClick={(e) => {
                  e.preventDefault();
                  setTemplateList([]);
                  setSelectedTemplateType("WISHES");
                  getTemplateByProductid(selectedProductId, "WISHES");
                  setOpenTab("wishes");
                }}
                data-toggle="tab"
                href="#link2"
                role="tablist"
                style={openTab === "wishes" ? { pointerEvents: "none" } : null}
              >
                Wishes
              </a>
            </li>

            <li className="-mb-px mr-2 last:mr-0 text-center">
              <a
                className={
                  "text-xs font-bold  px-5 py-3 shadow-lg rounded block leading-normal" +
                  (openTab === "feedback" ? " active" : "")
                }
                onClick={(e) => {
                  e.preventDefault();
                  setTemplateList([]);
                  setSelectedTemplateType("FEEDBACK");
                  getTemplateByProductid(selectedProductId, "FEEDBACK");
                  setOpenTab("feedback");
                }}
                data-toggle="tab"
                href="#link2"
                role="tablist"
                style={
                  openTab === "feedback" ? { pointerEvents: "none" } : null
                }
              >
                Feedback
              </a>
            </li>
          </ul>

          {/* Pre-sales tab content */}

          <div
            style={{ float: "left" }}
            className={openTab === "Pre-sales" ? "gap-6 " : "hidden"}
            id="link1"
          >
            <Grid
              container
              rowSpacing={2}
              columnSpacing={{ xs: 1, sm: 2, md: 3 }}
            >
              {templateList.map((tempInfo, i) => (
                <div xs={12} key={tempInfo.templateConfigId}>
                  <div className="boxContainer col-span-3 md-4">
                    <div className="brdrblack  previewbtn ml-2">
                      <div
                        className="emailimgsize"
                        dangerouslySetInnerHTML={{
                          __html: cleanHTML(tempInfo.htmlString),
                        }}
                        key={`template-${tempInfo.templateConfigId}`}
                      />
                      <Button
                        className="btn-black m-2"
                        style={{ margin: "10px" }}
                        onClick={() => showTemplatePreview(tempInfo)}
                        key={`templatebtn-${tempInfo.templateConfigId}`}
                      >
                        Preview
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </Grid>
            {/* <div className="col-span-3 mt-5 ">
                            <Button
                                type="submit"
                                disabled={false}
                                onClick={navigateHome}
                                variant="contained"
                                className="btn-blue float-right"
                            >
                                Next
                            </Button>
                        </div> */}
          </div>

          {/* Post-sales tab content */}

          <div
            className={openTab === "Post-sales" ? "gap-6  " : "hidden"}
            id="link1"
          >
            <Grid
              container
              rowSpacing={2}
              columnSpacing={{ xs: 1, sm: 2, md: 3 }}
            >
              {templateList.map((tempInfo, i) => (
                <div xs={12}>
                  <div
                    className="boxContainer col-span-3 md-4"
                    key={tempInfo.id}
                  >
                    <div className="brdrblack previewbtn">
                      <div
                        className="emailimgsize"
                        dangerouslySetInnerHTML={{
                          __html: cleanHTML(tempInfo.htmlString),
                        }}
                      />
                      <Button
                        className="btn-black "
                        style={{ margin: "10px" }}
                        onClick={() => showTemplatePreview(tempInfo)}
                      >
                        Preview
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </Grid>
          </div>

          {/* Follow-up tab content */}
          <div
            className={
              openTab === "Follow-up"
                ? "grid grid-cols-1  md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-3 gap-6 mt-6"
                : "hidden"
            }
            id="link1"
          >
            <Grid
              container
              rowSpacing={2}
              columnSpacing={{ xs: 1, sm: 2, md: 3 }}
            >
              {templateList.map((tempInfo, i) => (
                <div xs={12}>
                  <div className="boxContainer md-4" key={tempInfo.id}>
                    <div className="brdrblack ">
                      <div
                        dangerouslySetInnerHTML={{
                          __html: cleanHTML(tempInfo.htmlString),
                        }}
                      />
                      <Button
                        className="btn-black previewbtn"
                        style={{}}
                        onClick={() => showTemplatePreview(tempInfo)}
                      >
                        Preview
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </Grid>
          </div>

          {/* Thankyou tab content */}
          <div
            className={
              openTab === "Thankyou"
                ? "grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-3 gap-6 mt-6"
                : "hidden"
            }
            id="link1"
          >
            <Grid
              container
              rowSpacing={2}
              columnSpacing={{ xs: 1, sm: 2, md: 3 }}
            >
              {templateList.map((tempInfo, i) => (
                <div xs={12}>
                  <div className="boxContainer md-4" key={tempInfo.id}>
                    <div className="brdrblack previewbtn">
                      <div
                        dangerouslySetInnerHTML={{
                          __html: cleanHTML(tempInfo.htmlString),
                        }}
                      />
                      <Button
                        className="btn-black "
                        style={{}}
                        onClick={() => showTemplatePreview(tempInfo)}
                      >
                        Preview
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </Grid>
          </div>

          {/* wishes tab content */}
          <div
            className={
              openTab === "wishes"
                ? "grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-3 gap-6 mt-6"
                : "hidden"
            }
            id="link1"
          >
            <Grid
              container
              rowSpacing={2}
              columnSpacing={{ xs: 1, sm: 2, md: 3 }}
            >
              {templateList.map((tempInfo, i) => (
                <div xs={12}>
                  <div className="boxContainer md-4" key={tempInfo.id}>
                    <div className="brdrblack previewbtn">
                      <div
                        dangerouslySetInnerHTML={{
                          __html: cleanHTML(tempInfo.htmlString),
                        }}
                      />
                      <Button
                        className="btn-black "
                        style={{}}
                        onClick={() => showTemplatePreview(tempInfo)}
                      >
                        Preview
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </Grid>
          </div>

          {/* feedback tab content */}
          <div
            className={
              openTab === "feedback"
                ? "grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-3 gap-6 mt-6"
                : "hidden"
            }
            id="link1"
          >
            <Grid
              container
              rowSpacing={2}
              columnSpacing={{ xs: 1, sm: 2, md: 3 }}
            >
              {templateList.map((tempInfo, i) => (
                <div xs={12}>
                  <div className="boxContainer col-span-3 md-4">
                    <div className="brdrblack  previewbtn ml-2">
                      <div
                        className="emailimgsize"
                        dangerouslySetInnerHTML={{
                          __html: cleanHTML(tempInfo.htmlString),
                        }}
                      />
                      <Button
                        className="btn-black "
                        style={{}}
                        onClick={() => showTemplatePreview(tempInfo)}
                      >
                        Preview
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </Grid>
          </div>
        </div>
      </div>
      <ModalWrapper
        heading="Preview Template"
        isPopUpShow={showPreviewModal}
        size="lg"
        toggleModel={handlePreviewModal}
        saveBtnTitle="Next"
        onsubmit={handleNextAction}
      >
        <div
          dangerouslySetInnerHTML={{
            __html: cleanHTML(previewTemplate),
          }}
        />
      </ModalWrapper>
      <ModalWrapper
        heading="Share Template"
        isPopUpShow={showShareTempModal}
        size="xl"
        toggleModel={handleShareTempModal}
        saveBtnTitle="Submit"
        onsubmit={handleSubmit(sendTemplate)}
      >
        <div className="p-6 grid grid-cols-1 md:grid-cols-4 lg:grid-cols-4 xl:grid-cols-4">
          <div className="mb-0 col-span-3">
            {/* <h2 className="text-3xl font-bold mb-0">
                            Share Templates
                        </h2> */}
            {/* <h2 className="text-lg">2 members</h2> */}
          </div>
          <div className="col-span-4 mt-4">
            <div className={`form__item `}>
              <Controller
                name="subjectline"
                control={control}
                defaultValue=""
                render={({ field, formState }) => (
                  <TextField
                    fullWidth
                    label="Subject Line"
                    variant="standard"
                    {...field}
                    error={!!formState.errors?.subjectline}
                    helperText="Write a subject line that clearly describes your email content. It will be visible in your recipient’s inbox and is the first content they 
                                        will see. For example: ‘Private sale: 25% off our new collection"
                  />
                )}
              />
            </div>
            {errors.subjectline && errors.subjectline.type === "required" && (
              <span className={"error__feedback"}>
                {errors.subjectline.message}
              </span>
            )}
          </div>

          <div className="col-span-4 mt-4 ">
            <div className={`form__item `}>
              <Controller
                name="previewtext"
                control={control}
                defaultValue=""
                render={({ field, formState }) => (
                  <TextField
                    fullWidth
                    label="Preview Text"
                    variant="standard"
                    {...field}
                    error={!!formState.errors?.previewtext}
                    helperText="Write a short text (about 35 characters) that gives an overview of the content of your email. This will significantly increase your 
                                        opening rate. This feature is supported by most email clients, like Gmail and Yahoo. The text will be displayed in your recipient’s inbox, 
                                        just below the subject."
                  />
                )}
              />
            </div>
            {errors.previewtext && errors.previewtext.type === "required" && (
              <span className={"error__feedback"}>
                {errors.previewtext.message}
              </span>
            )}
          </div>
          <div className="col-span-4  mt-4">
            <div className={`form__item `}>
              <Controller
                name="emails"
                control={control}
                defaultValue=""
                render={({ field, formState }) => (
                  <TextField
                    fullWidth
                    multiline
                    maxRows={4}
                    label="To Email"
                    variant="standard"
                    {...field}
                    error={!!formState.errors?.emails}
                    helperText="Enter the address of the receiver"
                  />
                )}
              />
            </div>
            {errors.emails && errors.emails.type === "required" && (
              <span className={"error__feedback"}>{errors.emails.message}</span>
            )}
          </div>
          <div className="col-span-4 mt-4 ">
            <div className={`form__item `}>
              <Controller
                name="from"
                control={control}
                defaultValue=""
                render={({ field, formState }) => (
                  <TextField
                    fullWidth
                    variant="standard"
                    label="From Name"
                    name={"from"}
                    {...field}
                    error={!!formState.errors?.from}
                    helperText="Enter a name (e.g. your company name) to help campaign recipients recognize you in their inbox."
                  />
                )}
              />
            </div>
            {errors.from && errors.from.type === "required" && (
              <span className={"error__feedback"}>{errors.from.message}</span>
            )}
          </div>
        </div>
      </ModalWrapper>
      <Drawer
        anchor={"right"}
        open={historyModal}
        onClose={toggleDrawer(false)}
      >
        <Box
          sx={{
            width: 550,
            height: "100%",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            flexDirection: "column",
          }}
        >
          <Typography
            variant="h6"
            sx={{
              marginLeft: 2,
              marginTop: 10,
              alignSelf: "start",
            }}
          >
            Email History
          </Typography>
          <Divider />
          <Box
            sx={{
              backgroundColor: "#EAF0FD",
              borderRadius: 4,
              width: 550,
              height: "100%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexDirection: "column",
            }}
          >
            {_.isEmpty(emailHistory) ? (
              <>
                <CircularProgress />
              </>
            ) : (
              <>
                {/* email history from API */}
                {_.map(emailHistory, (email) => {
                  return (
                    <Typography key={email.id} variant="h6">
                      {email.name}
                    </Typography>
                  );
                })}
              </>
            )}
          </Box>
          <Button
            onClick={() => {
              setHistoryModal(false);
            }}
            variant="outlined"
            sx={{ alignSelf: "middle", marginBottom: 2 }}
          >
            Back
          </Button>
        </Box>
      </Drawer>
    </>
  );
};

export default EmailLead;
