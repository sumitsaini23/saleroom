import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";

import Breadcrumb from "../../components/Breadcrumb/Breadcrumb";
import ProductCmp from "../MyProducts/ProductCmp";
import AddCardIconCmp from "../../components/AddCardIconCmp";
import {
  getProductByCategoryId,
  resetCategoryProducts,
} from "../../reducers/productSlice";
import requestsApi from "../../app/requestsApi";
import Swal from "sweetalert2";
import doneicn from "../../assets/images/icon/doneicn.gif";

/**
 * Component Start
 * @param {*} props
 * @returns
 */
const CategoryProductsCmp = () => {
  const dispatch = useDispatch();
  const location = useLocation();
  const navigate = useNavigate();
  const products = useSelector((state) => state.products.productsByCategory);
  let categoryId = location.state?.categoryId;
  let categoryName = location.state?.categoryName;

  useEffect(() => {
    dispatch(getProductByCategoryId({ categoryId }));
  }, []);
  /**
   * component will unmount
   */
  useEffect(() => {
    return () => {
      dispatch(resetCategoryProducts());
    };
  }, []);

  const goToEditProduct = (pId, cId) => {
    navigate("/editProduct", {
      state: {
        productId: pId,
        categoryId: cId,
      },
    });
  };

  const confirmDeleteProduct = (productId) => {
    Swal.fire({
      title: "Are you sure?",
      text: "Want to change access level",
      icon: "warning",
      showCancelButton: true,

      confirmButtonColor: "#174FBA",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, do it!",
    }).then((result) => {
      if (result.isConfirmed) {
        deleteProduct(productId);
      }
    });
  };

  const deleteProduct = async (productId) => {
    await requestsApi
      .deleteRequest(`/v1/products/${productId}`)
      .then(function (response) {
        Swal.fire({
          title: `Product deleted successfully`,
          imageUrl: doneicn,
          imageWidth:"100",
          showConfirmButton: false,
          timer: 2000,
        });
        dispatch(getProductByCategoryId({ categoryId }));
      })
      .catch(function (error) {
        // console.log("error", error);
      });
  };

  /**
   * Return Component
   */
  return (
    <div>
      <Breadcrumb />
      <div className="p-6">
        <div className="mb-6">
          <h2 className="text-3xl font-bold mb-1">{categoryName}</h2>
          <p className="text-[18px] font-normal mb-5">
            Products {`(${products.length})`}
          </p>
        </div>
        <div className="flex px-6">
          <div className="w-full">
            {/* categories tab content */}
            <div className="grid grid-cols-4 gap-7" id="link1">
              {products.map((prodct, index) => (
                <ProductCmp
                  product={prodct}
                  productId={prodct.productId}
                  productCategoryId={categoryId}
                  index={index}
                  key={`pro-${index}`}
                  goToEditProduct={goToEditProduct}
                  confirmDeleteProduct={confirmDeleteProduct}
                />
              ))}
              <AddCardIconCmp title="Product" categoryId={categoryId} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CategoryProductsCmp;
