import React from "react";
import PropTypes from "prop-types";
import Dialog from "@mui/material//Dialog";
import DialogActions from "@mui/material//DialogActions";
import DialogContent from "@mui/material//DialogContent";
import DialogTitle from "@mui/material//DialogTitle";
import Button from "@mui/material/Button";

const PreviewModalWrapper = (props) => {
  //const fullScreen = useMediaQuery(theme.breakpoints.down("md"));
  //Size: xs,sm,md,lg,xl
  return (
    <React.Fragment>
      <Dialog
       sx={{
       
        ".MuiDialog-paper": {
           minHeight: "70vh",
          maxHeight: "80vh",
           overflowY:"auto",
           textAlign:"center"
        },
    }}
        padding={20}
        fullWidth={true}
        // sx={{ minHeight: "800px" }}
        maxWidth={props.size}
        open={props.isPopUpShow}
        onClose={(_, reason) => {
          if (reason !== "backdropClick") {
            props.toggleModel();
          }
        }}
        aria-labelledby="responsive-dialog-title"
      >
        <DialogTitle id="max-width-dialog-title">{props.heading}</DialogTitle>
        <DialogContent>{props.children}</DialogContent>

        {props.showCloseButton === false ? null : (
          <DialogActions className="p-4" sx={{ justifyContent: "end" }}>
            <Button
              variant="outlined"
              className="btnoutline "
              style={{ textTransform: "none" }}
              onClick={props.toggleModel}
            >
              Close
            </Button>
          </DialogActions>
        )}
      </Dialog>
    </React.Fragment>
  );
};

PreviewModalWrapper.propTypes = {
  heading: PropTypes.string.isRequired,
  isPopUpShow: PropTypes.bool.isRequired,
  size: PropTypes.string.isRequired,
  toggleModel: PropTypes.func.isRequired,
  children: PropTypes.element.isRequired,
};

export default PreviewModalWrapper;
