import React from "react";
import { connect } from "react-redux";
import { useNavigate } from "react-router-dom";
import { Button } from "@mui/material";

function PageNotFound(props) {
  const navigate = useNavigate();
  //// console.log(props);
  // if (props.isAuthenticated === false){
  //     return <Redirect to="/" />
  // }

  const gotoBack = () => {
    navigate(-1);
  };

  return (
    <div className="rounded bg-white p-5 text-center my-5">
      <h2>404</h2>
      <span>Page Not Found</span>
      <div>The page you are looking for doesn't exist.</div>
      <Button onClick={gotoBack} variant="primary">
        Go back
      </Button>
    </div>
  );
}

const mapStateToProps = (state) => {
  return {
    isAuthenticated: false,
    //isAuthenticated: state.auth.authenticated,
  };
};

export default connect(mapStateToProps, null)(PageNotFound);
