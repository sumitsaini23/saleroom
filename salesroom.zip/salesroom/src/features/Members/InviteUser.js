import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useForm, Controller } from "react-hook-form";
import OtpInput from "react-otp-input";
import { Buffer } from "buffer";
import Swal from "sweetalert2";
import { Button, TextField } from "@mui/material";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import IconButton from "@mui/material/IconButton";
import Dialog from "@mui/material//Dialog";
import DialogActions from "@mui/material//DialogActions";
import DialogContent from "@mui/material//DialogContent";
//import DialogContentText from '@mui/material//DialogContentText';
import DialogTitle from "@mui/material//DialogTitle";

import Loader from "../../components/Loader";
import "../Signup/Signup.module.scss";
import { emailPattern } from "../../common/utility";
import requestsApi from "../../app/requestsApi";
import doneicn from "../../assets/images/icon/doneicn.gif";

const validateSchema = Yup.object({
  email: Yup.string()
    .required("Required")
    .matches(emailPattern, "Invalid emailId"),
  username: Yup.string().required("Required"),
  password: Yup.string()
    .required("Required")
    .matches(/[a-zA-Z0-9]/, "Password allowd only alphanumeric characters.")
    .min(8, "Min 8 charactor require")
    .max(16, "Too Long!"),
  confirmPassword: Yup.string()
    .required("Required")
    .oneOf([Yup.ref("password"), null], "Passwords must match"),
}).required();

export default function InviteUser() {
  const navigate = useNavigate();
  let params = useParams();
  const [showPassword, setShowPassword] = useState(false);
  const [showConfPassword, setShowConfPassword] = useState(false);
  const [objParams, setObjParams] = useState({});
  const [userPostData, setUserPostData] = useState({});
  const [otpReferenceId, setOtpReferenceId] = useState("");
  const [isRegUser, setIsRegUser] = useState(false);
  const [showOtpModal, setShowOtpModal] = useState(false);
  const [Isloading, setLoading] = useState(false);
  const [IsloadingTwo, setLoadingTwo] = useState(false);

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validateSchema),
  });

  const {
    control: otpForm,
    handleSubmit: handleOtpSubmit,
    formState: { errors: otpErrors },
  } = useForm();

  useEffect(() => {
    let buff = Buffer.from(params.encodeId, "base64");
    let base64ToObj = JSON.parse(buff.toString("ascii"));

    setObjParams(base64ToObj);
    if (base64ToObj.hasOwnProperty("userId")) {
      setIsRegUser(true);
      getUserDetials(base64ToObj.userId);
    }
  }, []);

  const handleClickShowPassword = () => {
    setShowPassword(!showPassword);
  };

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };

  const handleClickShowConfPassword = () => {
    setShowConfPassword(!showConfPassword);
  };

  const handleMouseDownConfPassword = (event) => {
    event.preventDefault();
  };

  const getUserDetials = (userId) => {
    requestsApi
      .getRequest(`/v1/users/${userId}`)
      .then(function (response) {
        reset({
          email: response.email,
        });
      })
      .catch(function (error) {
        // console.log("error", error);
      });
  };

  const generateOtp = (email) => {
    requestsApi
      .postRequest("v1/login/templates/send", {
        identifier: email,
        verificationType: "EMAIL",
      })
      .then(function (response) {
        setOtpReferenceId(response.otpReferenceId);
        setShowOtpModal(true);
      })
      .catch(function (error) {
        setLoading(false);
        // console.log("error", error);
      });
  };

  const onOtpSubmit = (data) => {
    setLoadingTwo(true);
    requestsApi
      .postRequest("v1/login/templates/verify", {
        identifier: userPostData.email,
        otp: data.otp,
        otpReferenceId: otpReferenceId,
        verificationType: "EMAIL",
      })
      .then(function (response) {
        setLoadingTwo(false);
        setShowOtpModal(false);
        saveUserDetails(userPostData);
      })
      .catch(function (error) {
        setLoadingTwo(false);
        // console.log("error", error);
      });
  };

  const onSubmit = (data) => {
    let postData = {
      businessId: objParams.businessId,
      email: data.email,
      fullName: data.username,
      password: data.password,
      role: "USER",
    };

    if (!isRegUser) {
      setUserPostData(postData);
      generateOtp(data.email);
    } else {
      saveUserDetails(postData);
    }
  };

  const saveUserDetails = (postData) => {
    setLoading(true);
    requestsApi
      .postRequest("/v1/users", postData)
      .then(function (response) {
        setLoading(false);
        reset();
        Swal.fire({
          title: "User details saved successfully",
          imageUrl: doneicn,
          imageWidth:"100",
          showConfirmButton: false,
          timer: 2000,
        });
        navigate("/");
      })
      .catch(function (error) {
        setLoading(false);
        // console.log("error", error);
      });
  };
  return (
    <div className="11bg-[#ecedf0] signup">
      <div className="grid grid-cols-1  h-screen">
        <div className="header flex justify-center h-0">
          <img
            alt="Salesroom_logo"
            src={require("../../assets/images/icon/Salesroom_logo.png")}
            className="h-20 mt-0"
          />
        </div>
        <main>
          <div className="formbox grid  ">
            <form>
              <div className="header  mb-7">
                <h2 className="text-[26px] font-medium">
                  Get started with Salesroom
                </h2>
              </div>
              <div className="grid grid-cols-4 gap-3">
                <div className="body col-span-4">
                  <div>
                    <Controller
                      name="email"
                      control={control}
                      defaultValue=""
                      render={({ field, formState }) => (
                        <TextField
                          fullWidth
                          id="email"
                          label="Email *"
                          variant="standard"
                          {...field}
                          inputProps={{
                            readOnly: isRegUser,
                          }}
                          error={!!formState.errors?.email}
                        />
                      )}
                    />
                    {errors.email && errors.email.type === "required" && (
                      <span className={"error__feedback"}>
                        {errors.email.message}
                      </span>
                    )}
                    {errors.email && errors.email.type === "matches" && (
                      <span className={"error__feedback"}>
                        {errors.email.message}
                      </span>
                    )}
                  </div>
                  <div
                    style={{
                      marginTop: "20px",
                    }}
                  >
                    <Controller
                      name="username"
                      control={control}
                      defaultValue=""
                      render={({ field, formState }) => (
                        <TextField
                          fullWidth
                          id="username"
                          label="User Name *"
                          variant="standard"
                          {...field}
                          error={!!formState.errors?.username}
                        />
                      )}
                    />
                    {errors.username && errors.username.type === "required" && (
                      <span className={"error__feedback"}>
                        {errors.username.message}
                      </span>
                    )}
                  </div>
                  <div
                    className="mb-5"
                    style={{
                      display: "flex",
                      marginTop: "20px",
                    }}
                  >
                    <Controller
                      name="password"
                      control={control}
                      defaultValue=""
                      render={({ field, formState }) => (
                        <TextField
                          type={showPassword ? "test" : "password"}
                          fullWidth
                          id="password"
                          label="Enter password *"
                          variant="standard"
                          {...field}
                          error={!!formState.errors?.password}
                        />
                      )}
                    />
                    <div className="pwdeyeicon">
                      <IconButton
                        position="end"
                        aria-label="toggle password visibility"
                        onClick={handleClickShowPassword}
                        onMouseDown={handleMouseDownPassword}
                      >
                        {showPassword ? <VisibilityOff /> : <Visibility />}
                      </IconButton>
                    </div>
                  </div>
                  {errors.password && errors.password.type === "required" && (
                    <span className={"error__feedback"}>
                      {errors.password.message}
                    </span>
                  )}
                  {errors.password && errors.password.type === "matches" && (
                    <span className={"error__feedback"}>
                      {errors.password.message}
                    </span>
                  )}
                  {errors.password && errors.password.type === "min" && (
                    <span className={"error__feedback"}>
                      {errors.password.message}
                    </span>
                  )}
                  {errors.password && errors.password.type === "max" && (
                    <span className={"error__feedback"}>
                      {errors.password.message}
                    </span>
                  )}

                  <div
                    style={{
                      display: "flex",
                      marginTop: "20px",
                    }}
                  >
                    <Controller
                      name="confirmPassword"
                      control={control}
                      defaultValue=""
                      render={({ field, formState }) => (
                        <TextField
                          type={showConfPassword ? "test" : "password"}
                          fullWidth
                          id="confpassword"
                          label="Enter confirm password *"
                          variant="standard"
                          {...field}
                          error={!!formState.errors?.confirmPassword}
                        />
                      )}
                    />

                    <div className="pwdeyeicon">
                      <IconButton
                        position="end"
                        aria-label="toggle password visibility"
                        onClick={handleClickShowConfPassword}
                        onMouseDown={handleMouseDownConfPassword}
                      >
                        {showConfPassword ? <VisibilityOff /> : <Visibility />}
                      </IconButton>
                    </div>
                  </div>
                  {errors.confirmPassword &&
                    errors.confirmPassword.type === "required" && (
                      <span className={"error__feedback"}>
                        {errors.confirmPassword.message}
                      </span>
                    )}
                  {errors.confirmPassword &&
                    errors.confirmPassword.type === "oneOf" && (
                      <span className={"error__feedback"}>
                        {errors.confirmPassword.message}
                      </span>
                    )}
                  <div
                    className={
                      "form__item button__items d-flex justify-content-end"
                    }
                  ></div>
                </div>
                <div className="footer col-span-4 flex justify-between mb-5">
                  <div></div>

                  <Button
                    onClick={handleSubmit(onSubmit)}
                    type="submit"
                    className="btn-blue"
                  >
                    {Isloading ? <Loader isLoading={Isloading} /> : "Submit"}
                  </Button>
                </div>
              </div>
            </form>
          </div>
          {showOtpModal && (
            <Dialog
              padding={20}
              fullWidth={true}
              maxWidth="xs"
              open={showOtpModal}
              aria-labelledby="responsive-dialog-title"
            >
              <DialogTitle id="max-width-dialog-title">OTP verify</DialogTitle>
              <DialogContent>
                <div>
                  <Controller
                    name="otp"
                    //value={otpCode}
                    rules={{
                      required: true,
                    }}
                    control={otpForm}
                    render={({ field: { onChange, value } }) => (
                      <OtpInput
                        value={value}
                        onChange={onChange}
                        numInputs={6}
                        separator={
                          <span
                            style={{
                              width: "8px",
                            }}
                          ></span>
                        }
                        isInputNum={true}
                        shouldAutoFocus={true}
                        inputStyle={{
                          borderBottom: "1px solid #136fcb",
                          borderRadius: "0px",
                          width: "55px",
                          height: "55px",
                          fontSize: "20px",
                          color: "#000",
                          fontWeight: "500",
                          caretColor: "blue",
                        }}
                        focusStyle={{
                          borderBottom: "1px solid #CFD3DB",
                        }}
                      />
                    )}
                  />

                  {otpErrors.otp && otpErrors.otp.type === "required" && (
                    <span className="errormsg" role="alert">
                      OTP is required
                    </span>
                  )}
                </div>
              </DialogContent>
              <DialogActions className="p-4 ">
                <Button
                  onClick={handleOtpSubmit(onOtpSubmit)}
                  type="submit"
                  className="btn-blue"
                >
                  {IsloadingTwo ? (
                    <Loader isLoading={IsloadingTwo} />
                  ) : (
                    "Submit"
                  )}
                </Button>
              </DialogActions>
            </Dialog>
          )}
        </main>
      </div>
    </div>
  );
}
