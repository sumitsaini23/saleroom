import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";

import { Button, TextField } from "@mui/material";
import MenuItem from "@mui/material/MenuItem";
import ReactHookFormSelect from "../../components/UI/ReactHookFormSelect";
import { saveproductDetails } from "../../reducers/productSlice";

/**
 * Product details validation
 */

const detailsvalidateschema = Yup.object({
  productId: Yup.string().required("Required"),
  currency: Yup.string().required("Required"),
  sellingPrice: Yup.number().required("Required"),
  productName: Yup.string()
    .required("Required")
    .min(2, "too short")
    .max(100, "Too long"),
  productTagline: Yup.string().required("Required"),
  description: Yup.string().required("Required"),
}).required();

function TabContentDetails(props) {
  const dispatch = useDispatch();
  const location = useLocation();
  const businessId = useSelector((state) => state.auth?.user?.businessId);
  const categories = useSelector((state) => state.categories.categories);
  const categoryId = location.state?.categoryId;
  const productName = location.state?.productName;
  //// console.log("location", location);
  /**
   * Form set
   */
  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(detailsvalidateschema),
    mode: "onTouched",
  });
  /**
   * Component mount
   */
  useEffect(() => {
    if (props.action && props.action === "Edit") {
      let proinfo = props.prodata;
      //// console.log("proinfo", proinfo);
      reset({
        category: categoryId,
        productId: proinfo?.productUniqueId,
        productName: proinfo?.productName,
        productTagline: proinfo?.tagline,
        sellingPrice: proinfo?.priceInfo?.price,
        description: proinfo?.productDescription,
      });
      dispatch(
        saveproductDetails({
          businessId: businessId,
          categoryId: categoryId,
          currency: "INR",
          price: proinfo?.priceInfo?.price,
          productDescription: proinfo?.productDescription,
          productName: proinfo?.productName,
          productUniqueId: proinfo?.productUniqueId,
          tagline: proinfo?.tagline,
        })
      );
    } else {
      reset({
        category: categoryId,
        productName: productName,
      });
    }
  }, [
    props.action,
    props.prodata,
    businessId,
    categoryId,
    productName,
    dispatch,
    reset,
  ]);

  const onSaveProduct = (data) => {
    dispatch(
      saveproductDetails({
        businessId: businessId,
        categoryId: categoryId,
        currency: data.currency,
        price: data.sellingPrice,
        productDescription: data.description,
        productName: data.productName,
        productUniqueId: data.productId,
        tagline: data.productTagline,
      })
    );
    props.changeTab("Uploads");
    //dispatch(startLoader());
    //dispatch(stopLoader());
    //reset();
  };
  return (
    <div className="max-w-[800px]">
      <form onSubmit={handleSubmit(onSaveProduct)}>
        {/* 1 */}
        <div className="">
          <div className="col-span-2 ">
            <ReactHookFormSelect
              id="category-select"
              name="category"
              label="Category"
              control={control}
              defaultValue={categoryId}
              fullWidth
              variant="standard"
              disabled={true}
            >
              <MenuItem value="">
                <em>None</em>
              </MenuItem>
              {categories.map((category) => (
                <MenuItem key={category.categoryId} value={category.categoryId}>
                  {category.categoryName}
                </MenuItem>
              ))}
            </ReactHookFormSelect>
          </div>
          {/* 2 */}

          <div className="col-span-2  mt-5">
            <Controller
              name="productId"
              control={control}
              defaultValue=""
              render={({ field, formState }) => (
                <TextField
                  fullWidth
                  id="productId"
                  label="ProductId"
                  variant="standard"
                  {...field}
                  error={!!formState.errors?.productId}
                />
              )}
            />
            {errors.productId && errors.productId.type === "required" && (
              <span className={"error__feedback"}>
                {errors.productId.message}
              </span>
            )}
          </div>
          {/* <div className="header mt-8">
                        <h5 className="text-[20px] font-bold">Product Info</h5>
                    </div> */}
          {/* <label htmlFor="SellingPrice">
                        Selling Price ( Optional )
                    </label> */}
          <div className="grid grid-cols-5 gap-3 mt-8">
            <div className="col-span-1">
              {/* 1 */}
              <Controller
                name="currency"
                control={control}
                defaultValue="INR"
                render={({ field, formState }) => (
                  <TextField
                    fullWidth
                    id="inr"
                    label="INR"
                    variant="standard"
                    disabled={true}
                    {...field}
                    error={!!formState.errors?.inr}
                  />
                )}
              />
              {errors.inr && errors.inr.type === "required" && (
                <span className={"error__feedback"}>{errors.inr.message}</span>
              )}
            </div>
            <div className="col-span-4 ">
              {/* 2 */}
              <Controller
                name="sellingPrice"
                control={control}
                defaultValue=""
                render={({ field, formState }) => (
                  <TextField
                    fullWidth
                    id="sellingPrice"
                    label="Selling Price"
                    variant="standard"
                    {...field}
                    error={!!formState.errors?.sellingPrice}
                  />
                )}
              />
              {errors.sellingPrice &&
                errors.sellingPrice.type === "required" && (
                  <span className={"error__feedback"}>
                    {errors.sellingPrice.message}
                  </span>
                )}
            </div>

            {/* 3 */}
            <div className="col-span-5 mt-5">
              <Controller
                name="productName"
                control={control}
                defaultValue=""
                render={({ field, formState }) => (
                  <TextField
                    fullWidth
                    id="productName"
                    label="Product Name"
                    variant="standard"
                    {...field}
                    error={!!formState.errors?.productName}
                  />
                )}
              />
              {errors.productName && errors.productName.type === "required" && (
                <span className={"error__feedback"}>
                  {errors.productName.message}
                </span>
              )}
              {errors.productName && errors.productName.type === "min" && (
                <span className={"error__feedback"}>
                  {errors.productName.message}
                </span>
              )}
              {errors.productName && errors.productName.type === "max" && (
                <span className={"error__feedback"}>
                  {errors.productName.message}
                </span>
              )}
            </div>
            {/* 4 */}
            <div className="col-span-5  mt-5">
              <Controller
                name="productTagline"
                control={control}
                defaultValue=""
                render={({ field, formState }) => (
                  <TextField
                    fullWidth
                    id="productTagline"
                    label="Product Tagline *"
                    variant="standard"
                    {...field}
                    error={!!formState.errors?.productTagline}
                  />
                )}
              />
              {errors.productTagline &&
                errors.productTagline.type === "required" && (
                  <span className={"error__feedback"}>
                    {errors.productTagline.message}
                  </span>
                )}
            </div>
            {/* 5 */}
            <div className="col-span-5  mt-5">
              <Controller
                name="description"
                control={control}
                defaultValue=""
                render={({ field, formState }) => (
                  <TextField
                    fullWidth
                    multiline
                    maxRows={4}
                    id="description"
                    label="Description *"
                    variant="standard"
                    {...field}
                    error={!!formState.errors?.productTagline}
                  />
                )}
              />
              {errors.description && errors.description.type === "required" && (
                <span className={"error__feedback"}>
                  {errors.description.message}
                </span>
              )}
            </div>

            <div className="col-span-5 mt-5 ">
              <Button
                type="submit"
                disabled={false}
                variant="contained"
                className="btn-blue float-right"
              >
                Next
              </Button>
            </div>
            {/* <div className="w-full flex justify-end py-7 ">
                            <div className="btnclr">
                                <Button
                                    type="submit"
                                    disabled={false}
                                    variant="contained"
                                    className=" text-[20px] px-6 py-1 btn-blue"
                                >
                                    Save
                                </Button>
                            </div>
                        </div> */}
          </div>
        </div>
      </form>
    </div>
  );
}

export default TabContentDetails;
