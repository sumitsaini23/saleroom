import { Button, TextField } from "@mui/material";

import MenuItem from "@mui/material/MenuItem";
import React, { useState } from "react";
import Breadcrumb from "../../components/Breadcrumb/Breadcrumb";
import { Navigate, useNavigate } from "react-router-dom";
const currencies = [
  {
    value: "Bi-pap",
    label: "Bi- PAP",
  },
  {
    value: "CPAP",
    label: "CPAP",
  },
];

// const [currency] = React.useState('EUR');

const Email = () => {
  const navigate = useNavigate();

  const navigateHome = () => {
    // 👇️ navigate to /
    navigate("/EmailTemplates");
  };
  const [openTab, setOpenTab] = React.useState("Team");

  return (
    <>
      <Breadcrumb />
      <div className="p-6 grid grid-cols-1 md:grid-cols-4 lg:grid-cols-4 xl:grid-cols-4">
        <div className="mb-0 col-span-3">
          <h2 className="text-3xl font-bold mb-0">Email Templates</h2>
          {/* <h2 className="text-lg">2 members</h2> */}
        </div>
        <div className="grid md:grid-cols-4 gap-5">
          <div className="col-span-2">
            <TextField
              fullWidth
              variant="outlined"
              id="outlined-select-currency"
              select
              label="Select Product"
              // value={currency}
              // onChange={handleChange}
              // helperText="Please select your currencyasdfds"
            >
              {currencies.map((option) => (
                <MenuItem key={option.value} value={option.value}>
                  {option.label}
                </MenuItem>
              ))}
            </TextField>{" "}
          </div>
          <div className="col-span-2">
            <TextField
              fullWidth
              id="outlined-select-currency"
              select
              label="Language"
              variant="outlined"
              // value={currency}
              // onChange={handleChange}
              // helperText="Please select your currencyasdfds"
            >
              {currencies.map((option) => (
                <MenuItem key={option.value} value={option.value}>
                  {option.label}
                </MenuItem>
              ))}
            </TextField>{" "}
          </div>
        </div>
      </div>

      <div className="flex m-5 mt-0">
        <div className="w-fit">
          <ul
            className="tabs-btn flex mb-0 list-none flex-wrap pt-3 pb-4 flex-row"
            role="tablist"
          >
            {/* Team tab */}
            <li className="-mb-px mr-2 last:mr-0 text-center">
              <a
                className={
                  "text-xs font-bold  px-5 py-3 shadow-lg rounded block leading-normal" +
                  (openTab === "Team" ? " active" : "")
                }
                onClick={(e) => {
                  e.preventDefault();
                  setOpenTab("Team");
                }}
                data-toggle="tab"
                href="#link1"
                role="tablist"
              >
                Pre-sales
              </a>
            </li>
            {/* all groups tab */}
            <li className="-mb-px mr-2 last:mr-0 text-center">
              <a
                className={
                  "text-xs font-bold  px-5 py-3 shadow-lg rounded block leading-normal" +
                  (openTab === "groups" ? " active" : "")
                }
                onClick={(e) => {
                  e.preventDefault();
                  setOpenTab("groups");
                }}
                data-toggle="tab"
                href="#link2"
                role="tablist"
              >
                Post-sales
              </a>
            </li>

            <li className="-mb-px mr-2 last:mr-0 text-center">
              <a
                className={
                  "text-xs font-bold  px-5 py-3 shadow-lg rounded block leading-normal" +
                  (openTab === "distributors" ? " active" : "")
                }
                onClick={(e) => {
                  e.preventDefault();
                  setOpenTab("distributors");
                }}
                data-toggle="tab"
                href="#link2"
                role="tablist"
              >
                Follow-up
              </a>
            </li>

            <li className="-mb-px mr-2 last:mr-0 text-center">
              <a
                className={
                  "text-xs font-bold  px-5 py-3 shadow-lg rounded block leading-normal" +
                  (openTab === "thankyou" ? " active" : "")
                }
                onClick={(e) => {
                  e.preventDefault();
                  setOpenTab("thankyou");
                }}
                data-toggle="tab"
                href="#link2"
                role="tablist"
              >
                Thank you
              </a>
            </li>

            <li className="-mb-px mr-2 last:mr-0 text-center">
              <a
                className={
                  "text-xs font-bold  px-5 py-3 shadow-lg rounded block leading-normal" +
                  (openTab === "wishes" ? " active" : "")
                }
                onClick={(e) => {
                  e.preventDefault();
                  setOpenTab("wishes");
                }}
                data-toggle="tab"
                href="#link2"
                role="tablist"
              >
                Wishes
              </a>
            </li>

            <li className="-mb-px mr-2 last:mr-0 text-center">
              <a
                className={
                  "text-xs font-bold  px-5 py-3 shadow-lg rounded block leading-normal" +
                  (openTab === "feedback" ? " active" : "")
                }
                onClick={(e) => {
                  e.preventDefault();
                  setOpenTab("feedback");
                }}
                data-toggle="tab"
                href="#link2"
                role="tablist"
              >
                Feedback
              </a>
            </li>
          </ul>

          {/* Team tab content */}
          <div
            className={
              openTab === "Team"
                ? "grid grid-cols-1 md:grid-cols-1 lg:grid-cols-1 xl:grid-cols-1 gap-6 mt-6 text-center"
                : "hidden"
            }
            id="link1"
          >
            <div class="boxContainer">
              <div className="brdrblack previewbtn col-span-3">
                {/* <Button className="btn-black " style={{ }}  >Preview</Button> */}
              </div>
            </div>

            <div className="col-span-3 mt-5 ">
              <Button
                type="submit"
                disabled={false}
                onClick={navigateHome}
                variant="contained"
                className="btn-blue float-right"
              >
                Next
              </Button>
            </div>
          </div>

          {/* all groups tab content */}

          <div
            className={
              openTab === "groups"
                ? "grid grid-cols-1 md:grid-cols-1 lg:grid-cols-1 xl:grid-cols-1 gap-6 mt-6"
                : "hidden"
            }
            id="link1"
          >
            <p>2nd</p>
          </div>

          {/* all groups tab content */}
          <div
            className={
              openTab === "distributors"
                ? "grid grid-cols-1 md:grid-cols-1 lg:grid-cols-1 xl:grid-cols-1 gap-6 mt-6"
                : "hidden"
            }
            id="link1"
          >
            <p>3rd</p>
          </div>

          {/* all groups tab content */}
          <div
            className={
              openTab === "thankyou"
                ? "grid grid-cols-1 md:grid-cols-1 lg:grid-cols-1 xl:grid-cols-1 gap-6 mt-6"
                : "hidden"
            }
            id="link1"
          >
            <p>4th</p>
          </div>

          {/* all groups tab content */}
          <div
            className={
              openTab === "wishes"
                ? "grid grid-cols-1 md:grid-cols-1 lg:grid-cols-1 xl:grid-cols-1 gap-6 mt-6"
                : "hidden"
            }
            id="link1"
          >
            <p>5th</p>
          </div>

          {/* all groups tab content */}
          <div
            className={
              openTab === "feedback"
                ? "grid grid-cols-1 md:grid-cols-1 lg:grid-cols-1 xl:grid-cols-1 gap-6 mt-6"
                : "hidden"
            }
            id="link1"
          >
            <p>6th</p>
          </div>
        </div>
      </div>
    </>
  );
};

export default Email;
