import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import FileViewer from "react-file-viewer";
import Breadcrumb from "../../components/Breadcrumb/Breadcrumb";
import FileMenu from "../../components/UI/FileMenu";
import PreviewModalWrapper from "../../components/UI/PreviewModalWrapper";
import requestsApi from "../../app/requestsApi";
import UploadCardIconCmp from "../../components/UploadCardIconCmp";
import {
  checkObjectEmpty,
  getFileExtensionByUrl,
  getSortName,
  getFileNameByUrl,
} from "../../common/utility";
import { getAllCategories } from "../../reducers/categorySlice";
import { getAllProducts } from "../../reducers/productSlice";

/**
 * Component Start
 */
const Manuals = () => {
  const dispatch = useDispatch();
  const userRole = useSelector((state) => state.auth?.user?.role);
  const businessId = useSelector((state) => state.auth?.user?.businessId);
  const [manualFiles, setManualFiles] = useState({});
  const [previewModal, setPreviewModal] = useState(false);
  const [pdfDocUrl, setPdfDocUrl] = useState("");

  useEffect(() => {
    if (businessId) {
      getManualFilesByBusinessId();
      dispatch(getAllCategories({ businessId }));
      dispatch(getAllProducts({ businessId, offset: 0 }));
    }
  }, [businessId, dispatch]);
  /**
   * component will unmount
   */
  useEffect(() => {
    return () => {
      setManualFiles({});
    };
  }, []);

  const getManualFilesByBusinessId = async () => {
    await requestsApi
      .getRequest(`/v1/dashboard/search`, {
        businessId: businessId,
        filterBy: "MANUAL",
      })
      .then(function (response) {
        //// console.log("response", response);
        setManualFiles(response);
      })
      .catch(function (error) {
        // console.log("error", error);
      });
  };

  const getTotalManualsCount = () => {
    return checkObjectEmpty(manualFiles) ? manualFiles.totalManualsCount : 0;
  };

  const getManualFiles = () => {
    return checkObjectEmpty(manualFiles) ? manualFiles.manuals : [];
  };

  const handlePreviewModal = () => {
    let val = !previewModal;
    if (val === false) {
      setPdfDocUrl("");
    }
    setPreviewModal(val);
  };

  /**
   * Child Component
   */
  const ManualCardCmp = ({ imgUrl }) => {
    return (
      <div className="mainbox">
        {/* <Card key={ukey}> */}
        {/* <CardContent className="cardcss"> */}
        {/* <div className="text-center productimg">
                        <img src={imgUrl} alt="img" />
                        <h2 className="font-regular font-poppins uppercase fntclr mt-3">
                           
                            vaibhav
                        </h2>
                    </div> */}

        <div className="boxMain">
          <div className="boxinner">
            <div className="boxOne">
              <div className="boxOneinner">
                <img
                  style={{ paddingTop: "25px" }}
                  src={
                    getFileExtensionByUrl(imgUrl) === "pdf"
                      ? require(`../../assets/images/image/awesome-file-pdf.png`)
                      : require(`../../assets/images/image/Group 658.png`)
                  }
                  alt="img"
                  onClick={() => {
                    setPdfDocUrl(imgUrl);
                    handlePreviewModal();
                  }}
                />
              </div>
            </div>
          </div>
          <div className="boxTwo">
            <img
              src={
                getFileExtensionByUrl(imgUrl) === "pdf"
                  ? require(`../../assets/images/image/awesome-file-pdf.png`)
                  : require(`../../assets/images/image/Group 658.png`)
              }
              alt="img"
            />
            <span>
              {" "}
              {getSortName(getFileNameByUrl(imgUrl, "/MANUAL/"), 15)}{" "}
            </span>
            <span
              style={{
                float: "right",
                color: "#ccc",
                marginTop: "-3.5%",
              }}
            >
              {" "}
              <FileMenu url={imgUrl} />{" "}
            </span>
          </div>
        </div>
      </div>

      // <Card sx={{ minWidth: 205 }}>
      //     <CardContent>
      //         <div className="text-center">
      //             <div className="innerpaddingimg cadmainimg">

      //                 <iframe
      //                     title="PDF in an i-Frame"
      //                     srcdoc={imgUrl}
      //                     height="100"
      //                     width="250"
      //                     sandbox="allow-same-origin"
      //                 ></iframe>
      //             </div>
      //             <div className="cadimg mt-3">
      //                 <img
      //                     src={require(`../../assets/images/image/awesome-file-pdf.png`)}
      //                     alt="img"
      //                 />
      //                 <span
      //                     className="font-regular font-poppins pt-2 fntclr "
      //                     style={{ fontSize: ".75rem" }}
      //                 >

      //                 </span>
      //             </div>
      //         </div>
      //         <div></div>
      //         <div></div>
      //     </CardContent>
      // </Card>
    );
  };

  /**
   * Child Component
   */
  const ManualsFileCmp = (props) => {
    return (
      <>
        {props.fileDetails?.map((data, i) => (
          <div key={`${data.productName}_${i}`}>
            <div className="text-xl font-normal mb-1 mt-6">
              {data.productName}
            </div>
            <div
              className={
                "Categories"
                  ? "grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 gap-6 mt-6"
                  : "hidden"
              }
              id="link1"
            >
              {data?.manualsS3Urls?.map((imgUrl, index) => (
                <ManualCardCmp
                  key={`img_${index}_${props.imgDetails?.productId}`}
                  imgUrl={imgUrl}
                />
              ))}
              {userRole === "SUPER_ADMIN" || userRole === "ADMIN" ? (
                <UploadCardIconCmp
                  title="Manual"
                  key={data.productName}
                  productId={data.productId}
                  uploadCategoryType="MANUAL"
                  refreshList={getManualFilesByBusinessId}
                />
              ) : null}
            </div>
          </div>
        ))}
      </>
    );
  };

  return (
    <>
      <Breadcrumb />
      <div className="p-6 mb-3">
        <div className="mb-6">
          <h2 className="text-3xl font-bold mb-1">
            Manuals {`(${getTotalManualsCount()})`}
          </h2>
          {/* <h2 className="text-lg font-normal">2 Manuals</h2> */}
          {manualFiles && getManualFiles().length
            ? getManualFiles()?.map((rec, index) => (
                <ManualsFileCmp
                  fileDetails={rec.manuals}
                  index={index}
                  key={`Manual-${index}`}
                />
              ))
            : null}
          {/* <div className="text-xl mt-5 font-normal">Product 1</div> */}
        </div>
        <PreviewModalWrapper
          heading="Document Preview"
          isPopUpShow={previewModal}
          size="lg"
          toggleModel={handlePreviewModal}
        >
          <FileViewer
            fileType={getFileExtensionByUrl(pdfDocUrl)}
            filePath={pdfDocUrl}
            //errorComponent={CustomErrorComponent}
            //onError={this.onError}
          />
        </PreviewModalWrapper>
      </div>
    </>
  );
};

export default Manuals;
