import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useNavigate, useLocation } from "react-router-dom";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import Swal from "sweetalert2";
import {
  Button,
  Table,
  TableCell,
  TableContainer,
  TableRow,
  TextField,
  TableBody,
  //TableHead,
} from "@mui/material";

import { startLoader, stopLoader } from "../../reducers/commonSlice";
import { resetCreateProductObj } from "../../reducers/productSlice";
import ModalWrapper from "../../components/UI/ModalWrapper";
import requestsApi from "../../app/requestsApi";
import doneicn from "../../assets/images/icon/doneicn.gif";

/**
 * Specification from
 */
const specificationSchema = Yup.object({
  dimension: Yup.string().required("Required"),
  weight: Yup.string().required("Required"),
}).required();

/**
 * Additional information from
 */
const additionalInfoSchema = Yup.object({
  itemKey: Yup.string().required("Required"),
  itemValue: Yup.string().required("Required"),
}).required();
/**
 * Component
 */
const TabContentSpecification = (props) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const createProductObj = useSelector(
    (state) => state.products.createProductObj
  );
  const [showModal, setShowmodal] = useState(false);
  const [additionInfoObj, setAdditionInfoObj] = useState({});
  let categoryId = location.state?.categoryId;
  let categoryName = location.state?.categoryName;
  /**
   *  Specification from control
   */
  const {
    control: specificationControl,
    handleSubmit: specificationSubmit,
    reset: specificationReset,
    formState: { errors: specificationErrors },
  } = useForm({
    resolver: yupResolver(specificationSchema),
    mode: "onTouched",
  });
  /**
   *  additionalInfo from control
   */
  const {
    control: additionalInfoControl,
    handleSubmit: additionalInfoSubmit,
    reset: additionalInfoReset,
    formState: { errors: additionalInfoErrors },
  } = useForm({
    resolver: yupResolver(additionalInfoSchema),
    mode: "onTouched",
  });
  /**
   *
   */
  useEffect(() => {
    if (props.action && props.action === "Edit") {
      let proinfo = props.prodata;
      //// console.log("proinfo", proinfo);
      specificationReset({
        dimension: proinfo?.productSpecification?.specification?.dimension,
        weight: proinfo?.productSpecification?.specification?.weight,
      });

      if (
        proinfo?.productSpecification?.specification &&
        Object.keys(proinfo?.productSpecification?.specification).length > 0
      ) {
        let additionData = {};
        for (const property in proinfo.productSpecification.specification) {
          if (property !== "dimension" && property !== "weight") {
            additionData = {
              ...additionData,
              [property]: proinfo.productSpecification.specification[property],
            };
          }
        }
        setAdditionInfoObj(additionData);
      }
    }
  }, [props.action, props.prodata, specificationReset]);

  const handleformModal = () => {
    additionalInfoReset();
    setShowmodal(!showModal);
  };

  const handleAdditionInfoSubmit = (data) => {
    dispatch(startLoader());
    let additionData = {
      ...additionInfoObj,
      [data.itemKey]: data.itemValue,
    };

    setAdditionInfoObj(additionData);
    handleformModal();
    dispatch(stopLoader());
  };

  const handleSpecificationSubmit = (data) => {
    let specification = {
      ...additionInfoObj,
      dimension: data.dimension,
      weight: data.weight,
    };

    let postData = {
      ...createProductObj,
      productSpecification: {
        specification: specification,
      },
    };

    if (props.action && props.action === "Edit") {
      postData = { ...postData, productId: props.prodata.productId };
    }
    //// console.log("postData", postData);
    onSaveProducts(postData);
  };

  /**
   * Save products
   */
  const onSaveProducts = async (postData) => {
    dispatch(startLoader());
    let productsaveApi;
    if (props.action && props.action === "Edit") {
      productsaveApi = requestsApi.putRequest("/v1/products", postData);
    } else {
      productsaveApi = requestsApi.postRequest("/v1/products", postData);
    }
    await productsaveApi
      .then(function (response) {
        Swal.fire({
          // title: `${response.productName} Product Created`,
          title: `Product successfully ${
            props.action === "Edit" ? "updated" : "added"
          }`,
          imageUrl: doneicn,
          imageWidth:"100",
          showConfirmButton: false,
          timer: 2000,
        }).then((_result) => {
          setAdditionInfoObj({});
          specificationReset();
          dispatch(resetCreateProductObj());
          navigate("/category/products", {
            state: {
              categoryId: categoryId,
              categoryName: categoryName,
            },
          });
        });
      })
      .catch(function (error) {
        // console.log("error", error);
      })
      .then(function () {
        // always executed
        dispatch(stopLoader());
      });
  };

  /**
   * Update additionInfo value
   */
  const updateAdditionInfoByKey = (e) => {
    let obj = { ...additionInfoObj };
    obj[e.target.name] = e.target.value;
    setAdditionInfoObj(obj);
  };

  return (
    <div className="max-w-[800px]">
      <TableContainer
        style={{
          // width: "700px",
          border: "1px solid #ccc",
          borderRadius: "10px",
        }}
      >
        <Table sx={{ minWidth: 650 }}>
          <TableBody>
            <TableRow>
              <TableCell variant="head">
                <b>Dimension</b>{" "}
              </TableCell>
              <TableCell>
                <Controller
                  name="dimension"
                  control={specificationControl}
                  defaultValue=""
                  render={({ field, formState }) => (
                    <TextField
                      fullWidth
                      id="dimension"
                      label="Enter Dimension *"
                      variant="standard"
                      {...field}
                      error={!!formState.specificationErrors?.dimension}
                    />
                  )}
                />
                {specificationErrors.dimension &&
                  specificationErrors.dimension.type === "required" && (
                    <span className={"error__feedback"}>
                      {specificationErrors.dimension.message}
                    </span>
                  )}
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell variant="head">
                <b>Weight</b>{" "}
              </TableCell>
              <TableCell>
                <Controller
                  name="weight"
                  control={specificationControl}
                  defaultValue=""
                  render={({ field, formState }) => (
                    <TextField
                      fullWidth
                      id="weight"
                      label="Enter Weight *"
                      variant="standard"
                      {...field}
                      error={!!formState.specificationErrors?.weight}
                    />
                  )}
                />
                {specificationErrors.weight &&
                  specificationErrors.weight.type === "typeError" && (
                    <span className={"error__feedback"}>
                      Filed is required and allowed only number
                    </span>
                  )}
              </TableCell>
            </TableRow>
            {Object.keys(additionInfoObj).map((itemkey, index) => (
              <TableRow key={`itemkey-${index}`}>
                <TableCell variant="head">
                  <b>{itemkey}</b>
                </TableCell>
                <TableCell>
                  <TextField
                    fullWidth
                    id={itemkey}
                    name={itemkey}
                    label={`Enter ${itemkey}`}
                    variant="standard"
                    value={additionInfoObj[itemkey]}
                    onChange={(e) => updateAdditionInfoByKey(e)}
                  />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <div className="col-span-5  ">
        <Button type="button" disabled={false} onClick={handleformModal}>
          + Add
        </Button>
      </div>

      <ModalWrapper
        heading="Additional Specification"
        isPopUpShow={showModal}
        size="sm"
        toggleModel={handleformModal}
        saveBtnTitle="Done"
        onsubmit={additionalInfoSubmit(handleAdditionInfoSubmit)}
      >
        <div className="grid grid-cols-4 md:grid-cols-4 lg:grid-cols-4 gap-1 mt-2 ">
          <div className="col-span-4  ">
            <div className={`form__item `}>
              <Controller
                name="itemKey"
                control={additionalInfoControl}
                defaultValue=""
                render={({ field, formState }) => (
                  <TextField
                    fullWidth
                    id="itemKey"
                    label="Enter Parameter *"
                    variant="standard"
                    {...field}
                    error={!!formState.additionalInfoErrors?.itemKey}
                  />
                )}
              />
              {additionalInfoErrors.itemKey &&
                additionalInfoErrors.itemKey.type === "required" && (
                  <span className={"error__feedback"}>
                    {additionalInfoErrors.itemKey.message}
                  </span>
                )}
            </div>
          </div>

          <div className="col-span-4  ">
            <div className={`form__item `}>
              <Controller
                name="itemValue"
                control={additionalInfoControl}
                defaultValue=""
                render={({ field, formState }) => (
                  <TextField
                    fullWidth
                    id="itemKey"
                    label="Enter Value *"
                    variant="standard"
                    {...field}
                    error={!!formState.additionalInfoErrors?.itemValue}
                  />
                )}
              />
              {additionalInfoErrors.itemValue &&
                additionalInfoErrors.itemValue.type === "required" && (
                  <span className={"error__feedback"}>
                    {additionalInfoErrors.itemValue.message}
                  </span>
                )}
            </div>
          </div>
        </div>
      </ModalWrapper>
      <div className="grid grid-cols-5  gap-3">
        <div className=" col-span-12 flex justify-end">
          <Button
            style={{ marginRight: "1rem" }}
            type="button"
            disabled={false}
            variant="outlined"
            className="float-left"
            onClick={(e) => {
              e.preventDefault();
              props.changeTab("Uploads");
            }}
          >
            Back
          </Button>
          <Button
            type="submit"
            variant="contained"
            className=" text-[20px] px-6 py-1 btn-blue float-right"
            onClick={specificationSubmit(handleSpecificationSubmit)}
            //disabled={image_urls?.length !== 3}
          >
            Submit
          </Button>
        </div>
      </div>
    </div>
  );
};

export default TabContentSpecification;
