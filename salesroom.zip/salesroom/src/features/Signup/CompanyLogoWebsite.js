import React, { useEffect, useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import axios from "axios";
import ImageUploading from "react-images-uploading";

//important for getting nice style.
import { FaRegWindowClose } from "react-icons/fa";
import { Button, TextField } from "@mui/material";
import Loader from "../../components/Loader";
import { ToastAlert } from "../../common/utility";
import { ALERT_ERROR } from "../../common/constants";
import {
  nextStep,
  previousStep,
  changeStatus,
  companyLogoWesite,
} from "../../reducers/authSlice";
import requestsApi from "../../app/requestsApi";

const CompanyLogoWebsite = () => {
  const dispatch = useDispatch();
  const maxNumber = 69;
  const [Isloading, setLoading] = useState(false);
  const [images1, setImages1] = useState([]);
  const businessId = useSelector((state) => state.auth.signUp.businessId);
  const companyDetail = useSelector((state) => state.auth.signUp.companyDetail);

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm();

  const onChange1 = (imageList, addUpdateIndex) => {
    // data for submit
    // console.log("image data");
    // console.log(imageList, addUpdateIndex);
    setImages1(imageList);
  };

  useEffect(() => {
    dispatch(changeStatus());
    if (Object.keys(companyDetail).length != 0) {
      setImages1(companyDetail.companyLogo);
      reset({
        companyName: companyDetail.companyName,
      });
    }
  }, [dispatch, reset, businessId, companyDetail]);

  // Add Images Component
  const AddImages = (props) => {
    const { images, onChange } = props;
    return (
      <>
        <ImageUploading
          // multiple
          value={images}
          onChange={onChange}
          maxNumber={maxNumber}
          dataURLKey="data_url"
        >
          {({
            imageList,
            onImageUpload,
            onImageRemoveAll,
            onImageUpdate,
            onImageRemove,
            isDragging,
            dragProps,
          }) => (
            // write your building UI
            <div className="upload__image-wrapper mb-8">
              <button
                type="button"
                style={isDragging ? { color: "red" } : undefined}
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  onImageUpload();
                }}
                {...dragProps}
              >
                <div className="flex flex-col justify-center items-center h-[150px] w-[160px] rounded-3xl shadow-xl bg-[#ecedf0]">
                  <h3 className="mb-0 text-[20px] font-semibold ">
                    Upload Logo
                  </h3>
                  <h3 className="mb-0 text-[30px] font-semibold leading-7">
                    +
                  </h3>
                </div>
              </button>
              &nbsp;
              {/* <button onClick={onImageRemoveAll}><FaRegWindowClose /></button> */}
              {imageList.map((image, index) => (
                <>
                  <div
                    key={index}
                    className="mylogocss image-item absolute -mt-[148px] flex justify-center items-center w-[158px] h-[150px]"
                  >
                    <img
                      src={image["data_url"]}
                      alt=""
                      className="max-h-[140px] max-w-[140px] mx-auto"
                    />
                  </div>
                  <div className="image-item__btn-wrapper">
                    {/* <button onClick={() => onImageUpdate(index)}>Update</button> */}
                    <button
                      type="button"
                      onClick={() => onImageRemove(index)}
                      className=""
                    >
                      <FaRegWindowClose
                        className="text-[14px]"
                        key={`closeIcon-${index}`}
                      />
                    </button>
                  </div>
                </>
              ))}
            </div>
          )}
        </ImageUploading>
      </>
    );
  };

  const onSubmit = async (data) => {
    setLoading(true);
    await requestsApi
      .postRequest("v2/documents/getPreSignUrl", {
        businessId: businessId, //businessId,
        category: "BUSINESS_PROFILE",
        filename: data.companyName,
        type: "IMAGE",
      })
      .then(function (response) {
        let preSignedUrl = response.preSignedUrl;
        let path = response.path;
        uploadLogo(preSignedUrl, path, data.companyName);
      })
      .catch(function (error) {
        // console.log("error", error);
        errorAlert(error);
      });
  };

  const uploadLogo = async (preSignedUrl, path, companyName) => {
    //let formData = new FormData();
    //// console.log("iiii", images1[0]);
    //formData.append("image", images1[0].file);
    const blob = new Blob([images1[0].file], {
      type: images1[0].file.type,
    });
    let headers = {
      "Access-Control-Allow-Origin": "*",
      //"Content-Type": "multipart/form-data",
    };

    await axios
      .put(preSignedUrl, blob, {
        headers: headers,
      })
      .then(function (_response) {
        updateBusinessLogo(path, companyName);
      })
      .catch(function (error) {
        setLoading(false);
        // console.log("error_upload", error);
        errorAlert(error);
      });
  };

  const updateBusinessLogo = async (path, companyName) => {
    // console.log("path", path);
    let postData = {
      businessId: businessId,
      businessLogoS3Url: path,
      onboardPhase: "BUSINESS_PROFILE_INFO",
    };
    await requestsApi
      .putRequest("v1/business", postData)
      .then(function (response) {
        //// console.log("response", response);
        dispatch(companyLogoWesite({ companyLogo: images1, companyName }));
        dispatch(
          nextStep(6) // update formStage
        );
        // setTimeout(() => {
        //     dispatch(
        //         nextStep(6) // update formStage
        //     );
        // }, 1000);
      })
      .catch(function (error) {
        // console.log("error_upload", error);
        errorAlert(error);
      })
      .then(function () {
        // always executed
        // console.log("always executed");
        setLoading(false);
      });
  };

  const errorAlert = (error) => {
    let statusCode = error.response.status ? error.response.status : error.code;

    let msg = error.response.data
      ? error.response.data.errorMsg
      : error.message;
    ToastAlert({
      type: ALERT_ERROR,
      msg: `${statusCode} ${msg}`,
    });
  };

  return (
    <form>
      <div className="header  mb-7">
        <h2 className="text-[26px] font-medium">
          Enter your company logo {"&"} Website
        </h2>
      </div>

      <div className="grid grid-cols-4 gap-3">
        <div className="body col-span-4 ">
          {/* Upload Logo Start  */}
          <div className="flex justify-center">
            <AddImages images={images1} onChange={onChange1} />
          </div>
          {/* Upload Logo End  */}

          <div>
            <Controller
              name="companyName"
              control={control}
              rules={{
                required: true,
              }}
              defaultValue=""
              render={({ field, formState }) => (
                <TextField
                  fullWidth
                  id="companyName"
                  label="You can enter your company name *"
                  variant="standard"
                  {...field}
                  error={!!formState.errors?.companyName}
                />
              )}
            />
            {errors.companyName && errors.companyName.type === "required" && (
              <span className={"error__feedback"}>Required</span>
            )}
          </div>
          <div
            className={"form__item button__items d-flex justify-content-end"}
          ></div>
        </div>
        <div className="footer col-span-4 flex justify-between gap-3">
          <Button
            type="button"
            style={{ marginRight: "1rem" }}
            className="btnoutline"
            onClick={() =>
              dispatch(
                previousStep() // update formStage
              )
            }
          >
            Back
          </Button>

          <div>
            {/* <Button type={"button"} onClick={next}>
                        Skip
                    </Button> */}
            <Button
              type="submit"
              className="btn-blue"
              onClick={handleSubmit(onSubmit)}
              //disabled={Isloading}
              //onClick={() => next()}
            >
              {Isloading ? <Loader isLoading={Isloading} /> : "Next"}
            </Button>
          </div>
        </div>
      </div>
    </form>
  );
};
export default CompanyLogoWebsite;
