import React, { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
//import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import { dateCustomFormat, getSortName } from "../../common/utility";
// import EditIcon from "@mui/icons-material/Edit";
// import DownloadIcon from "@mui/icons-material/Download";
// import InfoIcon from "@mui/icons-material/Info";
// import DeleteIcon from "@mui/icons-material/Delete";

// import { showCategoryModal } from "../../reducers/modalSlice";

// const StyledMenu = styled((props) => (
//     <Menu
//         elevation={0}
//         anchorOrigin={{
//             vertical: "bottom",
//             horizontal: "right",
//         }}
//         transformOrigin={{
//             vertical: "top",
//             horizontal: "right",
//         }}
//         {...props}
//     />
// ))(({ theme }) => ({
//     "& .MuiPaper-root": {
//         borderRadius: 6,
//         marginTop: theme.spacing(1),
//         minWidth: 180,
//         color:
//             theme.palette.mode === "light"
//                 ? "rgb(55, 65, 81)"
//                 : theme.palette.grey[300],
//         boxShadow:
//             "rgb(255, 255, 255) 0px 0px 0px 0px, rgba(0, 0, 0, 0.05) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 10px 15px -3px, rgba(0, 0, 0, 0.05) 0px 4px 6px -2px",
//         "& .MuiMenu-list": {
//             padding: "4px 0",
//         },
//         "& .MuiMenuItem-root": {
//             "& .MuiSvgIcon-root": {
//                 fontSize: 18,
//                 color: theme.palette.text.secondary,
//                 marginRight: theme.spacing(1.5),
//             },
//             "&:active": {
//                 backgroundColor: alpha(
//                     theme.palette.primary.main,
//                     theme.palette.action.selectedOpacity
//                 ),
//             },
//         },
//     },
// }));

// const bull = (
//     <Box
//         component="span"
//         sx={{ display: "inline-block", mx: "2px", transform: "scale(0.8)" }}
//     >
//         •
//     </Box>
// );

function CategoryCmp(props) {
  const showModal = useSelector((state) => state.modalView.showModal);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleCategory = (categoryId, categoryName) => {
    //navigate(`/category/${cateName}`);
    navigate("/category/products", {
      state: { categoryId: categoryId, categoryName: categoryName },
      //productName: data.productName,
    });
  };

  return (
    <Card
      sx={{
        backgroundColor: "#fff",
        borderRadius: "4px",
        overflow: "hidden",
        minWidth: "0px",
        boxShadow: 10,
        cursor: "pointer",
      }}
      onClick={() =>
        handleCategory(props.category.categoryId, props.category.categoryName)
      }
      //key={`#pcard_${index}`}
    >
      <CardContent>
        <div className="flex justify-between">
          <h2 className="font-bold font-poppins uppercase">
            {getSortName(props.category.categoryName, 16)}
          </h2>
          {/* <MoreVertIcon
                        //Link
                        to="/"
                        onClick={(event) => handleClick(event)}
                    />
                    <StyledMenu
                        id="basic-menu"
                        anchorEl={anchorEl_2}
                        open={openProMenu}
                        onClose={() => handleClose}
                        MenuListProps={{
                            "aria-labelledby": "basic-button",
                        }}
                    >
                        <MenuItem
                            //key={`pm_${index}`}
                            onClick={() => {
                                dispatch(
                                    showCategoryModal({
                                        action: "Edit",
                                        selectedMenu: "Product",
                                    })
                                );
                                handleClose();
                            }}
                        >
                            <EditIcon /> Rename
                        </MenuItem>

                        <MenuItem key={props.index}>
                            <DownloadIcon /> Download
                        </MenuItem>
                        <MenuItem
                        //key={`pm_${index}`}
                        >
                            <InfoIcon /> Info
                        </MenuItem>
                        <MenuItem
                        //key={`pm_${index}`}
                        >
                            <DeleteIcon /> Delete
                        </MenuItem>
                    </StyledMenu> */}
        </div>

        <div></div>
      </CardContent>
      <CardActions className="arowright">
        <span className="">
          <CardActions className="crdaction">
            {dateCustomFormat(props.category.lastUpdatedOn, "LL", true)}
          </CardActions>
        </span>
      </CardActions>
    </Card>
  );
}

CategoryCmp.propTypes = {};

export default CategoryCmp;
