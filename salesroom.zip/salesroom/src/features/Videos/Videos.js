import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import FileViewer from "react-file-viewer";
import Breadcrumb from "../../components/Breadcrumb/Breadcrumb";
//import Card from "@mui/material/Card";
//import CardContent from "@mui/material/CardContent";
import requestsApi from "../../app/requestsApi";
import UploadCardIconCmp from "../../components/UploadCardIconCmp";
import PreviewModalWrapper from "../../components/UI/PreviewModalWrapper";
import FileMenu from "../../components/UI/FileMenu";
import {
  checkObjectEmpty,
  getFileExtensionByUrl,
  getSortName,
  getFileNameByUrl,
} from "../../common/utility";
import { getAllCategories } from "../../reducers/categorySlice";
import { getAllProducts } from "../../reducers/productSlice";

const Videos = () => {
  const dispatch = useDispatch();
  const userRole = useSelector((state) => state.auth?.user?.role);
  const businessId = useSelector((state) => state.auth?.user?.businessId);
  const [videoFiles, setVideoFiles] = useState({});
  const [previewModal, setPreviewModal] = useState(false);
  const [videocUrl, setVideocUrl] = useState("");

  useEffect(() => {
    if (businessId) {
      getVideosByBusinessId();
      dispatch(getAllCategories({ businessId }));
      dispatch(getAllProducts({ businessId, offset: 0 }));
    }
  }, [businessId, dispatch]);
  /**
   * component will unmount
   */
  useEffect(() => {
    return () => {
      setVideoFiles({});
    };
  }, []);

  const getVideosByBusinessId = async () => {
    await requestsApi
      .getRequest(`/v1/dashboard/search`, {
        businessId: businessId,
        filterBy: "VIDEOS",
      })
      .then(function (response) {
        setVideoFiles(response);
      })
      .catch(function (error) {
        // console.log("error", error);
      });
  };

  const getTotaVideosCount = () => {
    return checkObjectEmpty(videoFiles) ? videoFiles?.totalVideosCount : 0;
  };

  const getVideoFile = () => {
    return checkObjectEmpty(videoFiles) ? videoFiles.videos : [];
  };

  const handlePreviewModal = () => {
    let val = !previewModal;
    if (val === false) {
      setVideocUrl("");
    }
    setPreviewModal(val);
  };

  /**
   * Child Component
   */
  const VideoCardCmp = ({ videoUrl }) => {
    return (
      <div className="mainbox">
        <div className="boxMain">
          <div className="boxinner">
            <div className="boxOne">
              <div className="boxOneinner">
                {/* <video controls>
                                    <source src={videoUrl} type="video/mp4" />
                                </video> */}
                <img
                  style={{ paddingTop: "25px" }}
                  src={require(`../../assets/images/image/material-videocam.png`)}
                  alt="img"
                  onClick={() => {
                    setVideocUrl(videoUrl);
                    handlePreviewModal();
                  }}
                />
              </div>
            </div>
          </div>
          <div className="boxTwo">
            <img
              style={{ width: "30px", paddingTop: "3px" }}
              src={require(`../../assets/images/image/material-videocam.png`)}
              alt="img"
            />
            <span>
              {getSortName(getFileNameByUrl(videoUrl, "/VIDEOS/"), 14)}
            </span>
            <span
              style={{
                float: "right",
                color: "#ccc",
                marginTop: "-3.5%",
              }}
            >
              {" "}
              <FileMenu url={videoUrl} />{" "}
            </span>
          </div>
        </div>
      </div>

      // <Card sx={{ minWidth: 205 }}>
      //     <CardContent>
      //         <div className="text-center">
      //             <div
      //                 className="innerpaddingimg cadmainimg"
      //                 style={{ padding: " 54px 0" }}
      //             >
      //                 <video width="750" height="500" controls>
      //                     <source src={videoUrl} type="video/mp4" />
      //                 </video>

      //             </div>
      //             <div className="cadimg mt-3">
      //                 <img
      //                     src={require(`../../assets/images/image/awesome-file-pdf.png`)}
      //                     alt="img"
      //                     style={{ marginTop: "0" }}
      //                 />
      //                 <span
      //                     className="font-regular font-poppins pt-2 fntclr "
      //                     style={{ fontSize: ".75rem" }}
      //                 >

      //                 </span>
      //             </div>
      //         </div>
      //         <div></div>
      //         <div></div>
      //     </CardContent>
      // </Card>
    );
  };

  /**
   * Child Component
   */
  const VideoFileCmp = (props) => {
    return (
      <>
        {props?.fileDetails?.map((data, i) => (
          <div key={`${data.productName}_${i}`}>
            <div className="text-xl font-normal mb-1 mt-6">
              {data.productName}
            </div>
            <div
              className={
                "Categories"
                  ? "grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 gap-6 mt-6"
                  : "hidden"
              }
              id="link1"
            >
              {data?.videoUrls?.map((vUrl, index) => (
                <VideoCardCmp
                  //ukey={`catalog_${index}_${props.imgDetails?.productId}`}
                  videoUrl={vUrl}
                  key={`video_${index}_${props.imgDetails?.productId}`}
                />
              ))}
              {userRole === "SUPER_ADMIN" || userRole === "ADMIN" ? (
                <UploadCardIconCmp
                  title="Video"
                  key={data.productName}
                  productId={data.productId}
                  uploadCategoryType="VIDEOS"
                  refreshList={getVideosByBusinessId}
                />
              ) : null}
            </div>
          </div>
        ))}
      </>
    );
  };

  return (
    <>
      <Breadcrumb />
      <div className="p-6 mb-3">
        <div className="mb-6">
          <h2 className="text-3xl font-bold mb-1">
            Videos {`(${getTotaVideosCount()})`}
          </h2>
          {/* <h2 className="text-lg font-normal">2 Manuals</h2> */}
          {videoFiles && getVideoFile().length
            ? getVideoFile()?.map((rec, index) => (
                <VideoFileCmp
                  title="CPAP"
                  fileDetails={rec.videoInfo}
                  index={index}
                  key={`Catalog-${index}`}
                />
              ))
            : null}
          {/* <div className="text-xl mt-5 font-normal">Product 1</div> */}
        </div>
        <PreviewModalWrapper
          heading="Video Preview"
          isPopUpShow={previewModal}
          size="lg"
          toggleModel={handlePreviewModal}
        >
          <FileViewer
            fileType={getFileExtensionByUrl(videocUrl)}
            filePath={videocUrl}
            //errorComponent={CustomErrorComponent}
            //onError={this.onError}
          />
        </PreviewModalWrapper>
      </div>
    </>
  );
};

export default Videos;
