import React from "react";
import PropTypes from "prop-types";
import MenuItem from "@mui/material/MenuItem";
import InputLabel from "@mui/material/InputLabel";
import Select from "@mui/material/Select";

function SelectMuiCmp(props) {
  return (
    <>
      <InputLabel id="demo-simple-select-helper-label">
        {props.label}
      </InputLabel>
      <Select
        labelId="demo-simple-select-helper-label"
        id="demo-simple-select-helper"
        //value={age}
        label={props.label}
        //onChange={handleChange}
      >
        <MenuItem value="">
          <em>None</em>
        </MenuItem>
        {props.menuOption.map((menu) => {
          return (
            <MenuItem key={menu.value} value={menu.value}>
              {menu.label}
            </MenuItem>
          );
        })}
      </Select>
    </>
  );
}

SelectMuiCmp.propTypes = {};

export default SelectMuiCmp;
