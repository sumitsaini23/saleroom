import React, { useState, useEffect, useRef } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";

import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import DeleteOutlinedIcon from "@mui/icons-material/DeleteOutlined";
import MenuItem from "@mui/material/MenuItem";
import { MdAdd } from "react-icons/md";
import { hideModal } from "../../reducers/modalSlice";
import { startLoader, stopLoader } from "../../reducers/commonSlice";
import {
  getPreSignUrlLink,
  getFileName,
  getFileDetails,
  getPreSignUrlFileType,
  uploadFile,
  ToastAlert,
  getDecodecFileUrl,
  getSortName,
} from "../../common/utility";
import {
  ALERT_INFO,
  ALERT_SUCCESS,
  ALERT_ERROR,
  imageExtension,
  docExtension,
  cadExtension,
  videoExtension,
} from "../../common/constants";
import ModalWrapper from "../UI/ModalWrapper";
import ReactHookFormSelect from "../UI/ReactHookFormSelect";
import requestsApi from "../../app/requestsApi";
import Swal from "sweetalert2";
import { CircularProgress } from "@mui/material";
import doneicn from "../../assets/images/icon/doneicn.gif";

const schema = Yup.object({
  productId: Yup.string().required("Required"),
  //uploadFile: Yup.mixed().required("A file is required"),
}).required();

/**
 * Component Start
 */
const DocUploadModal = (props) => {
  const ref = useRef();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const businessId = useSelector((state) => state.auth?.user?.businessId);
  const showModal = useSelector((state) => state.modalView.showModal);
  const heading = useSelector((state) => state.modalView.heading);
  const products = useSelector((state) => state.products.products.content);
  const [isFileUpload, setIsFileUpload] = useState(false);
  const [isSelectFile, setIsSelectFile] = useState(false);
  const [selectFileName, setSelectFileName] = useState("");
  const [selectFileUrl, setSelectFileUrl] = useState("");
  const [selectFileExt, setSelectFileExt] = useState("");
  const [productId, setProductId] = useState("");
  const [filePath, setFilePath] = useState("");
  const [image_urls, setImage_urls] = useState([]);
  const [manuals_urls, setManuals_urls] = useState([]);
  const [catalogue_urls, setCatalogue_urls] = useState([]);
  const [cad_urls, setCad_urls] = useState([]);
  const [video_urls, setVideo_urls] = useState([]);

  const [uploadingStatus, setUploadingStatus] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const dynamicIcon = () => {
    return uploadingStatus ? (
      <>
        <h2 className="fontheadclr">{`Uploading...`}</h2>
        <CircularProgress variant="determinate" value={uploadProgress} />
      </>
    ) : (
      <>
        <h2 className="fontheadclr">{`Add ${props.title}`}</h2>
        <MdAdd className="iconadd" />
      </>
    );
  };

  const onUploadProgress = (event) => {
    const { loaded, total } = event;
    const uploadPercentage = (loaded / total) * 100;
    setUploadProgress(uploadPercentage);
    if (uploadPercentage == 100) {
      setUploadProgress(0);
      setUploadingStatus(false);
    }
  };

  /**
   * Form
   */
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
  });
  /**
   * Component mount & unmount
   */
  useEffect(() => {
    /**
     * Component unmount
     */
    return () => {
      // console.log("Component unmount");
      resetAllStates();
    };
  }, []);
  /**
   *
   * button click Methods
   */
  const handleClick = (e) => {
    if (isSelectFile === false) {
      ref.current.click();
    }
  };
  /**
   * Reset All States when Component unmount
   */
  const resetAllStates = () => {
    setImage_urls([]);
    setManuals_urls([]);
    setCatalogue_urls([]);
    setCad_urls([]);
    setVideo_urls([]);
    setFilePath("");
    setProductId("");
  };
  /**
   * get product details by productId
   */
  const getProductDetails = async (productId) => {
    setProductId(productId);
    await requestsApi
      .getRequest(`/v1/products/${productId}`)
      .then(function (response) {
        previousData(response);
      })
      .catch(function (error) {
        // console.log("error", error);
      });
  };

  const previousData = (response) => {
    switch (props.uploadCategoryType) {
      case "MANUAL":
        previousManualUrls(response);
        break;
      case "CATALOG":
        previousCatalogueUrls(response);
        break;
      case "CAD_INFOS":
        previousCadUrls(response);
        break;
      case "VIDEOS":
        previousVideoUrls(response);
        break;
      default:
        previousImageUrls(response);
        break;
    }
  };

  const previousImageUrls = (response) => {
    let imgArr = [];
    if (
      response.productDocs &&
      response.productDocs.image_urls &&
      response.productDocs.image_urls.length > 0
    ) {
      (response.productDocs.image_urls || []).forEach((element) => {
        let mainUrl = getDecodecFileUrl(element);
        imgArr.push(mainUrl);
      });
      setImage_urls(imgArr);
    }
  };

  const previousManualUrls = (response) => {
    let mannualArr = [];
    if (
      response.productDocs &&
      response.productDocs.image_urls &&
      response.productDocs.manuals_urls.length > 0
    ) {
      (response.productDocs.manuals_urls || []).forEach((element) => {
        let mainUrl = getDecodecFileUrl(element);
        mannualArr.push(mainUrl);
      });
      setManuals_urls(mannualArr);
    }
  };

  const previousCatalogueUrls = (response) => {
    let catlogArr = [];
    if (
      response.productDocs &&
      response.productDocs.catalog_urls &&
      response.productDocs.catalog_urls.length > 0
    ) {
      (response.productDocs.catalog_urls || []).forEach((element) => {
        let mainUrl = getDecodecFileUrl(element);
        catlogArr.push(mainUrl);
      });
      setCatalogue_urls(catlogArr);
    }
  };

  const previousCadUrls = (response) => {
    let cadArr = [];
    if (
      response.productDocs &&
      response.productDocs.cad_urls &&
      response.productDocs.cad_urls.length > 0
    ) {
      (response.productDocs.cad_urls || []).forEach((element) => {
        let mainUrl = getDecodecFileUrl(element);
        cadArr.push(mainUrl);
      });
      setCad_urls(cadArr);
      //setCad_urls(response.productDocs.cad_urls);
    }
  };

  const previousVideoUrls = (response) => {
    let vdoArr = [];
    if (
      response.productDocs &&
      response.productDocs.video_urls &&
      response.productDocs.video_urls.length > 0
    ) {
      (response.productDocs.video_urls || []).forEach((element) => {
        let mainUrl = getDecodecFileUrl(element);
        vdoArr.push(mainUrl);
      });
      //setVideo_urls(response.productDocs.video_urls);
      setVideo_urls(vdoArr);
    }
  };

  const onFileChange = (e) => {
    if (!e || !e.target || !e.target.files || e.target.files.length === 0) {
      return;
    }
    let allowedExtensions = [];
    if (
      props.uploadCategoryType === "MANUAL" ||
      props.uploadCategoryType === "CATALOG"
    ) {
      allowedExtensions = docExtension;
    } else if (props.uploadCategoryType === "CAD_INFOS") {
      allowedExtensions = cadExtension;
    } else if (props.uploadCategoryType === "VIDEOS") {
      allowedExtensions = videoExtension;
    } else {
      allowedExtensions = imageExtension;
    }
    const fileData = e.target.files[0];
    let { ext } = getFileDetails(fileData);

    if (!allowedExtensions.includes(ext)) {
      ToastAlert({
        type: ALERT_INFO,
        msg: "Invalid file format",
      });
      return;
    }
    setIsSelectFile(true);
    setSelectFileExt(ext);
    if (fileData) {
      getPreSignUrl(fileData, props.uploadCategoryType);
    }
  };

  const confirmUploadFile = async (
    preSignedUrl,
    fileData,
    onUploadProgress
  ) => {
    setUploadingStatus(true);
    await uploadFile(preSignedUrl, fileData, onUploadProgress)
      .then(function (response) {
        if (response.status === 200) {
          let { fileName, fileUrl, ext } = getFileDetails(fileData);
          setSelectFileName(fileName);
          setSelectFileUrl(fileUrl);
          setSelectFileExt(ext);
          setIsSelectFile(false);
          setIsFileUpload(true);
          // ToastAlert({
          //     type: ALERT_SUCCESS,
          //     msg: "File Uploaded",
          // });
        }
      })
      .catch(function (error) {
        // console.log("response_upload file error", error);
        ToastAlert({
          type: ALERT_ERROR,
          msg: `${props.uploadCategoryType} file upload error`,
        });
      });
  };
  const getPreSignUrl = async (fileData, uploadCategory) => {
    let fileName = getFileName(fileData);
    let uploadFileType = getPreSignUrlFileType(fileName);

    await getPreSignUrlLink(
      businessId,
      fileName,
      uploadCategory,
      uploadFileType
    )
      .then(function (response) {
        let preSignedUrl = response.preSignedUrl;
        let path = response.path;
        setFilePath(path);
        /**
         * Upload file
         */
        confirmUploadFile(preSignedUrl, fileData, onUploadProgress);
      })
      .catch(function (error) {
        // console.log("getPreSignUrl_error", error);
        ToastAlert({
          type: ALERT_ERROR,
          msg: `${uploadCategory} PreSignUrl url error`,
        });
      });
  };

  const updateWithPreviousData = () => {
    let postData = {
      productId: productId,
      productDocs: {},
    };
    switch (props.uploadCategoryType) {
      case "MANUAL":
        postData.productDocs = {
          manuals_urls: [...manuals_urls, filePath],
        };
        break;
      case "CATALOG":
        postData.productDocs = {
          catalog_urls: [...catalogue_urls, filePath],
        };
        break;
      case "CAD_INFOS":
        postData.productDocs = {
          cad_urls: [...cad_urls, filePath],
        };
        break;
      case "VIDEOS":
        postData.productDocs = {
          video_urls: [...video_urls, filePath],
        };
        break;
      default:
        postData.productDocs = {
          image_urls: [...image_urls, filePath],
        };
        break;
    }
    return postData;
  };

  /**
   * Handle Submit
   */
  const handleSave = async () => {
    if (filePath === "") {
      ToastAlert({
        type: ALERT_ERROR,
        msg: `Please select file`,
      });
      return;
    }
    dispatch(startLoader());
    let postData = updateWithPreviousData();

    //// console.log("postData", postData);
    await requestsApi
      .putRequest("/v1/products", postData)
      .then(function (response) {
        setSelectFileExt("");
        setIsFileUpload(false);
        dispatch(hideModal());
        Swal.fire({
          // title: `${props.uploadCategoryType} Product Created`,
          title: `${props.uploadCategoryType} successfully added`,
          imageUrl: doneicn,
          imageWidth:"100",
          showConfirmButton: false,
          timer: 2000,
        });
        redirectLocation();
      })
      .catch(function (error) {
        // console.log("error", error);
        ToastAlert({
          type: ALERT_ERROR,
          msg: `Something went wrong`,
        });
      })
      .then(function () {
        dispatch(stopLoader());
        // always executed
      });
  };

  const getAllowedExtension = () => {
    switch (props.uploadCategoryType) {
      case "MANUAL":
        return ".pdf,.ppt,.doc,.docx,.pptx,.PDF,.PPT,.DOC,.DOCX,.PPTX";
      case "CATALOG":
        return ".pdf,.ppt,.doc,.docx,.pptx,.PDF,.PPT,.DOC,.DOCX,.PPTX";
      case "CAD_INFOS":
        return ".stp,.step,.abc,.sldasm";
      case "VIDEOS":
        return "video/*";
      default:
        return ".jpg,.jpeg,.JPG,.JPEG | image/*";
    }
  };

  const redirectLocation = () => {
    switch (props.uploadCategoryType) {
      case "MANUAL":
        navigate("/manuals");
        break;
      case "CATALOG":
        navigate("/catalogues");
        break;
      case "CAD_INFOS":
        navigate("/cadFiles");
        break;
      case "VIDEOS":
        navigate("/videos");
        break;
      default:
        navigate("images");
        break;
    }
  };

  const getImageIcon = (iconSize) => {
    let imgIconUrl = "";
    if (
      props.uploadCategoryType === "MANUAL" ||
      props.uploadCategoryType === "CATALOG"
    ) {
      return (
        <img
          src={
            selectFileExt === "pdf"
              ? require(`../../assets/images/image/awesome-file-pdf.png`)
              : require(`../../assets/images/image/Group 658.png`)
          }
          alt="..."
        />
      );
    } else if (props.uploadCategoryType === "CAD_INFOS") {
      return (
        <img
          src={require(`../../assets/images/image/Group 652.png`)}
          alt="..."
        />
      );
    } else if (props.uploadCategoryType === "VIDEOS") {
      let iconstyle =
        iconSize === "big"
          ? {
              paddingTop: "25px",
            }
          : {
              width: "30px",
              paddingTop: "3px",
            };
      return (
        <img
          style={iconstyle}
          src={require(`../../assets/images/image/material-videocam.png`)}
          alt="..."
        />
      );
    }
  };

  const onFileRemove = () => {
    setFilePath("");
    setSelectFileName("");
    setSelectFileUrl("");
    setSelectFileExt("");
    setIsSelectFile(false);
    setIsFileUpload(false);
  };

  return (
    <div>
      <ModalWrapper
        heading={`${heading} ${props.uploadCategoryType}`}
        isPopUpShow={showModal}
        size="xs"
        toggleModel={() => dispatch(hideModal())}
        saveBtnTitle="Done"
        onsubmit={handleSubmit(handleSave)}
      >
        <>
          <div className="relative p-6 flex-auto">
            <ReactHookFormSelect
              id="product-select"
              name="productId"
              label="Select Product *"
              control={control}
              defaultValue=""
              fullWidth
              variant="standard"
              disabled={false}
            >
              <MenuItem value="">
                <em>None</em>
              </MenuItem>
              {products.map((p) => (
                <MenuItem
                  key={p.id}
                  value={p.id}
                  onClick={() => getProductDetails(p.id)}
                >
                  {p.productName}
                </MenuItem>
              ))}
            </ReactHookFormSelect>
            {errors.productId && errors.productId.type === "required" && (
              <span className={"error__feedback"}>
                {errors.productId.message}
              </span>
            )}
          </div>
          <div className="relative p-6 flex-auto">
            {isFileUpload ? (
              <div className="mainbox " style={{margin:"0px auto 0px auto"}}>
                <div className="boxMain">
                  <div className="boxinner">
                    <div className="boxOne">
                      <div className="boxOneinner">{getImageIcon("big")}</div>
                    </div>
                  </div>

                  <div className="boxTwo">
                    {getImageIcon("small")}
                    <span>{getSortName(selectFileName, 16)}</span>
                    <span style={{ float: "right" }}>
                      <DeleteOutlinedIcon
                        sx={{
                          color: "#174fba",
                        }}
                        onClick={onFileRemove}
                      />
                    </span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="mainbox" style={{margin:"0px auto 0px auto"}}>
                <div
                  className="boxMain"
                  style={{
                    border: "2px dashed #174fba",
                    // height: "100%",
                    borderRadius: "10px",
                    background: "#F4F7FE",
                  }}
                  onClick={handleClick}
                >
                  <div className="boxinner">
                    <div className="boxOneadd">
                      <div className="boxOneinner">
                        <input
                          ref={ref}
                          type="file"
                          accept={getAllowedExtension()}
                          onChange={onFileChange}
                          style={{
                            display: "none",
                          }}
                        />
                        {dynamicIcon()}
                      </div>
                    </div>
                  </div>
                  <div className="boxTwo-img"></div>
                </div>
              </div>
            )}
          </div>
        </>
      </ModalWrapper>
    </div>
  );
};

export default DocUploadModal;
