import React from "react";
import { useSelector } from "react-redux";
import PropTypes from "prop-types";
import Dialog from "@mui/material//Dialog";
import DialogActions from "@mui/material//DialogActions";
import DialogContent from "@mui/material//DialogContent";
//import DialogContentText from '@mui/material//DialogContentText';
import DialogTitle from "@mui/material//DialogTitle";
import Button from "@mui/material/Button";
import Loader from "../Loader";

const ModalWrapper = (props) => {
  //const theme = useTheme();
  const isLoading = useSelector((state) => state.common.isLoading);
  //const fullScreen = useMediaQuery(theme.breakpoints.down("md"));

  return (
    <React.Fragment>
      <Dialog
        padding={20}
        fullWidth={true}
        maxWidth={props.size}
        open={props.isPopUpShow}
        onClose={(_, reason) => {
          if (reason !== "backdropClick") {
            props.toggleModel();
          }
        }}
        aria-labelledby="responsive-dialog-title"
      >
        <form onSubmit={props.onsubmit}>
          <DialogTitle id="max-width-dialog-title">{props.heading}</DialogTitle>
          <DialogContent>{props.children}</DialogContent>
          <DialogActions className="p-4 ">
            <Button
              type="button"
              variant="outlined"
              className="btnoutline "
              style={{ textTransform: "none" }}
              onClick={props.toggleModel}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="contained"
              color="primary"
              className="btnbg"
              onClick={(e) => {
                e.preventDefault();
                props.onsubmit();
              }}
              disabled={isLoading}
            >
              {isLoading ? (
                <Loader isLoading={isLoading} />
              ) : (
                props.saveBtnTitle
              )}
            </Button>
          </DialogActions>
        </form>
      </Dialog>
    </React.Fragment>
  );
};

ModalWrapper.propTypes = {
  heading: PropTypes.string.isRequired,
  isPopUpShow: PropTypes.bool.isRequired,
  size: PropTypes.string.isRequired,
  toggleModel: PropTypes.func.isRequired,
  children: PropTypes.element.isRequired,
  saveBtnTitle: PropTypes.string.isRequired,
};

export default ModalWrapper;
