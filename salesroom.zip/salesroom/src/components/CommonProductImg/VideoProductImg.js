import React, { useState } from "react";
import { MdArrowRight, MdArrowDropDown, MdAdd } from "react-icons/md";
import Card from "@mui/material/Card";
import Box from "@mui/material/Box";
import { Link, useNavigate } from "react-router-dom";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";
const VideoProductImg = ({ title }) => {
  const [open, setOpen] = useState(false);
  const handleUpload = () => {};
  const navigate = useNavigate();
  const handleCategory = (cateName) => {
    navigate(`/dashboard/category/${cateName}`);
  };
  const [anchorEl, setAnchorEl] = React.useState(null);
  // const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const imgcategories = [
    {
      productnm: "Product 1 promo.mp4 ",
      productdate: "24 Mar’ 22 ",
      img: "material-videocam.png",
      img1: "material-videocam.png",
    },
    {
      productnm: "Product 1 animati.... ",
      productdate: "24 Mar’ 22 ",
      img: "material-videocam.png",
      img1: "material-videocam.png",
    },
  ];
  const videocategories = [
    {
      productnm: "Product 2 promo.mp4 ",
      productdate: "24 Mar’ 22 ",
      img: "material-videocam.png",
      img1: "material-videocam.png",
    },
  ];
  return (
    <>
      <div className="text-xl font-normal mb-1 mt-6">Product 1 </div>
      <div
        className={
          "Categories"
            ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-6 "
            : "hidden"
        }
        id="link1"
      >
        {imgcategories.map(({ productnm, productdate, img, img1 }, index) => (
          <Card sx={{ boxShadow: 10 }}>
            <CardContent style={{}}>
              <div className="text-center ">
                <div
                  className="innerpaddingimg cadmainimg"
                  style={{ padding: " 54px 0" }}
                >
                  <img src={require(`../../assets/images/image/${img1}`)} />
                </div>
                <div className="cadimg mt-3">
                  <img
                    src={require(`../../assets/images/image/${img1}`)}
                    style={{ marginTop: "0" }}
                  />
                  <span
                    className="font-regular font-poppins fntclr "
                    style={{ fontSize: ".75rem" }}
                  >
                    {productnm}
                  </span>
                </div>
              </div>

              <div></div>
              <div></div>
            </CardContent>
          </Card>
        ))}

        <Box
          sx={{
            border: "2px dashed #174fba",
            height: "100%",
            borderRadius: "10px",
            background: "#F4F7FE",
          }}
        >
          <Card
            sx={{
              height: "100%",
              borderRadius: "12px",
              background: "#F4F7FE",
              boxShadow: 10,
            }}
          >
            <CardContent>
              <h2 className="fontheadclr">Add Video/link</h2>

              <MdAdd className="iconadd" />
            </CardContent>
          </Card>
        </Box>
      </div>
      <div className="text-xl font-normal mb-1 mt-6">Product 2</div>
      <div
        className={
          "Categories"
            ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-6 "
            : "hidden"
        }
        id="link1"
      >
        {videocategories.map(({ productnm, productdate, img, img1 }, index) => (
          <Card sx={{ boxShadow: 10 }}>
            <CardContent>
              <div className="text-center ">
                <div
                  className="innerpaddingimg cadmainimg"
                  style={{ padding: " 54px 0" }}
                >
                  <img src={require(`../../assets/images/image/${img1}`)} />
                </div>
                <div className="cadimg mt-3">
                  <img
                    src={require(`../../assets/images/image/${img1}`)}
                    style={{ marginTop: "0" }}
                  />
                  <span
                    className="font-regular font-poppins fntclr "
                    style={{ fontSize: ".75rem" }}
                  >
                    {productnm}
                  </span>
                </div>
              </div>

              <div></div>
              <div></div>
            </CardContent>
          </Card>
        ))}

        <Box
          sx={{
            border: "2px dashed #174fba",
            height: "100%",
            borderRadius: "10px",
            background: "#F4F7FE",
          }}
        >
          <Card
            sx={{
              height: "100%",
              borderRadius: "12px",
              background: "#F4F7FE",
              boxShadow: 10,
            }}
          >
            <CardContent>
              <h2 className="fontheadclr">Add Video/link</h2>

              <MdAdd className="iconadd" />
            </CardContent>
          </Card>
        </Box>
      </div>
    </>
  );
};

export default VideoProductImg;
