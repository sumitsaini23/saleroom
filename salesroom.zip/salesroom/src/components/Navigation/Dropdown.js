import React, { useState } from "react";
import { useSelector, useDispatch } from "react-redux";

import Button from "@mui/material/Button";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";

// import ManualModal from "../Modals/ManualModal/ManualModal";

import CategoryModal from "../Modals/CategoryModal/CategoryModal";
import ProductModal from "../Modals/ProductModal/ProductModal";
import DocUploadModal from "../Modals/DocUploadModal";
// import CataloguesModal from "../Modals/Catalogues/CataloguesModal";
// import CadModal from "../Modals/CadModal/CadModal";
// import VideosModal from "../Modals/VideosModal/VideosModal";
// import CategoryModal from "../Modals/CategoryModal/CategoryModal";
import {
  showCategoryModal,
  showProductModal,
  showDocUploadModal,
} from "../../reducers/modalSlice";

const Dropdown = () => {
  const dispatch = useDispatch();
  const showModal = useSelector((state) => state.modalView.showModal);
  const dropdownItem = useSelector((state) => state.modalView.navDropdownItem);
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  //const [dropdownItem, setDropdownItem] = React.useState("Category");

  const dropdownItems = [
    "Category",
    "Product",
    "Manual",
    "Catalogue",
    "CAD drawings",
    "Videos",
  ];

  const handleDropdownItem = (item) => {
    setAnchorEl(null);
    switch (item) {
      case "Product":
        return dispatch(
          showProductModal({
            action: "Add",
            selectedMenu: item,
            productName: "",
            productId: "",
          })
        );
      case "Category":
        return dispatch(
          showCategoryModal({ action: "Add", selectedMenu: item })
        );
      default:
        return dispatch(showDocUploadModal({ selectedMenu: item }));
    }
  };

  const getModal = () => {
    switch (dropdownItem) {
      case "Product":
        return <ProductModal />;
      case "Category":
        return <CategoryModal />;
      case "Manual":
        return <DocUploadModal title="Manual" uploadCategoryType="MANUAL" />;
      case "Catalogue":
        return (
          <DocUploadModal title="Catalogues" uploadCategoryType="CATALOG" />
        );
      case "CAD drawings":
        return (
          <DocUploadModal title="CAD Files" uploadCategoryType="CAD_INFOS" />
        );
      case "Videos":
        return <DocUploadModal title="Video" uploadCategoryType="VIDEOS" />;
      default:
        break;
    }
  };
  return (
    <div>
      <Button
        // variant="primary"
        disableRipple
        className="btnoutline text-md font-semibold flex justify-between shadow-xl m-3 addbtnwth"
        id="basic-button"
        aria-controls={open ? "basic-menu" : undefined}
        aria-haspopup="true"
        aria-expanded={open ? "true" : undefined}
        onClick={handleClick}
      >
        <span className="" style={{ fontSize: "20px", lineHeight: "0" }}>
          +{" "}
        </span>{" "}
        Add
      </Button>
      <Menu
        id="basic-menu"
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        MenuListProps={{
          "aria-labelledby": "basic-button",
        }}
      >
        {dropdownItems.map((item, index) => (
          <MenuItem key={index} onClick={() => handleDropdownItem(item)}>
            {item}
          </MenuItem>
        ))}
      </Menu>
      {showModal && getModal()}
    </div>
  );
};

export default Dropdown;
