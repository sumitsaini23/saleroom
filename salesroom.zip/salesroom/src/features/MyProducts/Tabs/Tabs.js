import React, { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";

import { getAllCategories } from "../../../reducers/categorySlice";
import { getAllProducts } from "../../../reducers/productSlice";
import Swal from "sweetalert2";
import CategoryCmp from "../../Categories/CategoryCmp";
import ProductCmp from "../ProductCmp";
import AddCardIconCmp from "../../../components/AddCardIconCmp";
import PaginationCmp from "../../../components/PaginationCmp";
import requestsApi from "../../../app/requestsApi";
import doneicn from "../../../assets/images/icon/doneicn.gif";

const Tabs = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [openTab, setOpenTab] = React.useState("Categories");
  const userRole = useSelector((state) => state.auth?.user?.role);
  const businessId = useSelector((state) => state.auth?.user?.businessId);
  const categories = useSelector((state) => state.categories.categories);
  const products = useSelector((state) => state.products.products);

  useEffect(() => {
    if (businessId) {
      dispatch(getAllCategories({ businessId }));
      dispatch(getAllProducts({ businessId, offset: 0 }));
    }
  }, [businessId, dispatch]);

  const handleProductPageChange = (event, value) => {
    dispatch(getAllProducts({ businessId, offset: value - 1 }));
    //// console.log("value", event, value);
  };

  const goToEditProduct = (pId, cId) => {
    navigate("/editProduct", {
      state: {
        productId: pId,
        categoryId: cId,
      },
    });
  };

  const confirmDeleteProduct = (productId) => {
    Swal.fire({
      title: "Are you sure?",
      text: "Want to change access level",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#174FBA",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, do it!",
    }).then((result) => {
      if (result.isConfirmed) {
        deleteProduct(productId);
      }
    });
  };

  const deleteProduct = async (productId) => {
    await requestsApi
      .deleteRequest(`/v1/products/${productId}`)
      .then(function (response) {
        Swal.fire({
          title: `Product deleted successfully`,
          imageUrl: doneicn,
          imageWidth:"100",
          showConfirmButton: false,
          timer: 2000,
        });
        dispatch(getAllProducts({ businessId, offset: 0 }));
      })
      .catch(function (error) {
        // console.log("error", error);
      });
  };

  return (
    <>
      <div className="flex">
        <div className="w-full">
          <ul
            className="tabs-btn flex mb-0 list-none flex-wrap pt-3 pb-4 flex-row"
            role="tablist"
          >
            {/* categories tab */}
            <li className="-mb-px mr-2 last:mr-0 text-center">
              <a
                className={
                  "text-xs font-bold  px-5 py-3 shadow-lg rounded block leading-normal" +
                  (openTab === "Categories" ? " active" : "")
                }
                onClick={(e) => {
                  e.preventDefault();
                  setOpenTab("Categories");
                }}
                data-toggle="tab"
                href="#link1"
                role="tablist"
              >
                Categories
              </a>
            </li>
            {/* all products tab */}
            <li className="-mb-px mr-2 last:mr-0 text-center">
              <a
                className={
                  "text-xs font-bold  px-5 py-3 shadow-lg rounded block leading-normal" +
                  (openTab === "products" ? " active" : "")
                }
                onClick={(e) => {
                  e.preventDefault();
                  setOpenTab("products");
                }}
                data-toggle="tab"
                href="#link2"
                role="tablist"
              >
                All Products
              </a>
            </li>
          </ul>
          {/* categories tab content */}
          <div
            className={
              openTab === "Categories"
                ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-4 gap-6 mt-6"
                : "hidden"
            }
            id="link1"
          >
            {categories.map((category, index) => (
              <CategoryCmp
                category={category}
                index={index}
                key={`cate-${index}`}
              />
            ))}
            {userRole === "SUPER_ADMIN" || userRole === "ADMIN" ? (
              <AddCardIconCmp title="Category" />
            ) : null}
          </div>

          {/* all products tab content */}
          <div
            className={
              openTab === "products"
                ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-6"
                : "hidden"
            }
            id="link1"
          >
            {products &&
              products.hasOwnProperty("content") &&
              products.content.map((prodct, index) => (
                <ProductCmp
                  product={prodct}
                  productId={prodct.id}
                  productCategoryId={prodct.categoryId}
                  index={index}
                  key={`pro-${index}`}
                  goToEditProduct={goToEditProduct}
                  confirmDeleteProduct={confirmDeleteProduct}
                />
              ))}
            {userRole === "SUPER_ADMIN" || userRole === "ADMIN" ? (
              <AddCardIconCmp title="Product" />
            ) : null}
            {/* Pagination */}
          </div>
          {openTab === "products" ? (
            <div
              style={{
                minHeight: "20vh",
                position: "relative",
                float: "right",
                width: "160px",
              }}
            >
              <div
                className="row"
                style={{ bottom: "0", left: "0", position: "absolute" }}
              >
                {products &&
                  products.hasOwnProperty("content") &&
                  products.content.length > 0 && (
                    <PaginationCmp
                      count={products.totalPages}
                      defaultPage={0}
                      siblingCount={0}
                      handlePageChange={handleProductPageChange}
                    />
                  )}
              </div>
            </div>
          ) : null}
        </div>
      </div>
    </>
  );
};

export default Tabs;
