import React, { useEffect, useState, Suspense, lazy } from "react";
import { useSelector, useDispatch } from "react-redux";
import Breadcrumb from "../../components/Breadcrumb/Breadcrumb";
import requestsApi from "../../app/requestsApi";
import { checkObjectEmpty } from "../../common/utility";
import { getAllCategories } from "../../reducers/categorySlice";
import { getAllProducts } from "../../reducers/productSlice";
const CommonProductImg = lazy(() =>
  import("../../components/CommonProductImg/CommonProductImg")
);

const Images = () => {
  const dispatch = useDispatch();
  const userRole = useSelector((state) => state.auth?.user?.role);
  const businessId = useSelector((state) => state.auth?.user?.businessId);
  const [imagesData, setImagesData] = useState({});
  useEffect(() => {
    if (businessId) {
      getImagesByBusinessId();
      dispatch(getAllCategories({ businessId }));
      dispatch(getAllProducts({ businessId, offset: 0 }));
    }
  }, [businessId, dispatch]);
  /**
   * component will unmount
   */
  useEffect(() => {
    return () => {
      setImagesData({});
    };
  }, []);

  const getImagesByBusinessId = async () => {
    await requestsApi
      .getRequest(`/v1/dashboard/search`, {
        businessId: businessId,
        filterBy: "IMAGES",
      })
      .then(function (response) {
        setImagesData(response);
      })
      .catch(function (error) {
        // console.log("error", error);
      });
  };

  const getTotalImageCount = () => {
    return checkObjectEmpty(imagesData) ? imagesData.totalImagesCount : 0;
  };

  const getImages = () => {
    return checkObjectEmpty(imagesData) ? imagesData.images : [];
  };

  return (
    <>
      <Breadcrumb />
      <div className="p-6 mb-3">
        <div className="mb-6">
          <h2 className="text-3xl font-bold mb-1">
            Images {`(${getTotalImageCount()})`}
          </h2>
          {/* <h2 className="text-lg font-normal">8 Images</h2> */}
        </div>
        <Suspense fallback={<p>Loading Images</p>}>
          {getImages()?.map((rec, index) => (
            <CommonProductImg
              userRole={userRole}
              title="CPAP"
              imgDetails={rec.images}
              index={index}
              key={`Images-${index}`}
              refreshList={getImagesByBusinessId}
            />
          ))}
          {/* <div className="text-xl mt-5 font-normal">Product 1</div> */}
        </Suspense>
      </div>
    </>
  );
};

export default Images;
