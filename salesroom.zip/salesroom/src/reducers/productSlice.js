import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import {
  Status,
  isApiError,
  //successReducer,
  failureReducer,
  objDeepClone,
} from "../common/utility";
import requestsApi from "../app/requestsApi";

/**
 * @type {productsState}
 */
const initialState = {
  products: [],
  productsByCategory: [],
  createProductObj: {
    businessId: "",
    categoryId: "",
    priceInfo: {
      currency: "",
      price: 0,
    },
    productDescription: "",
    productDocs: {
      cad_urls: null,
      catalog_urls: null,
      custom_links: null,
      image_urls: null,
      manuals_urls: null,
      video_urls: null,
    },
    productName: "",
    productUniqueId: "",
    tagline: "",
  },
};
/**
 * Send a get all products request
 * productSpecification: {
            specification: {},
        },
 */
export const getAllProducts = createAsyncThunk(
  "products/getAllProducts",
  async ({ businessId, offset }, thunkApi) => {
    //?businessId=1880ee89-4804-4cad-92c0-6f9675a212ab&direction=DESC&offset=1&size=12&sortBy=createdOn
    try {
      return await requestsApi.getRequest("/v1/products", {
        businessId: businessId,
        offset: offset,
      });
    } catch (error) {
      if (isApiError(error)) {
        return thunkApi.rejectWithValue(error);
      }
      throw error;
    }
  }
);
/**
 * Send a get products by CategoryID
 *
 */
export const getProductByCategoryId = createAsyncThunk(
  "products/getProductByCategoryId",
  async ({ categoryId }, thunkApi) => {
    try {
      return await requestsApi.getRequest(
        `/v1/dashboard/categories/${categoryId}/products`
      );
    } catch (error) {
      if (isApiError(error)) {
        return thunkApi.rejectWithValue(error);
      }
      throw error;
    }
  }
);
/**
 * @param {import('@reduxjs/toolkit').Draft<AuthState>} state
 * @param {import('@reduxjs/toolkit').PayloadAction<{token: string, user: User}>} action
 */
function successGetAllProductsReducer(state, action) {
  state.status = Status.SUCCESS;
  state.products = action.payload;
}
function successGetCategoryProductsReducer(state, action) {
  state.status = Status.SUCCESS;
  state.productsByCategory = action.payload.listProducts;
}
/**
 * Reducers
 */
const productSlice = createSlice({
  name: "products",
  initialState,
  reducers: {
    saveproductDetails(state, action) {
      state.createProductObj = {
        ...state.createProductObj,
        businessId: action.payload.businessId,
        categoryId: action.payload.categoryId,
        priceInfo: {
          currency: action.payload.currency,
          price: action.payload.price,
        },
        productDescription: action.payload.productDescription,
        productName: action.payload.productName,
        productUniqueId: action.payload.productUniqueId,
        tagline: action.payload.tagline,
      };
    },
    saveproductUploaddetails(state, action) {
      state.createProductObj = {
        ...state.createProductObj,
        productDocs: {
          cad_urls: action.payload.cad_urls,
          catalog_urls: action.payload.catalogue_urls,
          custom_links: action.payload.custom_links,
          image_urls: action.payload.image_urls,
          manuals_urls: action.payload.manuals_urls,
          video_urls: action.payload.video_urls,
        },
      };
    },
    resetCreateProductObj(state) {
      state.createProductObj = objDeepClone(initialState.createProductObj);
    },
    resetCategoryProducts(state) {
      state.productsByCategory = initialState.productsByCategory;
    },
    deleteproduct(state, action) {
      state.products = action.payload;
    },
  },
  extraReducers: (builder) => {
    /**
     * Pending Status
     */
    builder.addCase(getAllProducts.pending, (state) => {
      state.loading = Status.LOADING;
    });
    builder.addCase(getProductByCategoryId.pending, (state) => {
      state.loading = Status.LOADING;
    });
    /**
     * fulfilled Status
     */
    builder.addCase(getAllProducts.fulfilled, successGetAllProductsReducer);
    builder.addCase(
      getProductByCategoryId.fulfilled,
      successGetCategoryProductsReducer
    );
    /**
     * rejected Status
     */
    builder.addCase(getAllProducts.rejected, failureReducer);
    builder.addCase(getProductByCategoryId.rejected, failureReducer);
  },
});

export const {
  saveproductDetails,
  saveproductUploaddetails,
  resetCreateProductObj,
  resetCategoryProducts,
  deleteproduct,
} = productSlice.actions;

export default productSlice.reducer;
