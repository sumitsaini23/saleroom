import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import FileViewer from "react-file-viewer";
import Breadcrumb from "../../components/Breadcrumb/Breadcrumb";
//import Card from "@mui/material/Card";
//import CardContent from "@mui/material/CardContent";
import FileMenu from "../../components/UI/FileMenu";
import PreviewModalWrapper from "../../components/UI/PreviewModalWrapper";
import requestsApi from "../../app/requestsApi";
import UploadCardIconCmp from "../../components/UploadCardIconCmp";
import {
  checkObjectEmpty,
  getFileExtensionByUrl,
  getSortName,
  getFileNameByUrl,
} from "../../common/utility";
import { getAllCategories } from "../../reducers/categorySlice";
import { getAllProducts } from "../../reducers/productSlice";

const CadFiles = () => {
  const dispatch = useDispatch();
  const userRole = useSelector((state) => state.auth?.user?.role);
  const businessId = useSelector((state) => state.auth?.user?.businessId);
  const [cadFilesData, setCadFilesData] = useState({});
  const [previewModal, setPreviewModal] = useState(false);
  const [pdfDocUrl, setPdfDocUrl] = useState("");

  useEffect(() => {
    if (businessId) {
      getCadFilesByBusinessId();
      dispatch(getAllCategories({ businessId }));
      dispatch(getAllProducts({ businessId, offset: 0 }));
    }
  }, [businessId, dispatch]);
  /**
   * component will unmount
   */
  useEffect(() => {
    return () => {
      setCadFilesData({});
    };
  }, []);

  const getCadFilesByBusinessId = async () => {
    await requestsApi
      .getRequest(`/v1/dashboard/search`, {
        businessId: businessId,
        filterBy: "CAD_INFOS",
      })
      .then(function (response) {
        //// console.log("response", response);
        setCadFilesData(response);
      })
      .catch(function (error) {
        // console.log("error", error);
      });
  };

  const getTotalCadVideosCount = () => {
    return checkObjectEmpty(cadFilesData)
      ? cadFilesData.totalCadVideosCount
      : 0;
  };

  const getCadFiles = () => {
    return checkObjectEmpty(cadFilesData) ? cadFilesData.cadInfos : [];
  };

  const handlePreviewModal = () => {
    let val = !previewModal;
    if (val === false) {
      setPdfDocUrl("");
    }
    setPreviewModal(val);
  };

  /**
   * Child Component
   */
  const CadFileCardCmp = ({ imgUrl }) => {
    return (
      <div className="mainbox">
        <div className="boxMain">
          <div className="boxinner">
            <div className="boxOne">
              <div className="boxOneinner">
                <img
                  style={{ paddingTop: "25px" }}
                  src={
                    getFileExtensionByUrl(imgUrl) === "pdf"
                      ? require(`../../assets/images/image/awesome-file-pdf.png`)
                      : require(`../../assets/images/image/Group 652.png`)
                  }
                  alt="img"
                  onClick={() => {
                    setPdfDocUrl(imgUrl);
                    handlePreviewModal();
                  }}
                />
              </div>
            </div>
          </div>
          <div className="boxTwo">
            <img
              src={
                getFileExtensionByUrl(imgUrl) === "pdf"
                  ? require(`../../assets/images/image/awesome-file-pdf.png`)
                  : require(`../../assets/images/image/Group 652.png`)
              }
              alt="img"
            />
            {getSortName(getFileNameByUrl(imgUrl, "/CAD_INFOS/"), 16)}
            <span
              style={{
                float: "right",
                color: "#ccc",
                marginTop: "-3.5%",
              }}
            >
              {" "}
              <FileMenu url={imgUrl} />{" "}
            </span>
          </div>
        </div>
      </div>

      // <Card sx={{ minWidth: 205 }}>
      //     <CardContent>
      //         <div className="text-center">
      //             <div className="innerpaddingimg cadmainimg">
      //                 <img src={imgUrl} alt="img" />
      //             </div>
      //             <div className="cadimg mt-3">
      //                 <img
      //                     src={require(`../../assets/images/image/awesome-file-pdf.png`)}
      //                     alt="img"
      //                 />
      //                 <span
      //                     className="font-regular font-poppins pt-2 fntclr "
      //                     style={{ fontSize: ".75rem" }}
      //                 >
      //                     {productnm}
      //                 </span>
      //             </div>
      //         </div>
      //         <div></div>
      //         <div></div>
      //     </CardContent>
      // </Card>
    );
  };

  /**
   * Child Component
   */
  const CadFileCmp = (props) => {
    if (props?.fileDetails.length > 0) {
      return (
        <>
          {props?.fileDetails?.map((data, i) => (
            <div key={`${data.productName}_${i}`}>
              <div className="text-xl font-normal mb-1 mt-6">
                {data.productName}
              </div>
              <div
                className={
                  "Categories"
                    ? "grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 gap-6 mt-6"
                    : "hidden"
                }
                id="link1"
              >
                {data?.cadS3Urls?.map((imgUrl, index) => (
                  <CadFileCardCmp
                    //ukey={`catalog_${index}_${props.imgDetails?.productId}`}
                    imgUrl={imgUrl}
                    key={`catalog_${index}_${props.imgDetails?.productId}`}
                  />
                ))}
                {userRole === "SUPER_ADMIN" || userRole === "ADMIN" ? (
                  <UploadCardIconCmp
                    title="CAD Files"
                    key={data.productName}
                    productId={data.productId}
                    uploadCategoryType="CAD_INFOS"
                    refreshList={getCadFilesByBusinessId}
                  />
                ) : null}
              </div>
            </div>
          ))}
        </>
      );
    } else {
      return null;
    }
  };

  return (
    <>
      <Breadcrumb />
      <div className="p-6 mb-3">
        <div className="mb-6">
          <h2 className="text-3xl font-bold mb-1">
            Cad Files {`(${getTotalCadVideosCount()})`}
          </h2>
          {cadFilesData && getCadFiles().length
            ? getCadFiles()?.map((rec, index) => (
                <CadFileCmp
                  title="CPAP"
                  fileDetails={rec.cadInfos}
                  index={index}
                  key={`Catalog-${index}`}
                />
              ))
            : null}
        </div>
        <PreviewModalWrapper
          heading="Document Preview"
          isPopUpShow={previewModal}
          size="lg"
          toggleModel={handlePreviewModal}
        >
          <FileViewer
            fileType={getFileExtensionByUrl(pdfDocUrl)}
            filePath={pdfDocUrl}
            //errorComponent={CustomErrorComponent}
            //onError={this.onError}
          />
        </PreviewModalWrapper>
      </div>
    </>
  );
};

export default CadFiles;
