import React, { useState, memo, useCallback } from "react";
//import FileViewer from "react-file-viewer";
//import { MdArrowRight, MdArrowDropDown, MdAdd } from "react-icons/md";
// import Card from "@mui/material/Card";
// import CardContent from "@mui/material/CardContent";
import FileMenu from "../../components/UI/FileMenu";
import PreviewModalWrapper from "../../components/UI/PreviewModalWrapper";
import UploadCardIconCmp from "../../components/UploadCardIconCmp";
import { getFileNameByUrl, getSortName } from "../../common/utility";
//import ImageViewModal from "../../features/Images/ImageViewModal";
import ImageViewer from "react-simple-image-viewer";

const CommonProductImg = (props) => {
  const [imgDocUrl, setImgDocUrl] = useState([]);
  const [currentImage, setCurrentImage] = useState(0);
  const [isViewerOpen, setIsViewerOpen] = useState(false);

  const openImageViewer = useCallback((index) => {
    setCurrentImage(index);
    setIsViewerOpen(true);
  }, []);

  const closeImageViewer = () => {
    setCurrentImage(0);
    setIsViewerOpen(false);
  };

  const CardCmp = ({ imgUrl, ukey, imgArr, index }) => {
    return (
      <div className="mainbox" key={ukey}>
        {/* <Card key={ukey}> */}
        {/* <CardContent className="cardcss"> */}
        {/* <div className="text-center productimg">
                        <img src={imgUrl} alt="img" />
                        <h2 className="font-regular font-poppins uppercase fntclr mt-3">
                           
                            vaibhav
                        </h2>
                    </div> */}

        <div className="boxMain ">
          <div className="boxinner">
            <div className="boxOne">
              <div className="boxOneinner">
                <img
                  src={imgUrl}
                  alt="img"
                  onClick={() => {
                    setImgDocUrl(imgArr);
                    openImageViewer(index);
                  }}
                />
              </div>
            </div>
          </div>

          <div className="boxTwo">
            <span>{getSortName(getFileNameByUrl(imgUrl, "/IMAGES/"), 16)}</span>
            <span
              style={{
                fontSize: "22px",
                float: "right",
                color: "#ccc",
              }}
            >
              {/* &#8942; */}
            </span>
            <span
              style={{
                float: "right",
                color: "#ccc",
                marginTop: "-3.5%",
              }}
            >
              {" "}
              <FileMenu url={imgUrl} />{" "}
            </span>
          </div>
        </div>
      </div>

      //     </CardContent>
      // </Card>
    );
  };

  return (
    <>
      {props.imgDetails?.map((data, i) => (
        <div key={`${data.productName}_${i}`}>
          <div className="text-xl mt-5 font-normal">{data?.productName}</div>
          <div
            className={
              "Categories"
                ? "grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-3 gap-6 mt-6"
                : "hidden"
            }
            id="link1"
          >
            {data.imagesS3Urls.map((imgUrl, index) => (
              <CardCmp
                key={index}
                index={index}
                ukey={`img_${index}_${props.imgDetails?.productId}`}
                imgUrl={imgUrl}
                imgArr={data.imagesS3Urls}
              />
            ))}
            {props.userRole === "SUPER_ADMIN" || props.userRole === "ADMIN" ? (
              <UploadCardIconCmp
                title="Image"
                key={data.productName}
                productId={data.productId}
                uploadCategoryType="IMAGES"
                refreshList={props.refreshList}
              />
            ) : null}
          </div>
        </div>
      ))}
      {/* <div className="imgviewercss">
                {isViewerOpen && (
                    <ImageViewer
                        // style={{width:"50%!important"}}
                        src={imgDocUrl}
                        currentIndex={currentImage}
                        disableScroll={false}
                        closeOnClickOutside={true}
                        onClose={closeImageViewer}
                    />
                )}
            </div> */}
      <PreviewModalWrapper
        heading="Image Preview"
        isPopUpShow={isViewerOpen}
        size="lg"
        toggleModel={closeImageViewer}
        showCloseButton={false}
      >
        <ImageViewer
          className="imgviewercss"
          src={imgDocUrl}
          currentIndex={currentImage}
          disableScroll={false}
          closeOnClickOutside={true}
          onClose={closeImageViewer}
        />
      </PreviewModalWrapper>
    </>
  );
};

export default memo(CommonProductImg);
