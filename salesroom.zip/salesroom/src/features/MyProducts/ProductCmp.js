import React, { useState } from "react";
//import { useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import PropTypes from "prop-types";
//import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import { styled, alpha } from "@mui/material/styles";

import EditIcon from "@mui/icons-material/Edit";
import DownloadIcon from "@mui/icons-material/Download";
import InfoIcon from "@mui/icons-material/Info";
import DeleteIcon from "@mui/icons-material/Delete";
import ModalWrapper from "../../components/UI/ModalWrapper";
import { showProductModal } from "../../reducers/modalSlice";
import { dateCustomFormat, getSortName } from "../../common/utility";

const StyledMenu = styled((props) => (
  <Menu
    elevation={0}
    anchorOrigin={{
      vertical: "bottom",
      horizontal: "right",
    }}
    transformOrigin={{
      vertical: "top",
      horizontal: "right",
    }}
    {...props}
  />
))(({ theme }) => ({
  "& .MuiPaper-root": {
    borderRadius: 6,
    marginTop: theme.spacing(1),
    minWidth: 180,
    color:
      theme.palette.mode === "light"
        ? "rgb(55, 65, 81)"
        : theme.palette.grey[300],
    boxShadow:
      "rgb(255, 255, 255) 0px 0px 0px 0px, rgba(0, 0, 0, 0.05) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 10px 15px -3px, rgba(0, 0, 0, 0.05) 0px 4px 6px -2px",
    "& .MuiMenu-list": {
      padding: "4px 0",
    },
    "& .MuiMenuItem-root": {
      "& .MuiSvgIcon-root": {
        fontSize: 18,
        color: theme.palette.text.secondary,
        marginRight: theme.spacing(1.5),
      },
      "&:active": {
        backgroundColor: alpha(
          theme.palette.primary.main,
          theme.palette.action.selectedOpacity
        ),
      },
    },
  },
}));

// const bull = (
//     <Box
//         component="span"
//         sx={{ display: "inline-block", mx: "2px", transform: "scale(0.8)" }}
//     >
//         •
//     </Box>
// );

function ProductCmp(props) {
  const dispatch = useDispatch();
  const userRole = useSelector((state) => state.auth?.user?.role);
  const [showNameModal, setShowNamemodal] = useState(false);
  //const navigate = useNavigate();
  const [anchorEl_2, setAnchorEl_2] = useState(null);
  const openProMenu = Boolean(anchorEl_2);
  const handleClick = (event) => {
    setAnchorEl_2(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl_2(null);
  };

  const handleNameModal = () => {
    setShowNamemodal(!showNameModal);
  };

  return (
    <>
      <Card
        //sx={{ minWidth: 275 }}
        sx={{
          backgroundColor: "#fff",
          borderRadius: "4px",
          overflow: "hidden",
          minWidth: "0px",
          cursor: "pointer",
          boxShadow: 10,
        }}
        //key={`#pcard_${index}`}
        onClick={() => {
          props.goToEditProduct(props.productId, props.productCategoryId);
        }}
      >
        <CardContent>
          <div className="flex justify-between">
            <h2
              className="font-bold font-poppins uppercase"
              onClick={(e) => {
                e.stopPropagation();
                props.goToEditProduct(props.productId, props.productCategoryId);
              }}
              style={{ cursor: "pointer" }}
            >
              {getSortName(props.product.productName, 16)}
            </h2>
            <MoreVertIcon
              //Link
              to="/"
              onClick={(event) => {
                event.stopPropagation();
                handleClick(event);
              }}
            />
            <StyledMenu
              id="basic-menu"
              anchorEl={anchorEl_2}
              open={openProMenu}
              onClose={handleClose}
              MenuListProps={{
                "aria-labelledby": "basic-button",
              }}
              onClick={(e) => {
                e.stopPropagation();
              }}
            >
              {userRole === "SUPER_ADMIN" || userRole === "ADMIN" ? (
                <MenuItem
                  //key={`pm_${index}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    dispatch(
                      showProductModal({
                        action: "Edit",
                        selectedMenu: "Product",
                        productName: props.product.productName,
                        productId: props.productId,
                        categoryId: props.productCategoryId,
                      })
                    );
                    handleClose();
                  }}
                >
                  <EditIcon /> Rename
                </MenuItem>
              ) : null}

              <MenuItem key={props.index}>
                <DownloadIcon /> Download
              </MenuItem>
              <MenuItem
                onClick={(e) => {
                  e.stopPropagation();
                  handleNameModal();
                }}
                //key={`pm_${index}`}
              >
                <InfoIcon /> Info
              </MenuItem>
              {userRole === "SUPER_ADMIN" || userRole === "ADMIN" ? (
                <MenuItem
                  onClick={(e) => {
                    e.stopPropagation();
                    handleClose();
                    props.confirmDeleteProduct(props.productId);
                  }}
                  //key={`pm_${index}`}
                >
                  <DeleteIcon /> Delete
                </MenuItem>
              ) : null}
            </StyledMenu>
          </div>

          <div></div>
        </CardContent>
        <CardActions
          className="arowright"
          onClick={(e) => {
            e.stopPropagation();
            props.goToEditProduct(props.productId, props.productCategoryId);
          }}
          style={{ cursor: "pointer" }}
        >
          <span className="">
            <CardActions className="crdaction">
              {dateCustomFormat(props.product.lastUpdatedOn, "LL", true)}
            </CardActions>
          </span>
        </CardActions>
      </Card>

      <ModalWrapper
        heading="Details"
        size="sm"
        isPopUpShow={showNameModal}
        toggleModel={handleNameModal}
        saveBtnTitle="Continue"
        // onsubmit={changeName}
        // onsubmit={handleLoginSubmit(authenticateUser)}
      >
        <>
          <div className="grid grid-cols-4 md:grid-cols-2 lg:grid-cols-3 gap-1 mt-3 ">
            <div className="col-span-8 mt-3 ">
              <h2>Who has access</h2>
              <div className="mt-3" style={{ display: "flex" }}>
                <span>
                  {" "}
                  <img
                    style={{
                      width: "40px",
                      padding: "0px 15px 0px 0px",
                    }}
                    src={require(`../../assets/images/icon/notshared.png`)}
                    alt="img"
                  />
                </span>{" "}
                <span className="clrgray">Not Shared</span>
              </div>
            </div>
          </div>
          <div className=" grid-cols-2 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-2 gap-1 mt-3 ">
            <h2>Properties</h2>

            <div className="col-span-12 mt-5 " style={{ display: "flex" }}>
              {" "}
              <div className="clrgray " style={{ width: "150px" }}>
                Type
              </div>{" "}
              <div className="col-span-6 "> Category</div>
            </div>
            <div className="col-span-12 mt-5 " style={{ display: "flex" }}>
              {" "}
              <div className="clrgray  " style={{ width: "150px" }}>
                Created
              </div>{" "}
              <div className="col-span-6 ">
                7 Feb 2022 with forms-file-upload
              </div>
            </div>
            <div className="col-span-12 mt-5 " style={{ display: "flex" }}>
              {" "}
              <div className="clrgray " style={{ width: "150px" }}>
                Modified
              </div>{" "}
              <div className="col-span-6 ">7 Feb 2022 by Niranjan Naragund</div>
            </div>
          </div>
        </>
      </ModalWrapper>
    </>
  );
}

ProductCmp.propTypes = {};

export default ProductCmp;
