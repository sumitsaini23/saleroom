import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useForm, Controller } from "react-hook-form";
import copy from "copy-to-clipboard";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import Swal from "sweetalert2";
import CircularProgress from "@mui/material/CircularProgress";
import { styled } from "@mui/material/styles";
import ArrowForwardIosSharpIcon from "@mui/icons-material/ArrowForwardIosSharp";
import MuiAccordion from "@mui/material/Accordion";
import MuiAccordionSummary from "@mui/material/AccordionSummary";
import MuiAccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import { Button, TextField } from "@mui/material";

import { emailPattern } from "../../common/utility";
import { distributosGroupId } from "../../common/constants";
import { startLoader, stopLoader } from "../../reducers/commonSlice";
import { getAllCategories } from "../../reducers/categorySlice";
import { getAllProducts } from "../../reducers/productSlice";

import Breadcrumb from "../../components/Breadcrumb/Breadcrumb";
import ModalWrapper from "../../components/UI/ModalWrapper";
import ReactHookFormSelect from "../../components/UI/ReactHookFormSelect";
import requestsApi from "../../app/requestsApi";
import doneicn from "../../assets/images/icon/doneicn.gif";

const Accordion = styled((props) => (
  <MuiAccordion disableGutters elevation={0} square {...props} />
))(({ theme }) => ({
  border: `1px solid ${theme.palette.divider}`,
  "&:not(:last-child)": {
    borderBottom: 0,
  },
  "&:before": {
    display: "none",
  },
}));

const AccordionSummary = styled((props) => (
  <MuiAccordionSummary
    expandIcon={
      <ArrowForwardIosSharpIcon sx={{ fontSize: "0.9rem", color: "#fff" }} />
    }
    {...props}
  />
))(({ theme }) => ({
  backgroundColor: "#174fba",
  color: "#fff",
  flexDirection: "row-reverse",
  "& .MuiAccordionSummary-expandIconWrapper.Mui-expanded": {
    transform: "rotate(90deg)",
  },
  "& .MuiAccordionSummary-content": {
    marginLeft: theme.spacing(1),
  },
}));

const AccordionDetails = styled(MuiAccordionDetails)(({ theme }) => ({
  padding: theme.spacing(2),
  borderTop: "1px solid rgba(0, 0, 0, .125)",
}));

/**
 * member validation
 */
const memberValidationSchema = Yup.object({
  emails: Yup.string().required("Email is required"),
  accesslevel: Yup.string().required("Required"),
  group: Yup.string().required("Required"),
}).required();
/**
 * group form validation
 */
const groupValidationSchema = Yup.object({
  groupName: Yup.string().required("Required"),
  description: Yup.string().required("Required"),
}).required();

const Members = () => {
  const dispatch = useDispatch();
  const userRole = useSelector((state) => state.auth?.user?.role);
  const businessId = useSelector((state) => state.auth?.user?.businessId);

  const [showMembarModal, setShowMembarModal] = useState(false);
  const [showGroupModal, setShowGroupModal] = useState(false);

  const [usersList, setUsersList] = useState([]);
  const [groupList, setGroupList] = useState([]);
  const [distributorsList, setDistributorsList] = useState([]);
  const [groupUsersList, setGroupUsersList] = useState([]);
  const [openTab, setOpenTab] = useState("Team");
  const [expanded, setExpanded] = React.useState(null);
  const [progressLoadeer, setProgressLoadeer] = React.useState(false);
  //const [accessLevel, setAccessLevel] = useState("");
  const [inviteUrl, setInviteUrl] = useState("");
  const [inviteCode, setInviteCode] = useState("");
  const [isInviteUrlCopy, setIsInviteUrlCopy] = useState(false);
  // const [anchorEl, setAnchorEl] = React.useState(null);
  // const [anchorEl_2, setAnchorEl_2] = React.useState(null);
  /**
   *  member from control
   */
  const {
    control: memberFormControl,
    handleSubmit: handleMemberSubmit,
    reset: memberFormReset,
    formState: { errors: memberFormErrors },
  } = useForm({
    resolver: yupResolver(memberValidationSchema),
    mode: "onTouched",
  });
  /**
   *  group from control
   */
  const {
    control: groupFormControl,
    handleSubmit: handleGroupSubmit,
    reset: groupFormReset,
    formState: { errors: groupFormErrors },
  } = useForm({
    resolver: yupResolver(groupValidationSchema),
    mode: "onTouched",
  });

  useEffect(() => {
    if (businessId) {
      dispatch(getAllCategories({ businessId }));
      dispatch(getAllProducts({ businessId, offset: 0 }));
      getUsersByBusinessId();
      getGroupsByBusinessId();
      getDistributosUsers();
    }
  }, [businessId]);

  /**
   * Get user by businessId
   * /v1/users/business/{businessId}
   */
  const getUsersByBusinessId = () => {
    requestsApi
      .getRequest(`/v1/users/business/${businessId}`)
      .then(function (response) {
        setUsersList(response.users);
      })
      .catch(function (error) {
        // console.log("error", error);
      });
  };
  /**
   * Get Groups by businessId
   * /v1/users/business/{businessId}
   */
  const getGroupsByBusinessId = () => {
    requestsApi
      .postRequest(`/v1/users/groups/get`, {
        businessId: businessId,
        filterBy: "ALL_GROUPS",
        groupId: null,
      })
      .then(function (response) {
        setGroupList(response.groups.groups);
      })
      .catch(function (error) {
        // console.log("error", error);
      });
  };
  /**
   * Get user by GroupId distributors
   */
  const getDistributosUsers = () => {
    requestsApi
      .postRequest(`/v1/users/groups/get`, {
        businessId: businessId,
        filterBy: "GROUP_BY_ID",
        groupId: distributosGroupId,
      })
      .then(function (response) {
        setDistributorsList(response.users);
      })
      .catch(function (error) {
        // console.log("error", error);
      });
  };
  /**
   * Get user by GroupId distributors
   */
  const generateInviteLink = () => {
    requestsApi
      .postRequest(`/v1/invite`, {
        businessId: businessId,
      })
      .then(function (response) {
        //setInviteUrl(`${process.env.PUBLIC_URL}/${response.inviteUrl}`);
        setInviteUrl(response.inviteUrl);
        setInviteCode(response.inviteCode);
      })
      .catch(function (error) {
        // console.log("error", error);
      });
  };
  /**
   * Handle Member Modal
   */
  const handleMemberModal = () => {
    memberFormReset();
    setShowMembarModal(!showMembarModal);
  };

  const handleAccordianChange = (panel, rowGroupId) => (event, newExpanded) => {
    if (newExpanded) {
      getUsersByGroupId(rowGroupId);
    }
    setExpanded(newExpanded ? panel : false);
  };
  /**
   * Get user by GroupId
   */
  const getUsersByGroupId = (gropuId) => {
    setProgressLoadeer(true);
    requestsApi
      .postRequest(`/v1/users/groups/get`, {
        businessId: businessId,
        filterBy: "GROUP_BY_ID",
        groupId: gropuId,
      })
      .then(function (response) {
        setGroupUsersList(response.users);
      })
      .catch(function (error) {
        // console.log("error", error);
      })
      .then(function () {
        // always executed
        setProgressLoadeer(false);
      });
  };
  /**
   * Handle Group Modal
   */
  const handleGroupModal = () => {
    getGroupsByBusinessId();
    groupFormReset();
    setShowGroupModal(!showGroupModal);
  };
  /**
   * Save Member
   */
  const saveMember = (data) => {
    //// console.log("data ", data);
    dispatch(startLoader());
    let inviteUserArray = [];
    data.emails.split(",").forEach(function (email) {
      if (email && emailPattern.test(email))
        inviteUserArray.push({
          email: email.trim(),
          groupId: data.group,
          role: data.accesslevel,
        });
    });

    let postData = {
      businessId: businessId,
      users: inviteUserArray,
    };
    //// console.log("postData", postData);
    userSaveReq(requestsApi.postRequest("/v1/invite/users", postData), true);
  };
  /**
   * Save Group
   */
  const saveGroup = (data) => {
    dispatch(startLoader());
    let postData = {
      businessId: businessId,
      description: data.description,
      name: data.groupName,
    };
    //// console.log("postData", postData);
    requestsApi
      .postRequest("/v1/users/groups", postData)
      .then(function (_response) {
        handleGroupModal();
        Swal.fire({
          title: "Data saved successfully",
          imageUrl: doneicn,
          imageWidth:"100",
          showConfirmButton: false,
          timer: 2000,
        });
      })
      .catch(function (error) {
        // console.log("error", error);
      })
      .then(function () {
        // always executed
        dispatch(stopLoader());
      });
  };
  /**
   * Update Access level
   */
  const updateAccessLevel = (val, uId, obj) => {
    let postData = {
      role: val,
      userId: uId,
    };
    //// console.log("postdata", postData);
    // let usersList = usersList.filter(()=>{});
    // setUsersList(response.users);
    Swal.fire({
      title: "Are you sure?",
      text: "Want to change access level",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#174FBA",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, do it!",
    }).then((result) => {
      if (result.isConfirmed) {
        let groupId = obj.groupId ? obj.groupId : null;
        userSaveReq(
          requestsApi.putRequest("/v1/users", postData),
          false,
          groupId
        );
      } else {
        if (obj.tabName === "userList") {
          setUsersList(usersList);
        } else if (obj.tabName === "groupList") {
          setGroupUsersList(groupUsersList);
        } else if (obj.tabName === "distributorList") {
          setDistributorsList(distributorsList);
        }
      }
    });
  };
  /**
   * Send Request user add or update
   */
  const userSaveReq = (reqUrl, isModal, groupId) => {
    reqUrl
      .then(function (_response) {
        if (openTab === "groups") {
          getUsersByGroupId(groupId);
        } else if (openTab === "distributors") {
          getDistributosUsers();
        } else {
          getUsersByBusinessId();
        }

        if (isModal) handleMemberModal();
        Swal.fire({
          title: "Member invite sent on mail",
          imageUrl: doneicn,
          imageWidth:"100",
          showConfirmButton: false,
          timer: 2000,
        });
      })
      .catch(function (error) {
        // console.log("error", error);
      })
      .then(function () {
        // always executed
        dispatch(stopLoader());
      });
  };

  return (
    <>
      <Breadcrumb />
      <div className="p-6 mb-0">
        <div className="mb-0">
          <h2 className="text-3xl font-bold mb-0">
            Members {usersList ? `(${usersList.length})` : null}
          </h2>
          {/* <h2 className="text-lg">2 members</h2> */}
        </div>
      </div>

      <div className="flex m-5 mt-0">
        <div className="w-fit">
          <ul
            className="tabs-btn flex mb-0 list-none flex-wrap pt-3 pb-4 flex-row"
            role="tablist"
          >
            {/* Team tab */}
            <li className="-mb-px mr-2 last:mr-0 text-center">
              <a
                className={
                  "text-xs font-bold  px-5 py-3 shadow-lg rounded block leading-normal" +
                  (openTab === "Team" ? " active" : "")
                }
                onClick={(e) => {
                  e.preventDefault();
                  setOpenTab("Team");
                }}
                data-toggle="tab"
                href="#link1"
                role="tablist"
              >
                Team
              </a>
            </li>
            {/* all groups tab */}
            <li className="-mb-px mr-2 last:mr-0 text-center">
              <a
                className={
                  "text-xs font-bold  px-5 py-3 shadow-lg rounded block leading-normal" +
                  (openTab === "groups" ? " active" : "")
                }
                onClick={(e) => {
                  e.preventDefault();
                  setOpenTab("groups");
                }}
                data-toggle="tab"
                href="#link2"
                role="tablist"
              >
                Group
              </a>
            </li>

            <li className="-mb-px mr-2 last:mr-0 text-center">
              <a
                className={
                  "text-xs font-bold  px-5 py-3 shadow-lg rounded block leading-normal" +
                  (openTab === "distributors" ? " active" : "")
                }
                onClick={(e) => {
                  e.preventDefault();
                  setOpenTab("distributors");
                }}
                data-toggle="tab"
                href="#link2"
                role="tablist"
              >
                Distributors
              </a>
            </li>
          </ul>
          {/* Team tab content */}
          <div
            className={
              openTab === "Team"
                ? "grid grid-cols-1 md:grid-cols-1 lg:grid-cols-1 xl:grid-cols-1 gap-6 mt-6"
                : "hidden"
            }
            id="link1"
          >
            <p>
              Manage members here, or set up a domain, so everyone with allowed
              email domains can join the workspace automatically.
              <br />
              Note: you will NOT be charged for each member added
            </p>
            <div className="">
              {userRole === "SUPER_ADMIN" || userRole === "ADMIN" ? (
                <Button
                  variant="contained"
                  className="btn-black "
                  onClick={handleMemberModal}
                >
                  Add members
                </Button>
              ) : null}
            </div>

            <TableContainer component={Paper} style={{ width: "900px" }}>
              <Table sx={{ minWidth: 650 }} aria-label="simple table">
                <TableHead>
                  <TableRow
                    sx={{
                      "& th": {
                        color: "#fff",
                        backgroundColor: "#174fba",
                      },
                    }}
                    //style={{ color: "#fff!important" }}
                  >
                    <TableCell>User</TableCell>
                    <TableCell align="center">Access level</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {usersList?.map((row, index) => (
                    <TableRow
                      key={`${index}-${row.groupId}`}
                      sx={{
                        "&:last-child td, &:last-child th": { border: 0 },
                      }}
                    >
                      <TableCell component="th" scope="row">
                        {row.email}
                      </TableCell>
                      <TableCell align="center">
                        {row.role !== "SUPER_ADMIN" ? (
                          <FormControl
                            sx={{
                              m: 1,
                              minWidth: 120,
                            }}
                            size="small"
                            variant="standard"
                          >
                            <InputLabel id="demo-select-small">
                              Access level
                            </InputLabel>

                            <Select
                              labelId="demo-select-small"
                              id="demo-select-small"
                              defaultValue={row.role}
                              label="Access level"
                              value={row.role}
                              onChange={(e) =>
                                updateAccessLevel(e.target.value, row.userId, {
                                  tabName: "userList",
                                })
                              }
                              disabled={userRole === "USER"}
                            >
                              <MenuItem value={"ADMIN"}>Admin</MenuItem>
                              <MenuItem value={"USER"}>Member</MenuItem>
                            </Select>
                          </FormControl>
                        ) : (
                          row.role.replace("_", " ")
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
            {userRole === "SUPER_ADMIN" || userRole === "ADMIN" ? (
              <>
                <h2>
                  <b>Invite link</b>
                </h2>
                <Button
                  className="btn-blue"
                  style={{ width: "900px", height: "40px" }}
                  variant="contained"
                  onClick={generateInviteLink}
                  disabled={inviteUrl === "" ? false : true}
                >
                  Generate Invite Link
                </Button>
                <p>
                  Share this secret link to invite people to this workspace.
                  Only admins can see this. You can reset the link for all space
                  members to generate a new invite link.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-1 lg:grid-cols-6 gap-6 mt-6 ">
                  <div
                    className="col-span-4  mr-5 "
                    style={{
                      display: "flex",
                      width: "900px",
                    }}
                  >
                    <TextField
                      className="col-span-ful"
                      fullWidth
                      label="Copy URL here "
                      name={"pasteurl"}
                      variant="standard"
                      value={inviteUrl}
                      InputLabelProps={{ shrink: true }}
                    />
                    <Button
                      variant="contained"
                      className="md:grid-cols-2 btnbg w-52 ml-5 btn-black"
                      onClick={() => {
                        copy(inviteUrl);
                        setIsInviteUrlCopy(true);
                        setTimeout(() => {
                          setIsInviteUrlCopy(false);
                        }, 3000);
                      }}
                      disabled={!inviteUrl || isInviteUrlCopy}
                    >
                      {isInviteUrlCopy ? "Copied" : "Copy URL"}
                    </Button>
                  </div>
                </div>
              </>
            ) : null}
          </div>

          {/* all groups tab content */}

          <div
            className={
              openTab === "groups"
                ? "grid grid-cols-1 md:grid-cols-1 lg:grid-cols-1 xl:grid-cols-1 gap-6 mt-6"
                : "hidden"
            }
            id="link1"
          >
            <p>
              Set up separate groups for separate business functionalities, i.e
              Sales, Marketing, Accounts, etc.
            </p>
            <div className="">
              {userRole === "SUPER_ADMIN" || userRole === "ADMIN" ? (
                <Button
                  variant="contained"
                  className="btn-black"
                  onClick={handleGroupModal}
                >
                  Create Group
                </Button>
              ) : null}
            </div>
            {/* accordian */}
            {groupList?.map((row, index) => (
              <Accordion
                sx={{ width: "900px" }}
                expanded={expanded === `panel${index}`}
                onChange={handleAccordianChange(`panel${index}`, row.id)}
                key={`panel${index}`}
              >
                <AccordionSummary
                  aria-controls="panel1d-content"
                  id={`panel${index}-header`}
                >
                  <Typography>{row.name}</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  {/* <Typography> */}
                  {progressLoadeer && progressLoadeer === true ? (
                    <CircularProgress
                      sx={{
                        alignItems: "center",
                        display: "flex",
                        justifyContent: "center",
                      }}
                    />
                  ) : (
                    <TableContainer
                      component={Paper}
                      //style={{ width: "900px" }}
                    >
                      <Table sx={{ minWidth: 650 }} aria-label="simple table">
                        <TableHead>
                          <TableRow
                            sx={{
                              "& th": {
                                color: "#fff",
                                backgroundColor: "#174fba",
                              },
                            }}
                            //style={{ color: "#fff!important" }}
                          >
                            <TableCell>User</TableCell>
                            <TableCell align="center">Access level</TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {groupUsersList?.map((gurow, i) => (
                            <TableRow
                              key={`user-${i}-${row.id}`}
                              sx={{
                                "&:last-child td, &:last-child th": {
                                  border: 0,
                                },
                              }}
                            >
                              <TableCell component="th" scope="row">
                                {gurow.email}
                              </TableCell>
                              <TableCell align="center">
                                {gurow.role !== "SUPER_ADMIN" ? (
                                  <FormControl
                                    sx={{
                                      m: 1,
                                      minWidth: 120,
                                    }}
                                    size="small"
                                    variant="standard"
                                  >
                                    <InputLabel id="demo-select-small">
                                      Access level
                                    </InputLabel>
                                    <Select
                                      labelId="demo-select-small"
                                      id="demo-select-small"
                                      defaultValue={gurow.role}
                                      label="Access level"
                                      value={gurow.role}
                                      onChange={(e) =>
                                        updateAccessLevel(
                                          e.target.value,
                                          gurow.userId,
                                          {
                                            tabName: "groupList",
                                            groupId: row.id,
                                          }
                                        )
                                      }
                                      disabled={userRole === "USER"}
                                    >
                                      <MenuItem value={"ADMIN"}>Admin</MenuItem>
                                      <MenuItem value={"USER"}>Member</MenuItem>
                                    </Select>
                                  </FormControl>
                                ) : (
                                  gurow.role.replace("_", " ")
                                )}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </TableContainer>
                  )}
                  {/* </Typography> */}
                </AccordionDetails>
              </Accordion>
            ))}
          </div>

          {/* all groups tab content */}
          <div
            className={
              openTab === "distributors"
                ? "grid grid-cols-1 md:grid-cols-1 lg:grid-cols-1 xl:grid-cols-1 gap-6 mt-6"
                : "hidden"
            }
            id="link1"
          >
            <p>Add your distributors that are present across the world</p>
            <div className="">
              {userRole === "SUPER_ADMIN" || userRole === "ADMIN" ? (
                <Button
                  variant="contained"
                  className="btn-black "
                  onClick={handleMemberModal}
                >
                  Add Distributor
                </Button>
              ) : null}
            </div>

            <TableContainer component={Paper} style={{ width: "900px" }}>
              <Table sx={{ minWidth: 650 }} aria-label="simple table">
                <TableHead>
                  <TableRow
                    sx={{
                      "& th": {
                        color: "#fff",
                        backgroundColor: "#174fba",
                      },
                    }}
                  >
                    <TableCell>User</TableCell>
                    <TableCell align="center">Access level</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {distributorsList?.map((row) => (
                    <TableRow
                      key={row.userId}
                      sx={{
                        "&:last-child td, &:last-child th": { border: 0 },
                      }}
                    >
                      <TableCell component="th" scope="row">
                        {row.email}
                      </TableCell>
                      <TableCell align="center">
                        {row.role !== "SUPER_ADMIN" ? (
                          <FormControl
                            sx={{
                              m: 1,
                              minWidth: 120,
                            }}
                            size="small"
                            variant="standard"
                          >
                            <InputLabel id="demo-select-small">
                              Access level
                            </InputLabel>
                            <Select
                              labelId="demo-select-small"
                              id="demo-select-small"
                              defaultValue={row.role}
                              label="Access level"
                              value={row.role}
                              onChange={(e) =>
                                updateAccessLevel(e.target.value, row.userId, {
                                  tabName: "distributorList",
                                })
                              }
                              disabled={userRole === "USER"}
                            >
                              <MenuItem value={"ADMIN"}>Admin</MenuItem>
                              <MenuItem value={"USER"}>Member</MenuItem>
                            </Select>
                          </FormControl>
                        ) : (
                          row.role.replace("_", " ")
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </div>
        </div>
      </div>
      {/**
       * Member Modal
       */}
      <ModalWrapper
        heading="Member"
        isPopUpShow={showMembarModal}
        size="sm"
        toggleModel={handleMemberModal}
        saveBtnTitle="Invite"
        onsubmit={handleMemberSubmit(saveMember)}
      >
        <>
          <div className="grid grid-cols-4 md:grid-cols-2 lg:grid-cols-3 gap-1 mt-6 ">
            <div className="col-span-3 " style={{ display: "flex" }}>
              <Controller
                name="emails"
                control={memberFormControl}
                defaultValue=""
                render={({ field, formState }) => (
                  <TextField
                    fullWidth
                    multiline
                    maxRows={4}
                    id="emails"
                    label="Email Id *"
                    variant="standard"
                    {...field}
                    error={!!formState.memberFormErrors?.emails}
                  />
                )}
              />
              {/**
               * md:grid-cols-2 btnbg w-52 ml-5 btn-black
               */}
              {/* <Button
                            variant="contained"
                            className="md:grid-cols-2 btnbg w-52 ml-5 btn-black"
                        >
                            Members
                        </Button> */}
            </div>
            {memberFormErrors.emails &&
              memberFormErrors.emails.type === "required" && (
                <span className={"error__feedback"}>
                  {memberFormErrors.emails.message}
                </span>
              )}
          </div>
          <p>Type or paste in emails above, separated by commas.</p>
          <div className="grid grid-cols-4 md:grid-cols-2 lg:grid-cols-3 gap-1 mt-6 ">
            <div className="col-span-3 " style={{ display: "flex" }}>
              <ReactHookFormSelect
                id="accesslevel"
                name="accesslevel"
                label="Access level *"
                control={memberFormControl}
                defaultValue=""
                fullWidth
                variant="standard"
                //disabled={cId ? true : false}
              >
                {/* <MenuItem value={""}>None</MenuItem> */}
                <MenuItem value={"ADMIN"}>Admin</MenuItem>
                <MenuItem value={"USER"}>Member</MenuItem>
              </ReactHookFormSelect>
            </div>
            {memberFormErrors.accesslevel &&
              memberFormErrors.accesslevel.type === "required" && (
                <span className={"error__feedback"}>
                  {memberFormErrors.accesslevel.message}
                </span>
              )}
          </div>
          <div className="grid grid-cols-4 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6 ">
            <div className="col-span-3  " style={{ display: "flex" }}>
              <ReactHookFormSelect
                id="group"
                name="group"
                label="Group *"
                control={memberFormControl}
                defaultValue={
                  openTab === "distributors" ? distributosGroupId : ""
                }
                fullWidth
                variant="standard"
                disabled={openTab === "distributors" ? true : false}
              >
                {/* <MenuItem value={""}>None</MenuItem> */}
                {groupList.map((grpInfo) => (
                  <MenuItem key={grpInfo.id} value={grpInfo.id}>
                    {grpInfo.name}
                  </MenuItem>
                ))}
              </ReactHookFormSelect>
            </div>
            {memberFormErrors.group &&
              memberFormErrors.group.type === "required" && (
                <span className={"error__feedback"}>
                  {memberFormErrors.group.message}
                </span>
              )}
          </div>
          <p>Choose the group to be assigned.</p>
        </>
      </ModalWrapper>
      {/**
       * Group Modal
       */}
      <ModalWrapper
        heading="Create Group"
        isPopUpShow={showGroupModal}
        size="sm"
        toggleModel={handleGroupModal}
        saveBtnTitle="Save"
        onsubmit={handleGroupSubmit(saveGroup)}
      >
        <>
          <div className="grid grid-cols-4 md:grid-cols-2 lg:grid-cols-3 gap-1 mt-6 ">
            <div className="col-span-3 " style={{ display: "flex" }}>
              <Controller
                name="groupName"
                control={groupFormControl}
                defaultValue=""
                render={({ field, formState }) => (
                  <TextField
                    fullWidth
                    multiline
                    maxRows={4}
                    id="groupName"
                    label="Name *"
                    variant="standard"
                    {...field}
                    error={!!formState.groupFormErrors?.groupName}
                  />
                )}
              />
            </div>
            {groupFormErrors.groupName &&
              groupFormErrors.groupName.type === "required" && (
                <span className={"error__feedback"}>
                  {groupFormErrors.groupName.message}
                </span>
              )}
          </div>
          <div className="grid grid-cols-4 md:grid-cols-2 lg:grid-cols-3 gap-1 mt-6 ">
            <div className="col-span-3 " style={{ display: "flex" }}>
              <Controller
                name="description"
                control={groupFormControl}
                defaultValue=""
                render={({ field, formState }) => (
                  <TextField
                    fullWidth
                    multiline
                    maxRows={4}
                    id="description"
                    label="Description *"
                    variant="standard"
                    {...field}
                    error={!!formState.groupFormErrors?.description}
                  />
                )}
              />
            </div>
            {groupFormErrors.description &&
              groupFormErrors.description.type === "required" && (
                <span className={"error__feedback"}>
                  {groupFormErrors.description.message}
                </span>
              )}
          </div>
        </>
      </ModalWrapper>
    </>
  );
};

export default Members;
