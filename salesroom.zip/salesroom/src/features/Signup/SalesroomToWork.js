import React, { useEffect } from "react";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";

import MenuItem from "@mui/material/MenuItem";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";

import Loader from "../../components/Loader";
import ReactHookFormSelect from "../../components/UI/ReactHookFormSelect";
import { Button } from "@mui/material";

import { Status } from "../../common/utility";
import { businessSize, businessIndustry } from "../../common/constants";
import {
  nextStep,
  previousStep,
  updateBusinessAdditionalInfo,
  changeStatus,
} from "../../reducers/authSlice";

const salsroomFormSchema = Yup.object({
  members: Yup.string().required("Required"),
  industry: Yup.string().required("Required"),
  manufacture: Yup.string().required("Required"),
}).required();

const SalesroomToWork = () => {
  const [Isloading, setLoading] = React.useState(false);
  const businessId = useSelector((state) => state.auth.signUp.businessId);
  const businessAdditionalInfo = useSelector(
    (state) => state.auth.signUp.businessAdditionalInfo
  );
  const status = useSelector((state) => state.auth.status);
  const dispatch = useDispatch();

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(salsroomFormSchema),
  });

  useEffect(() => {
    if (status === Status.SUCCESS) {
      dispatch(changeStatus());
      setLoading(false);
      // setSalesToWork(data);
      dispatch(
        nextStep(8) // update formStage
      );
      // setTimeout(() => {
      //     setLoading(false);
      //     // setSalesToWork(data);
      //     dispatch(
      //         nextStep(8) // update formStage
      //     );
      // }, 1000);
    } else {
      setLoading(false);
      if (Object.keys(businessAdditionalInfo).length != 0) {
        reset({
          members: businessAdditionalInfo.businessSize,
          industry: businessAdditionalInfo.industry,
          manufacture: businessAdditionalInfo.manufacturing,
        });
      }
    }
  }, [dispatch, reset, status, businessAdditionalInfo]);

  const onSubmit = (data) => {
    setLoading(true);
    let postData = {
      businessSize: data.members,
      industry: data.industry,
      manufacturing: data.manufacture,
    };
    dispatch(updateBusinessAdditionalInfo({ businessId, postData }));
    // reset();
  };

  return (
    <div>
      <form>
        <div className="header mb-3">
          <h2 className="text-[26px] font-medium mb-0">
            Put Salesroom to work
          </h2>
          <p className="text-gray-500 text-lg  font-medium">
            This will help us customise salesroom for you
          </p>
        </div>
        <div className="grid grid-cols-4 gap-3">
          <div className="body col-span-4 ">
            <div className="grid grid-cols-4 gap-3">
              <div className="col-span-4">
                <ReactHookFormSelect
                  id="members-select"
                  name="members"
                  label="How many members do you have in your
							organisation?"
                  control={control}
                  defaultValue=""
                  fullWidth
                  variant="standard"
                  disabled={false}
                >
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  {businessSize.map((menu) => (
                    <MenuItem key={menu.value} value={menu.value}>
                      {menu.label}
                    </MenuItem>
                  ))}
                </ReactHookFormSelect>
                {errors.members && errors.members.type === "required" && (
                  <span className={"error__feedback"}>
                    {errors.members.message}
                  </span>
                )}
              </div>
              <div className="col-span-4">
                <ReactHookFormSelect
                  id="industry-select"
                  name="industry"
                  label="Which industry does your organisation belong to
								?"
                  control={control}
                  fullWidth
                  variant="standard"
                  defaultValue=""
                  disabled={false}
                >
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  {businessIndustry.map((menu) => (
                    <MenuItem key={menu.value} value={menu.value}>
                      {menu.label}
                    </MenuItem>
                  ))}
                </ReactHookFormSelect>
                {errors.industry && errors.industry.type === "required" && (
                  <span className={"error__feedback"}>
                    {errors.industry.message}
                  </span>
                )}
              </div>
              <div className="col-span-4">
                <ReactHookFormSelect
                  id="manufacture-select"
                  name="manufacture"
                  label="What does your company manufacture?"
                  control={control}
                  fullWidth
                  variant="standard"
                  defaultValue=""
                  disabled={false}
                >
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  <MenuItem key="Furnace machines" value="Furnace machines">
                    Furnace machines
                  </MenuItem>
                </ReactHookFormSelect>
                {errors.manufacture &&
                  errors.manufacture.type === "required" && (
                    <span className={"error__feedback"}>
                      {errors.manufacture.message}
                    </span>
                  )}
              </div>
            </div>
          </div>
        </div>

        <div className="footer col-span-4  flex justify-between my-5 ">
          <Button
            type="button"
            style={{ marginRight: "1rem" }}
            className="btnoutline  "
            onClick={() =>
              dispatch(
                previousStep() // update formStage
              )
            }
          >
            Back
          </Button>

          <div>
            {/* <Button
                        type={"button"}
                        style={{ marginRight: "1rem" }}
                        onClick={next}
                    >
                        Skip
                    </Button> */}

            <Button
              type="submit"
              className="btn-blue"
              onClick={handleSubmit(onSubmit)}
              //onClick={next}
            >
              {Isloading ? <Loader isLoading={Isloading} /> : "Next"}
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default SalesroomToWork;
