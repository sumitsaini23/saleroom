import React from "react";
import Box from "@mui/material/Box";
import CssBaseline from "@mui/material/CssBaseline";
import NavBar from "../components/Navigation/NavBar";

function Layout(props) {
  return (
    <Box sx={{ display: "flex" }}>
      <CssBaseline />
      <NavBar {...props} />
      <Box component="main" sx={{ flexGrow: 1, p: 3, background: "#F4F7FE" }}>
        {/* Use Breadcrups in place of drawerHeader
    <DrawerHeader />
    */}
        <br />
        <br />
        {props.children}
      </Box>
    </Box>
  );
}

export default Layout;
