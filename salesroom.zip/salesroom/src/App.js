import React, { useEffect, Suspense, lazy, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import {
  ToastContainer,
  Bounce, //Zoom, Flip, Bounce, Slide
} from "react-toastify";
//import Dashboard from "./features/Dashboard/Dashboard";
import MyProducts from "./features/MyProducts/MyProducts";
import Images from "./features/Images/Images";
import Manuals from "./features/Manuals/Manuals";
import CadFiles from "./features/CadFiles/CadFiles";
import Catalogues from "./features/Catalogues/Catalogues";
import Contact from "./features/Contact/Contact";
import Videos from "./features/Videos/Videos";
import Setting from "./features/Setting/Setting";
import WhatsAppLead from "./features/WhatsAppLead";
import EmailLead from "./features/Email/EmailLead";
import Members from "./features/Members/Members";
import CategoryProductsCmp from "./features/Categories/CategoryProductsCmp";
import AddProduct from "./features/MyProducts/AddProduct";
import EditProduct from "./features/MyProducts/EditProduct";
import AuthRoute from "./components/AuthRoute";
import Layout from "./app/Layout";
import "./App.css";
import { appLoad, clearRedirect } from "./reducers/commonSlice";
import EmailTemplates from "./features/Email/EmailTemplates";
import EmailHome from "./features/Email/EmailHome";
// import { appLoad } from "./reducers/commonSlice";

const Login = lazy(() => import("./features/Login/Login"));
const Signup = lazy(() => import("./features/Signup/Signup"));
const InviteUser = lazy(() => import("./features/Members/InviteUser"));
function App() {
  const dispatch = useDispatch();
  const [provideEmail, setProvideEmail] = useState(false);
  //const redirectTo = useSelector((state) => state.common.redirectTo);
  const isLoggedIn = useSelector((state) => state.auth.isLoggedIn);

  useEffect(() => {
    const token = window.localStorage.getItem("token");
    const userId = window.localStorage.getItem("userId");
    if (token && userId) {
      dispatch(appLoad(token, userId));
    }
  }, [dispatch]);

  const authRoutes = () => {
    if (isLoggedIn) {
      return (
        <>
          <Route
            path="/dashboard"
            element={
              <Layout>
                <MyProducts />
              </Layout>
            }
          />
          <Route
            path="products"
            element={
              <Layout>
                <MyProducts />
              </Layout>
            }
          />
          <Route
            path="addProduct"
            element={
              <Layout>
                <AddProduct />
              </Layout>
            }
          />
          <Route
            path="editProduct"
            element={
              <Layout>
                <EditProduct />
              </Layout>
            }
          />
          <Route
            path="category/products"
            element={
              <Layout>
                <CategoryProductsCmp />
              </Layout>
            }
          />
          <Route
            path="images"
            element={
              <Layout>
                <Images />
              </Layout>
            }
          />
          <Route
            path="manuals"
            element={
              <Layout>
                <Manuals />
              </Layout>
            }
          />
          <Route
            path="cadFiles"
            element={
              <Layout>
                <CadFiles />
              </Layout>
            }
          />
          <Route
            path="catalogues"
            element={
              <Layout>
                <Catalogues />
              </Layout>
            }
          />
          <Route
            path="contact"
            element={
              <Layout>
                <Contact />
              </Layout>
            }
          />
          <Route
            path="videos"
            element={
              <Layout>
                <Videos />
              </Layout>
            }
          />

          <Route
            path="emailHome"
            element={
              <Layout>
                <EmailHome />
              </Layout>
            }
          />
          <Route
            path="emailLeads"
            element={
              <Layout>
                <EmailLead />
              </Layout>
            }
          />
          <Route
            path="emailtemplates"
            element={
              <Layout>
                {" "}
                <EmailTemplates />{" "}
              </Layout>
            }
          />
          <Route
            path="members"
            element={
              <Layout>
                <Members />
              </Layout>
            }
          />
          <Route
            path="setting"
            element={
              <Layout>
                <Setting />
              </Layout>
            }
          />
          <Route
            path="whatsapp_leads"
            element={
              <Layout>
                <WhatsAppLead />
              </Layout>
            }
          />
        </>
      );
    } else {
      return null;
    }
  };

  return (
    <>
      <Router>
        <Suspense
          fallback={
            <div className="h-screen flex justify-center items-center">
              <img
                alt="spinner"
                src={require("./assets/images/icon/spinner.gif")}
                className="h-40"
              />
            </div>
          }
        >
          <Routes>
            <Route
              path="/"
              element={
                <AuthRoute type="guest">
                  <Login setProvideEmail={setProvideEmail} />
                </AuthRoute>
              }
            />
            <Route
              path="GetStarted/Signup"
              element={
                <AuthRoute type="guest">
                  <Signup provideEmail={provideEmail} />
                </AuthRoute>
              }
            />
            <Route
              path="Signup"
              element={
                <AuthRoute type="guest">
                  <Signup />
                </AuthRoute>
              }
            />
            <Route
              path="invite/:encodeId"
              element={
                <AuthRoute type="guest">
                  <InviteUser />
                </AuthRoute>
              }
            />
            {/* Private routes */}
            <Route
              path="/dashboard"
              element={
                <AuthRoute type="private">
                  <Layout>
                    <MyProducts />
                  </Layout>
                </AuthRoute>
              }
            />
            <Route
              path="products"
              element={
                <AuthRoute type="private">
                  <Layout>
                    <MyProducts />
                  </Layout>
                </AuthRoute>
              }
            />
            <Route
              path="addProduct"
              element={
                <AuthRoute type="private">
                  <Layout>
                    <AddProduct />
                  </Layout>
                </AuthRoute>
              }
            />
            <Route
              path="editProduct"
              element={
                <AuthRoute type="private">
                  <Layout>
                    <EditProduct />
                  </Layout>
                </AuthRoute>
              }
            />
            <Route
              path="category/products"
              element={
                <AuthRoute type="private">
                  <Layout>
                    <CategoryProductsCmp />
                  </Layout>
                </AuthRoute>
              }
            />
            <Route
              path="images"
              element={
                <AuthRoute type="private">
                  <Layout>
                    <Images />
                  </Layout>
                </AuthRoute>
              }
            />
            <Route
              path="manuals"
              element={
                <AuthRoute type="private">
                  <Layout>
                    <Manuals />
                  </Layout>
                </AuthRoute>
              }
            />
            <Route
              path="cadFiles"
              element={
                <AuthRoute type="private">
                  <Layout>
                    <CadFiles />
                  </Layout>
                </AuthRoute>
              }
            />
            <Route
              path="catalogues"
              element={
                <AuthRoute type="private">
                  <Layout>
                    <Catalogues />
                  </Layout>
                </AuthRoute>
              }
            />
            <Route
              path="contact"
              element={
                <AuthRoute type="private">
                  <Layout>
                    <Contact />
                  </Layout>
                </AuthRoute>
              }
            />
            <Route
              path="videos"
              element={
                <AuthRoute type="private">
                  <Layout>
                    <Videos />
                  </Layout>
                </AuthRoute>
              }
            />

            <Route
              path="emailHome"
              element={
                <AuthRoute type="private">
                  <Layout>
                    <EmailHome />
                  </Layout>
                </AuthRoute>
              }
            />
            <Route
              path="emailLeads"
              element={
                <AuthRoute type="private">
                  <Layout>
                    <EmailLead />
                  </Layout>
                </AuthRoute>
              }
            />
            <Route
              path="emailtemplates"
              element={
                <AuthRoute type="private">
                  <Layout>
                    {" "}
                    <EmailTemplates />{" "}
                  </Layout>
                </AuthRoute>
              }
            />
            <Route
              path="members"
              element={
                <AuthRoute type="private">
                  <Layout>
                    <Members />
                  </Layout>
                </AuthRoute>
              }
            />
            <Route
              path="setting"
              element={
                <AuthRoute type="private">
                  <Layout>
                    <Setting />
                  </Layout>
                </AuthRoute>
              }
            />
            <Route
              path="whatsapp_leads"
              element={
                <AuthRoute type="private">
                  <Layout>
                    <WhatsAppLead />
                  </Layout>
                </AuthRoute>
              }
            />
            <Route
              path="*"
              exact={true}
              element={<Login setProvideEmail={setProvideEmail} />}
            />
          </Routes>
        </Suspense>
      </Router>
      <ToastContainer
        position="bottom-right"
        autoClose={2000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        limit={1}
        transition={Bounce}
        theme="colored"
      />
    </>
  );
}

export default App;
