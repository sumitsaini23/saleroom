import React from "react";
//import SideBar from "../../components/Navigation/SideBar";
import MyProducts from "../MyProducts/MyProducts";
const Dashboard = () => {
  return <MyProducts />;
};

export default Dashboard;
