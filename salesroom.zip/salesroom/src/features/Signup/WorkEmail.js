import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useForm, Controller } from "react-hook-form";
import { Button, TextField } from "@mui/material";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";

import "./Signup.module.scss";
import Loader from "../../components/Loader";
import { nextStep, userRegister, changeStatus } from "../../reducers/authSlice";
import { Status, emailPattern } from "../../common/utility";

const emailValidateSchema = Yup.object({
  email: Yup.string()
    .required("Required")
    .matches(emailPattern, "Invalid email ID"),
}).required();

const WorkEmail = () => {
  // const { next } = useContext(MultiStepFormContext);
  const status = useSelector((state) => state.auth.status);
  const regEmail = useSelector((state) => state.auth.signUp.email);
  const [Isloading, setLoading] = useState(false);
  const dispatch = useDispatch();

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(emailValidateSchema),
  });

  useEffect(() => {
    if (status === Status.SUCCESS && regEmail !== "") {
      setLoading(false);
      dispatch(changeStatus());
      dispatch(
        nextStep(2) // update formStage
      );
      // setTimeout(() => {
      //     setLoading(false);
      //     //setWorkEmail(EmailValue);
      //     //next();
      // }, 1000);
    } else if (regEmail !== "") {
      reset({
        email: regEmail || "",
      });
    }
  }, [status, regEmail, reset, dispatch]);

  const onSubmit = async (data) => {
    setLoading(true);
    let email = data.email;
    await dispatch(userRegister({ email }));
    // reset();
  };

  return (
    <form>
      <div className="header  mb-7">
        <h2 className="text-[26px] font-medium">Get started with Salesroom</h2>
      </div>
      <div className="grid grid-cols-4 gap-3">
        <div className="body col-span-4 pt-12">
          <div>
            <Controller
              name="email"
              control={control}
              defaultValue=""
              render={({ field, formState }) => (
                <TextField
                  fullWidth
                  id="email"
                  label="Email *"
                  variant="standard"
                  {...field}
                  error={!!formState.errors?.email}
                />
              )}
            />
            {errors.email && errors.email.type === "required" && (
              <span className={"error__feedback"}>{errors.email.message}</span>
            )}
            {errors.email && errors.email.type === "matches" && (
              <span className={"error__feedback"}>{errors.email.message}</span>
            )}
          </div>
          <div
            className={"form__item button__items d-flex justify-content-end"}
          ></div>
        </div>
        <div className="footer col-span-4 flex justify-between mb-5">
          <div></div>

          <Button
            onClick={handleSubmit(onSubmit)}
            // onClick={() =>
            //     dispatch(
            //         nextStep(2) // update formStage
            //     )
            // }
            type="submit"
            className="btn-blue"
          >
            {Isloading ? <Loader isLoading={Isloading} /> : "Next"}
          </Button>
        </div>
      </div>
    </form>
  );
};
export default WorkEmail;
