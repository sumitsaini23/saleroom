import React from "react";
import { useSelector, useDispatch } from "react-redux";
//import Swal from "sweetalert2";
import FormControl from "@mui/material/FormControl";
//import TextField from "@mui/material/TextField";

import ModalWrapper from "../../UI/ModalWrapper";
import SelectMuiCmp from "../../UI/SelectMuiCmp";
import { hideModal } from "../../../reducers/modalSlice";

//import UploadModal from "../UploadModal";

const ManualModal = () => {
  const showModal = useSelector((state) => state.modalView.showModal);
  const dispatch = useDispatch();
  let uploadModal = false;

  const UploadModal = () => {
    return (
      <ModalWrapper
        heading="Choose file to upload"
        isPopUpShow={showModal}
        size="xs"
        toggleModel={() => dispatch(hideModal())}
        saveBtnTitle="Done"
      >
        <div className="relative p-6 flex-auto">
          <FormControl sx={{ m: 1, minWidth: 120 }}>
            <SelectMuiCmp label="Selcet Product" />
          </FormControl>
        </div>
      </ModalWrapper>
    );
  };

  const ManualModalContent = () => {
    return (
      <ModalWrapper
        heading="Add Category"
        isPopUpShow={showModal}
        size="xs"
        toggleModel={() => dispatch(hideModal())}
        saveBtnTitle="Done"
      >
        <div className="relative p-6 flex-auto">
          <FormControl sx={{ m: 1, minWidth: 120 }}>
            <SelectMuiCmp label="Select Product" />
          </FormControl>
        </div>
      </ModalWrapper>
    );
  };
  return (
    <>
      {showModal && (
        <>
          <div className="justify-center items-center flex overflow-x-hidden overflow-y-auto fixed inset-0 z-50 outline-none focus:outline-none">
            <div className="relative w-auto my-6 mx-auto">
              {/*content*/}
              <div className="border-0 rounded-lg shadow-lg relative flex flex-col w-full bg-white outline-none focus:outline-none">
                {uploadModal ? <UploadModal /> : <ManualModalContent />}
              </div>
            </div>
          </div>
          <div className="opacity-25 fixed inset-0 z-40 bg-black"></div>
        </>
      )}
    </>
  );
};

export default ManualModal;
