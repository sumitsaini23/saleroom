import React, { useEffect, useCallback, useState, useRef } from "react";
import FileViewer from "react-file-viewer";
import { useDispatch, useSelector } from "react-redux";
import { useForm, Controller } from "react-hook-form";
//import { yupResolver } from "@hookform/resolvers/yup";
//import * as Yup from "yup";
import DeleteOutlinedIcon from "@mui/icons-material/DeleteOutlined";
import { Button, TextField } from "@mui/material";
import { MdAdd } from "react-icons/md";
import PreviewModalWrapper from "../../components/UI/PreviewModalWrapper";
import {
    getSortName,
    getFileName,
    getPreSignUrlFileType,
    getPreSignUrlLink,
    ToastAlert,
    uploadFile,
    getFileNameByUrl,
    getFileExtensionByUrl,
    getDecodecFileUrl,
    getFileDetails,
} from "../../common/utility";
import {
    ALERT_ERROR,
    ALERT_SUCCESS,
    ALERT_INFO,
    imageExtension,
    docExtension,
    cadExtension,
    videoExtension,
} from "../../common/constants";
import { CircularProgress } from "@mui/material";

import { saveproductUploaddetails } from "../../reducers/productSlice";
import * as _ from "lodash";
//import requestsApi from "../../app/requestsApi";
//import axios from "axios";

// const uploadvalidateschema = Yup.object({
//     manualLink: Yup.string().required("Required"),
//     CatalogueManualLink: Yup.string().required("Required"),
// }).required();

const initialUploadState = {
    IMAGES: false,
    MANUAL: false,
    CATALOG: false,
    CAD_INFOS: false,
    VIDEOS: false,
};

const initialUploadProgressState = {
    IMAGES: 0,
    MANUAL: 0,
    CATALOG: 0,
    CAD_INFOS: 0,
    VIDEOS: 0,
};

const TabContentUploads = (props) => {
    const dispatch = useDispatch();
    const crateProductdata = useRef({});
    const imgRef = useRef();
    const manualRef = useRef();
    const catalogRef = useRef();
    const cadRef = useRef();
    const videoRef = useRef();
    const businessId = useSelector((state) => state.auth?.user?.businessId);
    let createProductObj = useSelector(
        (state) => state.products.createProductObj
    );

    const [imgArray, setImgArray] = useState([]);
    const [manualArray, setManualArray] = useState([]);
    const [catalogueArray, setCatalogueArray] = useState([]);
    const [cadArray, setCadArray] = useState([]);
    const [videoArray, setVideoArray] = useState([]);
    const [isProductImgLoad, setIsProductImgLoad] = useState(false);
    const [viewDocUrl, setViewDocUrl] = useState(false);
    const [previewModal, setPreviewModal] = useState(false);

    const [uploadingStatus, setUploadingStatus] = useState(false);
    const [uploadProgress, setUploadProgress] = useState(0);
    const dynamicIcon = (title) => {
        return uploadingStatus[title] ? (
            <>
                <h2 className="fontheadclr">{`Uploading...`}</h2>
                <CircularProgress
                    variant="determinate"
                    value={uploadProgress[title]}
                />
            </>
        ) : (
            <>
                <h2 className="fontheadclr">{`Add ${
                    title === "CAD_INFOS"
                        ? "CAD / Design Files"
                        : _.capitalize(title)
                }`}</h2>
                <MdAdd className="iconadd" />
            </>
        );
    };

    const onUploadProgress = (event, category) => {
        const { loaded, total } = event;
        const uploadPercentage = (loaded / total) * 100;
        setUploadProgress((prevState) => {
            return { ...prevState, [category]: uploadPercentage };
        });
        if (uploadPercentage == 100) {
            setUploadProgress((prevState) => {
                return { ...prevState, [category]: 0 };
            });
            updateUploadStatus(category, false);
        }
    };

    const updateUploadStatus = (category, status) => {
        setUploadingStatus((prevState) => {
            return { ...prevState, [category]: status };
        });
    };

    const {
        control,
        handleSubmit,
        reset,
        formState: { errors },
    } = useForm();

    useEffect(() => {
        crateProductdata.current = createProductObj;
    });

    const getPreviousImgData = (proinfo) => {
        let image_urls = [];
        if (
            proinfo?.productDocs?.image_urls &&
            proinfo?.productDocs?.image_urls.length > 0
        ) {
            let imgArr = [...imgArray];
            (proinfo.productDocs.image_urls || []).forEach((element) => {
                let mainUrl = getDecodecFileUrl(element);
                imgArr.push({
                    fileurl: element,
                    serverUrl: mainUrl,
                    fileName: getFileNameByUrl(element, "/IMAGES/"),
                    fileExt: getFileExtensionByUrl(element),
                });
                image_urls.push(mainUrl);
            });
            setImgArray(imgArr);
        }
        return image_urls;
    };

    const getPreviousManualData = (proinfo) => {
        let manuals_urls = [];
        if (
            proinfo?.productDocs?.manuals_urls &&
            proinfo?.productDocs?.manuals_urls.length > 0
        ) {
            let mannualArr = [...manualArray];
            (proinfo.productDocs.manuals_urls || []).forEach((element) => {
                let mainUrl = getDecodecFileUrl(element);
                mannualArr.push({
                    fileurl: element,
                    serverUrl: mainUrl,
                    fileName: getFileNameByUrl(element, "/MANUAL/"),
                    fileExt: getFileExtensionByUrl(element),
                });
                manuals_urls.push(mainUrl);
            });
            setManualArray(mannualArr);
        }
        return manuals_urls;
    };

    const getPreviousCatalogData = (proinfo) => {
        let catalogue_urls = [];
        if (
            proinfo?.productDocs?.catalog_urls &&
            proinfo?.productDocs?.catalog_urls.length > 0
        ) {
            let catlogArr = [...catalogueArray];
            (proinfo?.productDocs?.catalog_urls || []).forEach((element) => {
                let mainUrl = getDecodecFileUrl(element);
                catlogArr.push({
                    fileurl: element,
                    serverUrl: getDecodecFileUrl(element),
                    fileName: getFileNameByUrl(element, "/CATALOG/"),
                    fileExt: getFileExtensionByUrl(element),
                });
                catalogue_urls.push(mainUrl);
            });
            setCatalogueArray(catlogArr);
        }
        return catalogue_urls;
    };

    const getPreviousCadData = (proinfo) => {
        let cad_urls = [];
        if (
            proinfo?.productDocs?.cad_urls &&
            proinfo?.productDocs?.cad_urls.length > 0
        ) {
            let cadArr = [...cadArray];
            (proinfo?.productDocs?.cad_urls || []).forEach((element) => {
                let mainUrl = getDecodecFileUrl(element);
                cadArr.push({
                    fileurl: element,
                    serverUrl: mainUrl,
                    fileName: getFileNameByUrl(element, "/CAD_INFOS/"),
                    fileExt: getFileExtensionByUrl(element),
                });
                cad_urls.push(mainUrl);
            });
            setCadArray(cadArr);
        }
        return cad_urls;
    };

    const getPreviousVideoData = (proinfo) => {
        let video_urls = [];
        if (
            proinfo?.productDocs?.video_urls &&
            proinfo?.productDocs?.video_urls.length > 0
        ) {
            let vdoArr = [...videoArray];
            (proinfo?.productDocs?.video_urls || []).forEach((element) => {
                let mainUrl = getDecodecFileUrl(element);
                vdoArr.push({
                    fileurl: element,
                    serverUrl: mainUrl,
                    fileName: getFileNameByUrl(element, "/VIDEOS/"),
                    fileExt: getFileExtensionByUrl(element),
                });
                video_urls.push(mainUrl);
            });
            setVideoArray(vdoArr);
        }
        return video_urls;
    };

    const setPreviousData = useCallback(
        (proinfo) => {
            let image_urls = getPreviousImgData(proinfo);
            let manuals_urls = getPreviousManualData(proinfo);
            let catalogue_urls = getPreviousCatalogData(proinfo);
            let cad_urls = getPreviousCadData(proinfo);
            let video_urls = getPreviousVideoData(proinfo);
            reset({
                manualLink: proinfo?.productDocs?.custom_links?.[0],
                CatalogueManualLink: proinfo?.productDocs?.custom_links?.[1],
            });

            dispatch(
                saveproductUploaddetails({
                    cad_urls: cad_urls.length > 0 ? cad_urls : null,
                    catalogue_urls:
                        catalogue_urls.length > 0 ? catalogue_urls : null,
                    custom_links: [
                        proinfo?.productDocs?.custom_links?.[0],
                        proinfo?.productDocs?.custom_links?.[1],
                    ],
                    image_urls: image_urls.length > 0 ? image_urls : null,
                    manuals_urls: manuals_urls.length > 0 ? manuals_urls : null,
                    video_urls: video_urls.length > 0 ? video_urls : null,
                })
            );
        },
        [reset, dispatch]
    );

    useEffect(() => {
        if (props.action && props.action === "Edit") {
            let proinfo = props.prodata;
            setPreviousData(proinfo);
        }
    }, [props.action, props.prodata, setPreviousData]);

    const imgBoxhandleClick = (e) => {
        imgRef.current.click();
    };

    const onFileChange = (e, docType, allowedExtensions) => {
        if (!e || !e.target || !e.target.files || e.target.files.length === 0) {
            return;
        }
        const fileData = e.target.files[0];
        let { ext } = getFileDetails(fileData);

        if (!allowedExtensions.includes(ext)) {
            ToastAlert({
                type: ALERT_INFO,
                msg: "Invalid file format",
            });
            return;
        }
        getPreSignUrl(fileData, docType);
    };

    const onFileRemove = (index, docType) => {
        if (docType === "IMAGES") {
            removeImage(index);
        } else if (docType === "MANUAL") {
            removeManualFile(index);
        } else if (docType === "CATALOG") {
            removeCatalogFile(index);
        } else if (docType === "CAD_INFOS") {
            removeCadFile(index);
        } else if (docType === "VIDEOS") {
            removeVideoFile(index);
        }
    };

    const removeImage = (index) => {
        let itemArray = [...imgArray];
        itemArray.splice(index, 1);
        setImgArray(itemArray);
    };

    const removeManualFile = (index) => {
        let itemArray = [...manualArray];
        itemArray.splice(index, 1);
        setManualArray(itemArray);
    };

    const removeCatalogFile = (index) => {
        let itemArray = [...catalogueArray];
        itemArray.splice(index, 1);
        setCatalogueArray(itemArray);
    };

    const removeCadFile = (index) => {
        let itemArray = [...cadArray];
        itemArray.splice(index, 1);
        setCadArray(itemArray);
    };

    const removeVideoFile = (index) => {
        let itemArray = [...videoArray];
        itemArray.splice(index, 1);
        setVideoArray(itemArray);
    };

    const getPreSignUrl = async (fileData, uploadCategory) => {
        let fileName = getFileName(fileData);
        let uploadFileType = getPreSignUrlFileType(fileName);
        setIsProductImgLoad(true);
        getPreSignUrlLink(businessId, fileName, uploadCategory, uploadFileType)
            .then(function (response) {
                let preSignedUrl = response.preSignedUrl;
                let path = response.path;
                /**
                 * Upload file
                 */
                confirmUploadFile(
                    preSignedUrl,
                    path,
                    fileData,
                    uploadCategory,
                    onUploadProgress
                );
            })
            .catch(function (error) {
                setIsProductImgLoad(false);
                ToastAlert({
                    type: ALERT_ERROR,
                    msg: `${uploadCategory} PreSignUrl url error`,
                });
            });
    };

    const confirmUploadFile = async (
        preSignedUrl,
        path,
        fileData,
        uploadCategory,
        onUploadProgress
    ) => {
        // uploadCategory tells if it is image, manal etc
        updateUploadStatus(uploadCategory, true);
        await uploadFile(preSignedUrl, fileData, (e) => {
            onUploadProgress(e, uploadCategory);
        })
            .then(function (response) {
                if (response.status === 200) {
                    ToastAlert({
                        type: ALERT_SUCCESS,
                        msg: "File Uploaded",
                    });
                    setIsProductImgLoad(false);
                    /**
                     * save path into state
                     */
                    updateCategoryPath(uploadCategory, path, fileData);
                }
            })
            .catch(function (error) {
                setIsProductImgLoad(false);
                ToastAlert({
                    type: ALERT_ERROR,
                    msg: `${uploadCategory} file upload error`,
                });
            });
    };

    const updateCategoryPath = (uploadCategory, path, fileData) => {
        let { fileName, fileUrl, ext } = getFileDetails(fileData);
        switch (uploadCategory) {
            case "IMAGES":
                //setImage_urls(getItemArray(image_urls, path));
                let imgArr = [...imgArray];
                imgArr.push({
                    fileurl: fileUrl,
                    serverUrl: path,
                    fileName: fileName,
                    fileExt: ext,
                });
                setImgArray(imgArr);
                break;
            case "MANUAL":
                //setManuals_urls(getItemArray(manuals_urls, path));
                let mannualArr = [...manualArray];
                mannualArr.push({
                    fileurl: fileUrl,
                    serverUrl: path,
                    fileName: fileName,
                    fileExt: ext,
                });
                setManualArray(mannualArr);
                break;
            case "CATALOG":
                //setCatalogue_urls(getItemArray(catalogue_urls, path));
                let catlogArr = [...catalogueArray];
                catlogArr.push({
                    fileurl: fileUrl,
                    serverUrl: path,
                    fileName: fileName,
                    fileExt: ext,
                });
                setCatalogueArray(catlogArr);
                break;
            case "CAD_INFOS":
                //setCad_urls(getItemArray(cad_urls, path));
                let cadArr = [...cadArray];
                cadArr.push({
                    fileurl: fileUrl,
                    serverUrl: path,
                    fileName: fileName,
                    fileExt: ext,
                });
                setCadArray(cadArr);
                break;
            case "VIDEOS":
                //setVideo_urls(getItemArray(video_urls, path));
                let vdoArr = [...videoArray];
                vdoArr.push({
                    fileurl: fileUrl,
                    serverUrl: path,
                    fileName: fileName,
                    fileExt: ext,
                });
                setVideoArray(vdoArr);
                break;
            default:
                break;
        }
    };

    const handleUploadSubmit = (data) => {
        let image_urls = [];
        let manuals_urls = [];
        let catalogue_urls = [];
        let cad_urls = [];
        let video_urls = [];
        (imgArray || []).forEach((ele) => {
            image_urls.push(ele.serverUrl);
        });
        (manualArray || []).forEach((ele) => {
            manuals_urls.push(ele.serverUrl);
        });
        (catalogueArray || []).forEach((ele) => {
            catalogue_urls.push(ele.serverUrl);
        });
        (cadArray || []).forEach((ele) => {
            cad_urls.push(ele.serverUrl);
        });
        (videoArray || []).forEach((ele) => {
            video_urls.push(ele.serverUrl);
        });

        dispatch(
            saveproductUploaddetails({
                cad_urls: cad_urls.length > 0 ? cad_urls : null,
                catalogue_urls:
                    catalogue_urls.length > 0 ? catalogue_urls : null,
                custom_links: [data.manualLink, data.CatalogueManualLink],
                image_urls: image_urls.length > 0 ? image_urls : null,
                manuals_urls: manuals_urls.length > 0 ? manuals_urls : null,
                video_urls: video_urls.length > 0 ? video_urls : null,
            })
        );
        props.changeTab("Specifications");
    };

    const handlePreviewModal = () => {
        let val = !previewModal;
        if (val === false) {
            setViewDocUrl("");
        }
        setPreviewModal(val);
    };

    return (
        <>
            <form>
                {/* Images */}
                <div className="mb-10">
                    <div className="title">
                        <h4 className="mb-6">
                            <b>Images</b>
                        </h4>
                        <p className="text-[#908787] mb-1 font12">
                            Add images (At least 3) Allowed extension
                            jpeg,jpg,png
                        </p>
                    </div>
                    <div className="flex gap-5">
                        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-3 gap-6 mt-6">
                            {/* Images list */}
                            {(imgArray || []).map((data, i) => (
                                <div className="mainbox">
                                    <div className="boxMain">
                                        <div className="boxinner">
                                            <div className="boxOne">
                                                <div className="boxOneinner">
                                                    <img
                                                        src={data.fileurl}
                                                        alt="..."
                                                    />
                                                </div>
                                            </div>
                                        </div>

                                        <div className="boxTwo">
                                            <span
                                                style={{ marginLeft: "37px" }}
                                            >
                                                {getSortName(data.fileName, 12)}
                                            </span>
                                            <span style={{ float: "right" }}>
                                                <DeleteOutlinedIcon
                                                    sx={{
                                                        color: "#174fba",
                                                    }}
                                                    onClick={() =>
                                                        onFileRemove(
                                                            i,
                                                            "IMAGES"
                                                        )
                                                    }
                                                />
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            ))}
                            {/* Images Upload */}
                            <div className="mainbox">
                                <div
                                    className="boxMain"
                                    style={{
                                        border: "2px dashed #174fba",
                                        // height: "100%",
                                        borderRadius: "10px",
                                        background: "#F4F7FE",
                                    }}
                                    onClick={imgBoxhandleClick}
                                >
                                    <div className="boxinner">
                                        <div className="boxOneadd">
                                            <div className="boxOneinner">
                                                <input
                                                    ref={imgRef}
                                                    type="file"
                                                    accept=".jpg,.jpeg,.JPG,.JPEG,.PNG,.png | image/*"
                                                    //accept=".jpg,.jpeg,.png |audio/*|video/*|image/*|media_type"
                                                    onChange={(e) =>
                                                        onFileChange(
                                                            e,
                                                            "IMAGES",
                                                            imageExtension
                                                        )
                                                    }
                                                    style={{ display: "none" }}
                                                />
                                                {dynamicIcon("IMAGES")}
                                            </div>
                                        </div>
                                    </div>
                                    <div className="boxTwo-img"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {/* Header */}
                <div className="mb-10">
                    <div className="title">
                        <h4 className="mb-6">
                            <b>Manuals</b>
                        </h4>
                        <p className="text-[#908787] mb-1 font12">
                            Add Manuals
                        </p>
                        <p className="text-[#908787] mb-1 font12">
                            Allowed pdf,doc,ppt,pptx
                        </p>
                    </div>

                    <div className="flex gap-5 mb-8">
                        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-3 gap-6 mt-6">
                            {/* Manual list */}
                            {(manualArray || []).map((data, i) => (
                                <div className="mainbox">
                                    <div className="boxMain">
                                        <div className="boxinner">
                                            <div className="boxOne">
                                                <div className="boxOneinner">
                                                    <img
                                                        src={
                                                            data.fileExt ===
                                                            "pdf"
                                                                ? require(`../../assets/images/image/awesome-file-pdf.png`)
                                                                : require(`../../assets/images/image/Group 658.png`)
                                                        }
                                                        alt="..."
                                                    />
                                                </div>
                                            </div>
                                        </div>

                                        <div className="boxTwo">
                                            <img
                                                src={
                                                    data.fileExt === "pdf"
                                                        ? require(`../../assets/images/image/awesome-file-pdf.png`)
                                                        : require(`../../assets/images/image/Group 658.png`)
                                                }
                                                alt="img"
                                            />
                                            <span>
                                                {getSortName(data.fileName, 16)}
                                            </span>
                                            <span style={{ float: "right" }}>
                                                <DeleteOutlinedIcon
                                                    sx={{
                                                        color: "#174fba",
                                                    }}
                                                    onClick={() =>
                                                        onFileRemove(
                                                            i,
                                                            "MANUAL"
                                                        )
                                                    }
                                                />
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            ))}
                            <div className="mainbox">
                                <div
                                    className="boxMain"
                                    style={{
                                        border: "2px dashed #174fba",
                                        // height: "100%",
                                        borderRadius: "10px",
                                        background: "#F4F7FE",
                                    }}
                                    onClick={() => manualRef.current.click()}
                                >
                                    <div className="boxinner">
                                        <div className="boxOneadd">
                                            <div className="boxOneinner">
                                                <input
                                                    ref={manualRef}
                                                    type="file"
                                                    accept=".pdf,.doc,.docx,.ppt,.pptx"
                                                    onChange={(e) =>
                                                        onFileChange(
                                                            e,
                                                            "MANUAL",
                                                            docExtension
                                                        )
                                                    }
                                                    style={{ display: "none" }}
                                                />
                                                {dynamicIcon("MANUAL")}
                                            </div>
                                        </div>
                                    </div>
                                    <div className="boxTwo-img"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <label className="font12" htmlFor="SellingPrice">
                        Add Digital Manual Link (Optional)
                    </label>
                    <div className="grid grid-cols-5 gap-3">
                        <div className="col-span-3 ">
                            {/* 2 */}
                            <Controller
                                name="manualLink"
                                control={control}
                                defaultValue=""
                                render={({ field, formState }) => (
                                    <TextField
                                        fullWidth
                                        id="manualLink"
                                        label="Paste URL here "
                                        variant="standard"
                                        {...field}
                                        error={!!formState.errors?.manualLink}
                                    />
                                )}
                            />
                        </div>
                    </div>
                </div>
                <div className="mb-10">
                    <div className="title">
                        <h4 className="mb-6">
                            <b>Catalogue</b>
                        </h4>
                        {/* <p className="text-[#908787] mb-1 font12">
                            Add Catalogue
                        </p> */}
                        <p className="text-[#908787] mb-1 font12">
                            Allowed pdf,doc,ppt,pptx
                        </p>
                    </div>
                    <div className="flex gap-5 mb-8">
                        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-3 gap-6 mt-6">
                            {(catalogueArray || []).map((data, i) => (
                                <div className="mainbox">
                                    <div className="boxMain">
                                        <div className="boxinner">
                                            <div className="boxOne">
                                                <div className="boxOneinner">
                                                    <img
                                                        src={
                                                            data.fileExt ===
                                                            "pdf"
                                                                ? require(`../../assets/images/image/awesome-file-pdf.png`)
                                                                : require(`../../assets/images/image/Group 658.png`)
                                                        }
                                                        alt="..."
                                                    />
                                                </div>
                                            </div>
                                        </div>

                                        <div className="boxTwo">
                                            <img
                                                src={
                                                    data.fileExt === "pdf"
                                                        ? require(`../../assets/images/image/awesome-file-pdf.png`)
                                                        : require(`../../assets/images/image/Group 658.png`)
                                                }
                                                alt="img"
                                            />
                                            <span>
                                                {getSortName(data.fileName, 16)}
                                            </span>
                                            <span style={{ float: "right" }}>
                                                <DeleteOutlinedIcon
                                                    sx={{
                                                        color: "#174fba",
                                                    }}
                                                    onClick={() =>
                                                        onFileRemove(
                                                            i,
                                                            "CATALOG"
                                                        )
                                                    }
                                                />
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            ))}
                            <div className="mainbox">
                                <div
                                    className="boxMain"
                                    style={{
                                        border: "2px dashed #174fba",
                                        // height: "100%",
                                        borderRadius: "10px",
                                        background: "#F4F7FE",
                                    }}
                                    onClick={() => catalogRef.current.click()}
                                >
                                    <div className="boxinner">
                                        <div className="boxOneadd">
                                            <div className="boxOneinner">
                                                <input
                                                    ref={catalogRef}
                                                    type="file"
                                                    accept=".pdf,.doc,.docx,.ppt,.pptx"
                                                    onChange={(e) =>
                                                        onFileChange(
                                                            e,
                                                            "CATALOG",
                                                            docExtension
                                                        )
                                                    }
                                                    style={{ display: "none" }}
                                                />
                                                {dynamicIcon("CATALOG")}
                                            </div>
                                        </div>
                                    </div>
                                    <div className="boxTwo-img"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <label className="font12">
                        Add Catalogue Manual Link (Optional)
                    </label>
                    <div className="grid grid-cols-5 gap-3">
                        <div className="col-span-3 ">
                            {/* 2 */}
                            <Controller
                                name="CatalogueManualLink"
                                control={control}
                                defaultValue=""
                                render={({ field, formState }) => (
                                    <TextField
                                        fullWidth
                                        id="CatalogueManualLink"
                                        label="Paste URL here "
                                        variant="standard"
                                        {...field}
                                        error={!!formState.errors?.manualLink}
                                    />
                                )}
                            />
                        </div>
                    </div>
                </div>
                <div className="mb-10">
                    <div className="title">
                        <h4 className="mb-6">
                            <b>CAD / Design Files</b>
                        </h4>
                        {/* <p className="text-[#908787] mb-1 font12">
                            Add CAD / Design Files
                        </p> */}
                        <p className="text-[#908787] mb-1 font12">
                            Allowed stp,step,abc,sldasm,sldprt
                        </p>
                    </div>
                    <div className="flex gap-5">
                        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-3 gap-6 mt-6">
                            {(cadArray || []).map((data, i) => (
                                <div className="mainbox">
                                    <div className="boxMain">
                                        <div className="boxinner">
                                            <div className="boxOne">
                                                <div className="boxOneinner">
                                                    <img
                                                        src={
                                                            data.fileExt ===
                                                            "pdf"
                                                                ? require(`../../assets/images/image/awesome-file-pdf.png`)
                                                                : require(`../../assets/images/image/Group 652.png`)
                                                        }
                                                        alt="..."
                                                    />
                                                </div>
                                            </div>
                                        </div>

                                        <div className="boxTwo">
                                            <img
                                                src={
                                                    data.fileExt === "pdf"
                                                        ? require(`../../assets/images/image/awesome-file-pdf.png`)
                                                        : require(`../../assets/images/image/Group 652.png`)
                                                }
                                                alt="img"
                                            />
                                            <span>
                                                {getSortName(data.fileName, 16)}
                                            </span>
                                            <span style={{ float: "right" }}>
                                                <DeleteOutlinedIcon
                                                    sx={{
                                                        color: "#174fba",
                                                    }}
                                                    onClick={() =>
                                                        onFileRemove(
                                                            i,
                                                            "CAD_INFOS"
                                                        )
                                                    }
                                                />
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            ))}
                            <div className="mainbox">
                                <div
                                    className="boxMain"
                                    style={{
                                        border: "2px dashed #174fba",
                                        // height: "100%",
                                        borderRadius: "10px",
                                        background: "#F4F7FE",
                                    }}
                                    onClick={() => cadRef.current.click()}
                                >
                                    <div className="boxinner">
                                        <div className="boxOneadd">
                                            <div className="boxOneinner">
                                                <input
                                                    ref={cadRef}
                                                    type="file"
                                                    accept=".stp,.step,.abc,.sldasm,.sldprt"
                                                    onChange={(e) =>
                                                        onFileChange(
                                                            e,
                                                            "CAD_INFOS",
                                                            cadExtension
                                                        )
                                                    }
                                                    style={{ display: "none" }}
                                                />
                                                {dynamicIcon("CAD_INFOS")}
                                            </div>
                                        </div>
                                    </div>
                                    <div className="boxTwo-img"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {/* Video Upload */}
                <div className="mb-10">
                    <div className="title">
                        <h4 className="mb-6">
                            <b>Video Files</b>
                        </h4>
                        <p className="text-[#908787] mb-1 font12">
                            Add Video Files
                        </p>
                    </div>
                    <div className="flex gap-5">
                        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-3 gap-6 mt-6">
                            {(videoArray || []).map((data, i) => (
                                <div className="mainbox">
                                    <div className="boxMain">
                                        <div className="boxinner">
                                            <div className="boxOne">
                                                <div className="boxOneinner">
                                                    <img
                                                        style={{
                                                            paddingTop: "25px",
                                                        }}
                                                        src={require(`../../assets/images/image/material-videocam.png`)}
                                                        alt="..."
                                                    />
                                                </div>
                                            </div>
                                        </div>

                                        <div className="boxTwo">
                                            <img
                                                style={{
                                                    width: "30px",
                                                    paddingTop: "3px",
                                                }}
                                                src={require(`../../assets/images/image/material-videocam.png`)}
                                                alt="img"
                                            />
                                            <span>
                                                {getSortName(data.fileName, 12)}
                                            </span>
                                            <span style={{ float: "right" }}>
                                                <DeleteOutlinedIcon
                                                    sx={{
                                                        color: "#174fba",
                                                    }}
                                                    onClick={() =>
                                                        onFileRemove(
                                                            i,
                                                            "VIDEOS"
                                                        )
                                                    }
                                                />
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            ))}
                            <div className="mainbox">
                                <div
                                    className="boxMain"
                                    style={{
                                        border: "2px dashed #174fba",
                                        // height: "100%",
                                        borderRadius: "10px",
                                        background: "#F4F7FE",
                                    }}
                                    onClick={() => videoRef.current.click()}
                                >
                                    <div className="boxinner">
                                        <div className="boxOneadd">
                                            <div className="boxOneinner">
                                                <input
                                                    ref={videoRef}
                                                    type="file"
                                                    accept="video/*"
                                                    onChange={(e) =>
                                                        onFileChange(
                                                            e,
                                                            "VIDEOS",
                                                            videoExtension
                                                        )
                                                    }
                                                    style={{ display: "none" }}
                                                />
                                                {dynamicIcon("VIDEOS")}
                                            </div>
                                        </div>
                                    </div>
                                    <div className="boxTwo-img"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="grid grid-cols-5  gap-3">
                    <div className=" col-span-3 flex justify-end">
                        <Button
                            style={{ marginRight: "1rem" }}
                            type="button"
                            disabled={false}
                            variant="outlined"
                            className="float-left"
                            onClick={(e) => {
                                e.preventDefault();
                                props.changeTab("Details");
                            }}
                        >
                            Back
                        </Button>
                        <Button
                            type="submit"
                            variant="contained"
                            className="text-[20px] px-6 py-1 btn-blue float-right"
                            onClick={handleSubmit(handleUploadSubmit)}
                            disabled={isProductImgLoad || imgArray.length < 3}
                        >
                            Next
                        </Button>
                    </div>
                </div>
            </form>
            <PreviewModalWrapper
                heading="Document Preview"
                isPopUpShow={previewModal}
                size="lg"
                toggleModel={handlePreviewModal}
            >
                <>
                    {previewModal && (
                        <FileViewer
                            fileType={getFileExtensionByUrl(viewDocUrl)}
                            filePath={viewDocUrl}
                            //errorComponent={CustomErrorComponent}
                            //onError={this.onError}
                        />
                    )}
                </>
            </PreviewModalWrapper>
        </>
    );
};

export default TabContentUploads;
