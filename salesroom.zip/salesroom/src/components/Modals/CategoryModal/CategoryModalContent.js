import React, { useContext } from "react";
import Swal from "sweetalert2";
import TextField from "@mui/material/TextField";
import modalContext from "../../Modals/ModalContext";
import doneicn from "../../../assets/images/icon/doneicn.gif";
const CategoryModalContent = () => {
  const { setShowModal, setCreateCategory, setCreateNewCategory } =
    useContext(modalContext);
  const handleDone = () => {
    setCreateCategory(false);
    setCreateNewCategory(false);
    setShowModal(false);
    Swal.fire({
      title: "Category Created",
        imageUrl: doneicn,
        imageWidth:"100",
      showConfirmButton: false,
      timer: 2000,
    });
  };
  const handleCencle = () => {
    setShowModal(false);
    setCreateNewCategory(false);
  };

  return (
    <>
      {/*header*/}
      {/* <div className="flex items-start justify-center p-5">
        <h3 className="text-3xl font-semibold text-center">Add Category</h3>
      </div> */}
      {/*body*/}
      <div className="relative p-6 flex-auto">
        <TextField id="standard-basic" label="Enter Category Name" required />
      </div>
      {/*footer*/}
      {/* <div className="flex items-center justify-end p-6 border-t border-solid border-slate-200 rounded-b">
        <button
          className="modal-cancle-btn"
          type="button"
          onClick={handleCencle}
        >
          Cancle
        </button>
        <button className="modal-done-btn" type="button" onClick={handleDone}>
          Done
        </button>
      </div> */}
    </>
  );
};

export default CategoryModalContent;
