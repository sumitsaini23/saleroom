import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import LazyLoad from "react-lazyload";
import { useNavigate } from "react-router-dom";
import { Status } from "../../common/utility";
import { changeStatus } from "../../reducers/authSlice";
import MultiStepProgressBar from "./MultiStepProgressBar";
import WorkEmail from "./WorkEmail";
import EnterOTP from "./EnterOTP";
import EnterPassword from "./EnterPassword";
import NameYourRoom from "./NameYourRoom";
import CompanyLogoWebsite from "./CompanyLogoWebsite";
import CompanyAddress from "./CompanyAddress";
import SalesroomToWork from "./SalesroomToWork";
import SocialMediaLinks from "./SocialMediaLinks";
import "./Signup.module.scss";

export default function Signup() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const currentStep = useSelector((state) => state.auth.signUp.currentStep);
  //const regEmail = useSelector((state) => state.auth.signUp.email);
  const status = useSelector((state) => state.auth.status);
  const isLoggedIn = useSelector((state) => state.auth.isLoggedIn);

  /**
   * Check user is loggedIn
   *
   */
  useEffect(() => {
    if (status === Status.SUCCESS && isLoggedIn === true) {
      dispatch(changeStatus());
      navigate("/dashboard");
    }
  }, [dispatch, navigate, status, isLoggedIn]);

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <LazyLoad once>
            <WorkEmail />
          </LazyLoad>
        );
      case 2:
        //return provideEmail ? <EnterOTP /> : <EnterPassword />;
        return (
          <LazyLoad once>
            <EnterOTP />
          </LazyLoad>
        );
      case 3:
        //return provideEmail ? <EnterPassword /> : <NameYourRoom />;
        return (
          <LazyLoad once>
            <EnterPassword />
          </LazyLoad>
        );
      case 4:
        //return provideEmail ? <NameYourRoom /> : <CompanyLogoWebsite />;
        return (
          <LazyLoad once>
            <NameYourRoom />
          </LazyLoad>
        );
      case 5:
        //return provideEmail ? <CompanyLogoWebsite /> : <CompanyAddress />;
        return (
          <LazyLoad once>
            <CompanyLogoWebsite />
          </LazyLoad>
        );
      case 6:
        //return provideEmail ? <CompanyAddress /> : <SalesroomToWork />;
        return (
          <LazyLoad once>
            <CompanyAddress />
          </LazyLoad>
        );
      case 7:
        //return provideEmail ? <SalesroomToWork /> : <SocialMediaLinks />;
        return (
          <LazyLoad once>
            <SalesroomToWork />
          </LazyLoad>
        );
      case 8:
        //return provideEmail ? <SocialMediaLinks /> : <EnterPassword />;
        return (
          <LazyLoad once>
            <SocialMediaLinks />
          </LazyLoad>
        );
      default:
        return null;
    }
  };

  return (
    <div className="11bg-[#ecedf0] signup">
      <div className="grid grid-cols-1  h-screen">
        <div
          className="header flex justify-center h-0"
          style={{ height: "75px" }}
        >
          {/* <h1 className="text-[#174fba] font-bold py-3 text-6xl mb-3"> Salesroom </h1> */}
          <img
            alt="Salesroom_logo"
            src={require("../../assets/images/icon/new logo.png")}
            className="h-20 mt-0"
          />
        </div>
        <div className="mb-2">
          <MultiStepProgressBar currentStep={currentStep} />
        </div>
        <main>
          <div className="formbox grid  ">{renderStep()}</div>
        </main>
      </div>
    </div>
  );
}
