import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  showModal: false,
  navDropdownItem: "",
  uploadItem: "",
  heading: "",
  category: {},
  product: {
    productName: "",
    productId: "",
    categoryId: "",
  },
};

/**
 * Reducers
 */

export const modalSlice = createSlice({
  name: "modalPopup",
  initialState,
  reducers: {
    showCategoryModal: (state, action) => {
      state.navDropdownItem = action.payload.selectedMenu;
      state.showModal = !state.showModal;
      state.heading = action.payload.action;
    },
    showProductModal: (state, action) => {
      state.navDropdownItem = action.payload.selectedMenu;
      state.showModal = !state.showModal;
      state.heading = action.payload.action;
      state.product.productName = action.payload.productName;
      state.product.productId = action.payload.productId;
      state.product.categoryId = action.payload.categoryId;
    },
    showDocUploadModal: (state, action) => {
      state.navDropdownItem = action.payload.selectedMenu;
      state.showModal = !state.showModal;
    },
    hideModal: () => initialState,
  },
});

/**
 * Action creators are generated for each case reducer function
 */

export const {
  showCategoryModal,
  showProductModal,
  showDocUploadModal,
  hideModal,
} = modalSlice.actions;

export default modalSlice.reducer;
