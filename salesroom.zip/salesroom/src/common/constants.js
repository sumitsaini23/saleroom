/**
 *
 */
export const ALERT_INFO = "Info";
export const ALERT_WARNING = "Warning";
export const ALERT_ERROR = "Error";
export const ALERT_SUCCESS = "Success";

/**
 * businessSize
 */
export const businessSize = [
  {
    label: "1 to 10",
    value: "ONE_TO_TEN",
  },
  {
    label: "10 to 50",
    value: "TEN_TO_FIFTY",
  },
  {
    label: "50 to 100",
    value: "FIFTY_TO_HUNDRED",
  },
  {
    label: "100 to 500",
    value: "HUNDRED_TO_FIVE_HUNDRED",
  },
  {
    label: "500 to 1000",
    value: "FIVE_HUNDRED_TO_THOUSAND",
  },
  {
    label: "1000+",
    value: "THOUSAND_PLUS",
  },
];
/**
 * businessIndustry
 */
export const businessIndustry = [
  {
    label: "HEAT APPLICATION",
    value: "HEAT_APPLICATION",
  },
  {
    label: "AUTO MOBILE",
    value: "AUTO_MOBILE",
  },
  {
    label: "MEDICAL INSTRUMENTS",
    value: "MEDICAL_INSTRUMENTS",
  },
];

/**
 * contactType
 */
export const contactTypesData = {
  CUSTOMER: "CUSTOMER",
  DISTRIBUTOR: "DISTRIBUTOR",
  LEAD: "LEAD",
};

/**
 * Video file extensions
 */
export const videoExtension = [
  "MP4",
  "MOV",
  "WMV",
  "WebM",
  "AVI",
  "AVCHD",
  "FLV",
  "F4V",
  "SWF",
  "MKV",
  "mkv",
  "mp4",
  "webm",
  "flv",
  "f4v",
  "wmv",
  "avi",
  "avchd",
];
/**
 * Image file extensions
 */
export const imageExtension = ["JPEG", "JPG", "PNG", "jpeg", "jpg", "png"];
/**
 * Doc file extensions
 */
export const docExtension = [
  "DOC",
  "DOCX",
  "PDF",
  "doc",
  "docx",
  "pdf",
  "ppt",
  "pptx",
];

export const cadExtension = ["stp", "step", "abc", "sldasm", "sldprt"];

export const distributosGroupId = "eda3db98-0c5b-48e4-85fe-fdd69b62812a";
