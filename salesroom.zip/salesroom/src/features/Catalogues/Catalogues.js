import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import FileViewer from "react-file-viewer";
import Breadcrumb from "../../components/Breadcrumb/Breadcrumb";
import FileMenu from "../../components/UI/FileMenu";
import PreviewModalWrapper from "../../components/UI/PreviewModalWrapper";
import requestsApi from "../../app/requestsApi";
import UploadCardIconCmp from "../../components/UploadCardIconCmp";
import {
  checkObjectEmpty,
  getFileExtensionByUrl,
  getSortName,
  getFileNameByUrl,
} from "../../common/utility";
import { getAllCategories } from "../../reducers/categorySlice";
import { getAllProducts } from "../../reducers/productSlice";

const Catalogues = () => {
  const dispatch = useDispatch();
  const userRole = useSelector((state) => state.auth?.user?.role);
  const businessId = useSelector((state) => state.auth?.user?.businessId);
  const [cataloguesFile, setCataloguesFile] = useState({});
  const [previewModal, setPreviewModal] = useState(false);
  const [pdfDocUrl, setPdfDocUrl] = useState("");

  useEffect(() => {
    if (businessId) {
      getCataloguesByBusinessId();
      dispatch(getAllCategories({ businessId }));
      dispatch(getAllProducts({ businessId, offset: 0 }));
    }
  }, [businessId, dispatch]);
  /**
   * component will unmount
   */
  useEffect(() => {
    return () => {
      setCataloguesFile({});
    };
  }, []);

  const getCataloguesByBusinessId = async () => {
    await requestsApi
      .getRequest(`/v1/dashboard/search`, {
        businessId: businessId,
        filterBy: "CATALOG",
      })
      .then(function (response) {
        //// console.log("response", response);
        setCataloguesFile(response);
      })
      .catch(function (error) {
        // console.log("error", error);
      });
  };

  const getTotaCataloguesCount = () => {
    // // console.log(
    //     "checkObjectEmpty(cataloguesFile)",
    //     checkObjectEmpty(cataloguesFile)
    // );
    return checkObjectEmpty(cataloguesFile)
      ? cataloguesFile?.catalogs?.length
      : 0;
  };

  const getCataloguesFile = () => {
    return checkObjectEmpty(cataloguesFile) ? cataloguesFile?.catalogs : [];
  };

  const handlePreviewModal = () => {
    let val = !previewModal;
    if (val === false) {
      setPdfDocUrl("");
    }
    setPreviewModal(val);
  };

  /**
   * Child Component
   */
  const CataloguessCardCmp = ({ imgUrl }) => {
    return (
      <div className="mainbox">
        <div className="boxMain">
          <div className="boxinner">
            <div className="boxOne">
              <div className="boxOneinner">
                <img
                  style={{ paddingTop: "25px" }}
                  src={
                    getFileExtensionByUrl(imgUrl) === "pdf"
                      ? require(`../../assets/images/image/awesome-file-pdf.png`)
                      : require(`../../assets/images/image/Group 658.png`)
                  }
                  onClick={() => {
                    setPdfDocUrl(imgUrl);
                    handlePreviewModal();
                  }}
                  alt="img"
                />
              </div>
            </div>
          </div>
          <div className="boxTwo">
            <img
              src={
                getFileExtensionByUrl(imgUrl) === "pdf"
                  ? require(`../../assets/images/image/awesome-file-pdf.png`)
                  : require(`../../assets/images/image/Group 658.png`)
              }
              alt="img"
            />
            {getSortName(getFileNameByUrl(imgUrl, "/CATALOG/"), 14)}
            <span
              style={{
                float: "right",
                color: "#ccc",
                marginTop: "-3.5%",
              }}
            >
              {" "}
              <FileMenu url={imgUrl} />{" "}
            </span>
          </div>
        </div>
      </div>

      // <Card sx={{ minWidth: 205 }}>
      //     <CardContent>
      //         <div className="text-center">
      //             <div className="innerpaddingimg cadmainimg">
      //                 <img src={imgUrl} alt="img" />
      //             </div>
      //             <div className="cadimg mt-3">
      //                 <img
      //                     src={require(`../../assets/images/image/awesome-file-pdf.png`)}
      //                     alt="img"
      //                 />
      //                 <span
      //                     className="font-regular font-poppins pt-2 fntclr "
      //                     style={{ fontSize: ".75rem" }}
      //                 >

      //                 </span>
      //             </div>
      //         </div>
      //         <div></div>
      //         <div></div>
      //     </CardContent>
      // </Card>
    );
  };

  /**
   * Child Component
   */
  const CataloguessFileCmp = (props) => {
    return (
      <>
        {props?.fileDetails?.map((data, i) => (
          <div key={`${data.productName}_${i}`}>
            <div className="text-xl font-normal mb-1 mt-6">
              {data.productName}
            </div>
            <div
              className={
                "Categories"
                  ? "grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 gap-6 mt-6 "
                  : "hidden"
              }
              id="link1"
            >
              {data.catalogUrls?.map((imgUrl, index) => (
                <CataloguessCardCmp
                  //ukey={`catalog_${index}_${props.imgDetails?.productId}`}
                  imgUrl={imgUrl}
                  key={`catalog_${index}_${props.imgDetails?.productId}`}
                />
              ))}
              {userRole === "SUPER_ADMIN" || userRole === "ADMIN" ? (
                <UploadCardIconCmp
                  title="Catalogues"
                  key={data.productName}
                  productId={data.productId}
                  uploadCategoryType="CATALOG"
                  refreshList={getCataloguesByBusinessId}
                />
              ) : null}
            </div>
          </div>
        ))}
      </>
    );
  };

  return (
    <>
      <Breadcrumb />
      <div className="p-6 mb-3">
        <div className="mb-6">
          <h2 className="text-3xl font-bold mb-1">
            Catalogues {`(${getTotaCataloguesCount()})`}
          </h2>
          {/* <h2 className="text-lg font-normal">2 Manuals</h2> */}
          {getCataloguesFile()?.map((rec, index) => (
            <CataloguessFileCmp
              title="CPAP"
              fileDetails={rec.catalogInfo}
              index={index}
              key={`Catalog-${index}`}
            />
          ))}
          {/* <div className="text-xl mt-5 font-normal">Product 1</div> */}
        </div>
        <PreviewModalWrapper
          heading="Document Preview"
          isPopUpShow={previewModal}
          size="lg"
          toggleModel={handlePreviewModal}
        >
          <FileViewer
            fileType={getFileExtensionByUrl(pdfDocUrl)}
            filePath={pdfDocUrl}
            //errorComponent={CustomErrorComponent}
            //onError={this.onError}
          />
        </PreviewModalWrapper>
      </div>
    </>
  );
};

export default Catalogues;
