import React, { useEffect, useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import OtpInput from "react-otp-input";
//import MultiStepFormContext from "./MultiStepFormContext";
import { Button } from "@mui/material";
import Loader from "../../components/Loader";
import { Status } from "../../common/utility";
import {
  nextStep,
  previousStep,
  verifyOtp,
  changeStatus,
} from "../../reducers/authSlice";

const EnterOTP = () => {
  //const { next, prev } = useContext(MultiStepFormContext);
  const [otpCode, setOtpCode] = useState("");
  const [Isloading, setLoading] = useState(false);
  const status = useSelector((state) => state.auth.status);
  const regEmail = useSelector((state) => state.auth.signUp.email);
  const otpReferenceId = useSelector(
    (state) => state.auth.signUp.otpReferenceId
  );
  const otp = useSelector((state) => state.auth.signUp.otp);
  const dispatch = useDispatch();

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm();

  useEffect(() => {
    if (status === Status.SUCCESS && otpReferenceId !== "") {
      dispatch(changeStatus());
      reset();
      setLoading(false);
      dispatch(nextStep(3));
      // setTimeout(() => {
      //     reset();
      //     setLoading(false);
      //     dispatch(nextStep(3));
      // }, 1000);
    } else {
      if (otp !== "") {
        reset({
          otp: otp,
        });
        setOtpCode(otp);
      }
      setLoading(false);
    }
  }, [dispatch, status, otpReferenceId, reset, otp]);

  const onSubmit = async (data) => {
    setLoading(true);
    let otp = data.otp;
    await dispatch(verifyOtp({ regEmail, otp, otpReferenceId }));
    setLoading(false);
  };

  const handleChange = (val) => {
    setOtpCode(val);
  };

  // const OtpSend = (otpValue) => {
  //     // console.log(isLangth);
  //     if (isLangth < 6) {
  //         setBundle({ ...ErrorBundle, Error: true });
  //     } else {
  //         setLoading(true);
  //         setTimeout(() => {
  //             setLoading(false);
  //             setEnterOPT(otpValue);
  //             next();
  //         }, 1000);
  //     }
  // };

  return (
    <form>
      <>
        <div className="header  mb-7">
          <h2 className="text-[26px] font-medium">
            Enter OTP sent to your email
          </h2>
        </div>
        <div className="OPTscreen grid grid-cols-4 gap-3">
          <div className="body col-span-4 pt-12">
            <div className="grid grid-cols-4 gap-3">
              <div className="col-span-4 flex justify-center items-center">
                <div
                  className={`form__item ${errors.website && "input__error"}`}
                >
                  <Controller
                    name="otp"
                    value={otpCode}
                    rules={{
                      required: true,
                    }}
                    onChange={handleChange}
                    control={control}
                    render={({ field: { onChange, value } }) => (
                      <OtpInput
                        value={value}
                        onChange={onChange}
                        numInputs={6}
                        separator={<span style={{ width: "8px" }}></span>}
                        isInputNum={true}
                        shouldAutoFocus={true}
                        inputStyle={{
                          borderBottom: "1px solid #136fcb",
                          borderRadius: "0px",
                          width: "55px",
                          height: "55px",
                          fontSize: "20px",
                          color: "#000",
                          fontWeight: "500",
                          caretColor: "blue",
                        }}
                        focusStyle={{
                          borderBottom: "1px solid #CFD3DB",
                        }}
                      />
                    )}
                  />

                  {errors.otp && errors.otp.type === "required" && (
                    <span className="errormsg" role="alert">
                      OTP is required
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="footer col-span-4 flex justify-between mb-5">
            <Button
              style={{ marginRight: "1rem" }}
              type="button"
              className="btnoutline mr-2"
              onClick={() => {
                dispatch(changeStatus());
                dispatch(previousStep());
              }}
            >
              Back
            </Button>
            <Button
              type="submit"
              className="btn-blue"
              onClick={handleSubmit(onSubmit)}
              // onClick={() =>
              //     dispatch(
              //         nextStep() // update formStage
              //     )
              // }
            >
              {Isloading ? <Loader isLoading={Isloading} /> : "Next"}
            </Button>
          </div>
        </div>
      </>
    </form>
  );
};
export default EnterOTP;
