import React from "react";
import { FaRegWindowClose } from "react-icons/fa";
import ImageUploading from "react-images-uploading";

const UploadImage = (props) => {
  const { images, onChange, allowedExtension } = props;
  const maxNumber = 69;
  return (
    <>
      <ImageUploading
        // multiple
        value={images}
        onChange={onChange}
        maxNumber={maxNumber}
        dataURLKey="data_url"
        acceptType={allowedExtension} //"jpg", "jpeg", "png", "pdf", "doc", "docx"
      >
        {({
          imageList,
          onImageUpload,
          onImageRemoveAll,
          onImageUpdate,
          onImageRemove,
          isDragging,
          dragProps,
          errors,
        }) => (
          // write your building UI
          <div className="upload__image-wrapper">
            <button
              type="button"
              style={isDragging ? { color: "red" } : undefined}
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                onImageUpload();
              }}
              {...dragProps}
            >
              <img
                src={require("../../assets/images/icon/addImage.png")}
                width={160}
                height={275}
                className="rounded-[20px] cursor-pointer"
                alt="img-1"
              />
            </button>
            &nbsp;
            {/* <button onClick={onImageRemoveAll}><FaRegWindowClose /></button> */}
            {imageList.map((image, index) => (
              <>
                <div
                  key={index}
                  className="image-item absolute -mt-[148px] flex justify-center items-center w-[158px] h-[140px]"
                >
                  <img
                    src={image["data_url"]}
                    alt=""
                    className="rounded-[20px] cursor-pointer max-h-[140px] max-w-[140px] mx-auto"
                  />
                </div>
                <div
                  className="image-item__btn-wrapper"
                  key={image["file"].lastModified}
                >
                  {/* <button onClick={() => onImageUpdate(index)}>Update</button> */}
                  <button
                    type="button"
                    onClick={() => onImageRemove(index)}
                    className="absolute"
                  >
                    <FaRegWindowClose
                      className="text-[14px]"
                      key={`icon-${image["file"].lastModified}`}
                    />
                  </button>
                </div>
              </>
            ))}
            {errors && (
              <div>
                {/* {errors.maxNumber && (
                                    <span>
                                        Number of selected images exceed
                                        maxNumber
                                    </span>
                                )} */}
                {errors.acceptType && (
                  <span className={"error__feedback"}>
                    Your selected file type is not allow
                  </span>
                )}
                {/* {errors.maxFileSize && (
                                    <span>
                                        Selected file size exceed maxFileSize
                                    </span>
                                )}
                                {errors.resolution && (
                                    <span>
                                        Selected file is not match your desired
                                        resolution
                                    </span>
                                )} */}
              </div>
            )}
          </div>
        )}
      </ImageUploading>
    </>
  );
};

export default UploadImage;
