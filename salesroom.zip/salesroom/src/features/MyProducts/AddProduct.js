import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";

import { startLoader, stopLoader } from "../../reducers/commonSlice";
import { resetCreateProductObj } from "../../reducers/productSlice";

import Breadcrumb from "../../components/Breadcrumb/Breadcrumb";
import TabContentDetails from "../Categories/TabContentDetails";
import TabContentUploads from "../Categories/TabContentUploads";
import TabContentSpecification from "../Categories/TabContentSpecification";

const AddProduct = (props) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const [openTab, setOpenTab] = useState("Details");
  let categoryName = location.state?.categoryName;
  /**
   * Component mount
   */
  //  useEffect(() => {

  // }, []);

  /**
   * Clear state when component unmount
   */
  useEffect(() => {
    return () => {
      // console.log("cleaned up");
      dispatch(resetCreateProductObj());
      //navigate(location.state, {});
    };
  }, []);

  const changeTab = (tabVal) => {
    setOpenTab(tabVal);
  };

  return (
    <>
      <Breadcrumb />
      <div className="flex flex-col w-full px-6 pt-7">
        <h3 className="font-bold">{categoryName}</h3>
      </div>

      <div className="flex  ">
        <div className="w-full">
          <ul
            className="tabs-btn flex mb-0 list-none flex-wrap pt-3 pb-4 flex-row px-6 border-b-2"
            role="tablist"
          >
            {/* Details tab */}
            <li className="-mb-px mr-2 last:mr-0 text-center">
              <a
                className={
                  "text-xs font-bold px-5 py-3 shadow-lg rounded block leading-normal" +
                  (openTab === "Details" ? " active" : " ")
                }
                onClick={(e) => {
                  e.preventDefault();
                  //setOpenTab("Details");
                }}
                data-toggle="tab"
                href="#link1"
                role="tablist"
                style={{ cursor: "default" }}
              >
                Details
              </a>
            </li>
            {/* Uploads tab */}
            <li className="-mb-px mr-2 last:mr-0 text-center">
              <a
                className={
                  "text-xs font-bold px-5 py-3 shadow-lg rounded block leading-normal" +
                  (openTab === "Uploads" ? " active" : " ")
                }
                onClick={(e) => {
                  e.preventDefault();
                  //setOpenTab("Uploads");
                }}
                data-toggle="tab"
                href="#link2"
                role="tablist"
                style={{ cursor: "default" }}
              >
                Uploads
              </a>
            </li>
            {/* Specifications tab */}
            <li className="-mb-px mr-2 last:mr-0 text-center">
              <a
                className={
                  "text-xs font-bold px-5 py-3 shadow-lg rounded block leading-normal" +
                  (openTab === "Specifications" ? " active" : " ")
                }
                onClick={(e) => {
                  e.preventDefault();
                  //setOpenTab("Specifications");
                }}
                data-toggle="tab"
                href="#link2"
                role="tablist"
                style={{ cursor: "default" }}
              >
                Specifications
              </a>
            </li>
          </ul>
          <div className="body px-6">
            {/* Details tab Content */}
            <div
              className={
                openTab === "Details" ? "grid grid-cols-1 gap-6 mt-6" : "hidden"
              }
              id="link1"
            >
              <TabContentDetails changeTab={changeTab} />
            </div>
            {/* Uploads tab content */}
            <div
              className={openTab === "Uploads" ? "block mt-6" : "hidden"}
              id="link1"
            >
              <TabContentUploads changeTab={changeTab} />
            </div>
            {/* Specifications  tab content */}
            <div
              className={
                openTab === "Specifications"
                  ? "grid grid-cols-1 md:grid-cols-1 lg:grid-cols-1 gap-6 mt-6"
                  : "hidden"
              }
              id="link1"
            >
              <TabContentSpecification
                changeTab={changeTab}
                key="productSpecifications"
              />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AddProduct;
