import React from "react";
import PropTypes from "prop-types";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";

function CardCmp(props) {
  return (
    <Card sx={{ boxShadow: 10 }}>
      <CardContent>
        <div className="flex justify-between">
          <h2 className="font-bold font-poppins uppercase">{props.heading}</h2>
          {/* <MoreVertIcon Link to="/" onClick={handleClick} /> */}
          {/* <StyledMenu
                      id="basic-menu"
                      anchorEl={anchorEl}
                      open={open}
                      onClose={handleClose}
                      MenuListProps={{
                        "aria-labelledby": "basic-button",
                      }}
                    >
                      <MenuItem >
                        <EditIcon /> Rename
                      </MenuItem>

                      <MenuItem >
                        <DownloadIcon /> Download
                      </MenuItem>
                      <MenuItem>
                        <InfoIcon /> Info
                      </MenuItem>
                      <MenuItem>
                        <DeleteIcon /> Delete
                      </MenuItem>
                    </StyledMenu> */}
        </div>
      </CardContent>
      <CardActions></CardActions>
    </Card>
  );
}

// CardCmp.propTypes = {}

export default CardCmp;
