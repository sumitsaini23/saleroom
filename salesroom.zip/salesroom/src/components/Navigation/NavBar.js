import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { styled, alpha } from "@mui/material/styles";
import InputBase from "@mui/material/InputBase";
import SearchIcon from "@mui/icons-material/Search";
//import Badge from "@mui/material/Badge";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
// import NotificationsIcon from '@mui/icons-material/Notifications';
//import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";
import AccountCircle from "@mui/icons-material/AccountCircle";
import MuiAppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import LogoutIcon from "@mui/icons-material/Logout";
import SettingsIcon from "@mui/icons-material/Settings";
import IconButton from "@mui/material/IconButton";
import { Button } from "@mui/material";
import { IoCreateSharp } from "react-icons/io5";
import { FaShare } from "react-icons/fa";
import Dropdown from "./Dropdown";
import SideBar from "./SideBar";
import LogoIcon from "../Logo/LogoIcon";
// import { Search } from "@mui/icons-material";
import { getSortName } from "../../common/utility";
import { logout } from "../../reducers/authSlice";

const drawerWidth = 240;

const Search = styled("div")(({ theme }) => ({
  position: "relative",
  borderRadius: theme.shape.borderRadius,
  backgroundColor: alpha(theme.palette.common.white, 0.15),
  "&:hover": {
    backgroundColor: alpha(theme.palette.common.white, 0.25),
  },
  marginRight: theme.spacing(2),
  marginLeft: 0,
  width: "100%",
  [theme.breakpoints.up("sm")]: {
    marginLeft: theme.spacing(3),
    width: "auto",
  },
}));

const SearchIconWrapper = styled("div")(({ theme }) => ({
  padding: theme.spacing(0, 2),
  height: "100%",
  position: "absolute",
  pointerEvents: "none",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  color: "inherit",
  "& .MuiInputBase-input": {
    padding: theme.spacing(0.5, 1, 1, 0),
    // vertical padding + font size from searchIcon
    paddingLeft: `calc(1em + ${theme.spacing(4)})`,
    transition: theme.transitions.create("width"),
    width: "100%",
    [theme.breakpoints.up("md")]: {
      width: "20ch",
    },
  },
}));

const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== "open",
})(({ theme, open }) => ({
  zIndex: theme.zIndex.drawer + 1,
  transition: theme.transitions.create(["width", "margin"], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  ...(open && {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
}));

export default function NavBar(props) {
  //const theme = useTheme();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [open, setOpen] = React.useState(true);
  const [anchorEl, setAnchorEl] = React.useState(null);
  //const userName = useSelector((state) => state.auth?.user?.fullName);
  const email = useSelector((state) => state.auth?.user?.email);
  const userRole = useSelector((state) => state.auth?.user?.role);
  const openMenu = Boolean(anchorEl);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleDrawerOpen = () => {
    setOpen(true);
  };

  const handleDrawerClose = () => {
    setOpen(false);
  };

  return (
    <>
      <AppBar position="fixed" open={open} sx={{ bgcolor: "#fff" }}>
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            onClick={handleDrawerOpen}
            edge="start"
            sx={{
              marginRight: 5,
              ...(open && { display: "none" }),
            }}
          >
            <LogoIcon />
          </IconButton>
          <nav className="py-3 " style={{ width: " 100%", display: "flex" }}>
            <div
              className="flex px-4"
              style={{
                float: "left",
                marginLeft: "auto",
                // marginRight: "auto",
              }}
            >
              <div className="basis-[40%]">
                {/* <Link to="/dashboard">
                        <img
                            className="w-48"
                            src={require("../../assets/images/image/logo.png")}
                            alt="logo"
                        />
                    </Link> */}
              </div>
              <div className="font-poppins flex items-center justify-start basis-[60%]">
                {userRole === "SUPER_ADMIN" || userRole === "ADMIN" ? (
                  <Dropdown />
                ) : null}

                <Button className="btn-blue btnmargin text-white py-[6px] px-4 bg-primary text-md font-semibold flex justify-between shadow-xl mr-3">
                  <span className="text-xl font-semibold px-2">
                    <IoCreateSharp />
                  </span>
                  Create
                </Button>
                <Button className="btn-black btnmargin text-white py-[6px] px-4 bg-black  text-md font-semibold flex justify-between shadow-xl mr-3">
                  <span className="text-xl font-semibold px-2">
                    <FaShare />
                  </span>
                  Share
                </Button>
              </div>
            </div>
            <div
              style={{
                display: "flex",
                paddingTop: "5px",
                margin: "0px 50px 0px 30px",
              }}
            >
              {" "}
              <Search className="searchcss">
                <SearchIconWrapper>
                  <SearchIcon />
                </SearchIconWrapper>
                <StyledInputBase
                  placeholder="Search…"
                  inputProps={{ "aria-label": "search" }}
                />
              </Search>
              {/* <Box sx={{ flexGrow: 1 }} />
          <Box sx={{ display: { xs: 'none', md: 'flex' } }}> */}
              {/* <IconButton
                                sx={{
                                    paddingTop: "5px",
                                    color: "#174fba",
                                }}
                                //style={{ paddingTop: "5px" }}
                                size="large"
                                aria-label="show 17 new notifications"
                                color="inherit"
                            >
                                <Badge badgeContent={7} color="error">
                                    <NotificationsNoneIcon />
                                </Badge>
                            </IconButton> */}
              <span style={{ display: "flex" }}>
                <IconButton
                  sx={{
                    paddingTop: "5px",
                    color: "#174fba",
                  }}
                  //style={{ paddingTop: "5px" }}
                  size="large"
                  edge="end"
                  aria-label="account of current user"
                  //   aria-controls={menuId}
                  aria-haspopup="true"
                  //   onClick={handleProfileMenuOpen}
                  color="inherit"
                  onClick={handleClick}
                >
                  <AccountCircle />
                </IconButton>
                <span
                  style={{
                    color: "black",
                    paddingLeft: "10px",
                  }}
                >
                  <div onClick={handleClick}>
                    {email ? getSortName(email, 17) : null}
                  </div>
                  <div
                    style={{
                      fontSize: "10px",
                      color: "#707070",
                    }}
                  >
                    Active
                  </div>
                </span>
                <Menu
                  id="basic-menu"
                  anchorEl={anchorEl}
                  open={openMenu}
                  onClose={handleClose}
                  MenuListProps={{
                    "aria-labelledby": "basic-button",
                  }}
                >
                  <MenuItem onClick={() => navigate("/setting")}>
                    <SettingsIcon className="mr-2" sx={{ color: "#174fba" }} />
                    Account
                  </MenuItem>
                  <MenuItem onClick={() => dispatch(logout())}>
                    {/* <LogoutIcon sx={{ color: pink[500] }} /> */}
                    <LogoutIcon className="mr-2" sx={{ color: "#174fba" }} />
                    {"  "}
                    Logout
                  </MenuItem>
                </Menu>
              </span>
              {/* </Box>
          <Box sx={{ display: { xs: 'flex', md: 'none' } }}> */}
              {/* <IconButton
              size="large"
              aria-label="show more"
              aria-controls={mobileMenuId}
              aria-haspopup="true"
              onClick={handleMobileMenuOpen}
              color="inherit"
            >
              <MoreIcon />
            </IconButton> */}
            </div>
          </nav>
        </Toolbar>
      </AppBar>
      <SideBar toggle={open} drawerClose={handleDrawerClose} />
    </>
  );
}
